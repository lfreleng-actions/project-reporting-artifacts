# 📊 Gerrit Project Analysis Report: Opendaylight

**Generated:** 2026-10-23 07:09:58 UTC
**Schema Version:** 1.5.0

---## Table of Contents

- [Global Summary](#summary)
- [Gerrit Projects](#repositories)
- [Top Contributors](#contributors)
- [Top Organizations](#organizations)
- [Repository Feature Matrix](#features)
- [Deployed CI/CD Jobs](#workflows)
- [Orphaned Jenkins Jobs](#orphaned-jobs)
- [Unattributed Jenkins Jobs](#unattributed-jobs)

---

## 📈 Global Summary

**✅ Current** commits within last 365 days

**☑️ Active** commits between 365-1095 days

**🛑 Inactive** no commits in 1095+ days

| Metric | Count | Percentage |
| --- | --- | --- |
| Total Gerrit Projects | 27 | 100% |
| Current Gerrit Projects | 24 | 88.9% |
| Active Gerrit Projects | 1 | 3.7% |
| Inactive Gerrit Projects | 2 | 7.4% |
| No Apparent Commits | 0 | 0.0% |
| Total Commits | 115.8K | - |
| Total Lines of Code | 170.8K | - |

---
## 🏢 Top Organizations

The data presented in the table below covers the past 365 days.

**Organizations Found:** 151

| Rank | Organization | Contributors | Commits | LOC | Δ LOC | Avg LOC/Commit | Unique Repositories |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | pantheon.tech | 69 | 4115 | +268058 | 464526 | +17 | 23 |
| 2 | linuxfoundation.org | 15 | 1019 | +27343 | 43435 | +11 | 27 |
| 3 | github.com | 5 | 662 | +1494 | 2988 | 0 | 21 |
| 4 | opendaylight.org | 10 | 230 | +15557 | 31071 | 0 | 19 |
| 5 | hq.sk | 1 | 229 | +47 | 94 | 0 | 18 |
| 6 | orange.com | 19 | 130 | +185197 | 306835 | +488 | 12 |
| 7 | smartoptics.com | 3 | 101 | +21170 | 28873 | +133 | 4 |
| 8 | gmail.com | 190 | 5 | +164 | 295 | +6 | 22 |
| 9 | att.com | 14 | 2 | +570 | 1044 | +48 | 7 |
| 10 | fujitsu.com | 2 | 2 | +11888 | 13056 | +5360 | 2 |
| 11 | verizon.com | 6 | 2 | +4 | 5 | +1 | 11 |
| 12 | snyk.io | 1 | 1 | +1 | 2 | 0 | 1 |
| 13 | 126.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 14 | 163.com | 6 | 0 | 0 | 0 | 0 | 6 |
| 15 | 2cups.com | 1 | 0 | 0 | 0 | 0 | 6 |
| 16 | 6wind.com | 4 | 0 | 0 | 0 | 0 | 3 |
| 17 | 99cloud.net | 1 | 0 | 0 | 0 | 0 | 1 |
| 18 | ac.in | 4 | 0 | 0 | 0 | 0 | 14 |
| 19 | advaoptical.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 20 | altencalsoftlabs.com | 25 | 0 | 0 | 0 | 0 | 7 |
| 21 | altran.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 22 | amartus.com | 3 | 0 | 0 | 0 | 0 | 2 |
| 23 | appliedbroadband.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 24 | azverev.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 25 | b-com.com | 1 | 0 | 0 | 0 | 0 | 4 |
| 26 | bardicgrove.org | 1 | 0 | 0 | 0 | 0 | 1 |
| 27 | bigswitch.com | 2 | 0 | 0 | 0 | 0 | 1 |
| 28 | bluefield.tech | 1 | 0 | 0 | 0 | 0 | 2 |
| 29 | brocade.com | 22 | 0 | 0 | 0 | 0 | 16 |
| 30 | bsc.es | 1 | 0 | 0 | 0 | 0 | 2 |

---
## 👥 Top Contributors

The data presented in the table below covers the past 365 days.

**Contributors Found:** 1,170

| Rank | Contributor | Commits | LOC | Δ LOC | Avg LOC/Commit | Repositories | Organization |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Robert Varga | 3461 | +186358 | 349975 | +6 | 23 | pantheon.tech |
| 2 | Anil Belur | 992 | +27339 | 43425 | +11 | 26 | linuxfoundation.org |
| 3 | dependabot[bot] | 662 | +1494 | 2988 | 0 | 21 | github.com |
| 4 | Ivan Hrasko | 239 | +9678 | 15217 | +17 | 16 | pantheon.tech |
| 5 | jenkins-releng | 230 | +15557 | 31071 | 0 | 19 | opendaylight.org |
| 6 | Robert Varga | 229 | +47 | 94 | 0 | 18 | hq.sk |
| 7 | Matej Sramcik | 125 | +16987 | 26836 | +57 | 15 | pantheon.tech |
| 8 | Martin Balaz | 101 | +33594 | 44092 | +228 | 6 | pantheon.tech |
| 9 | Joakim Törnqvist | 97 | +20780 | 28377 | +135 | 2 | smartoptics.com |
| 10 | Gilles Thouenon | 76 | +12888 | 34286 | -111 | 6 | orange.com |
| 11 | tobias.pobocik | 72 | +3382 | 6003 | +10 | 8 | pantheon.tech |
| 12 | Yaroslav Lastivka | 48 | +5869 | 7632 | +85 | 12 | pantheon.tech |
| 13 | Christophe BETOULE | 26 | +128712 | 224057 | +1283 | 2 | orange.com |
| 14 | Andrew Grimberg | 24 | 0 | 0 | 0 | 16 | linuxfoundation.org |
| 15 | Samuel Schneider | 24 | +3368 | 4205 | +105 | 11 | pantheon.tech |
| 16 | orenais | 24 | +41963 | 45902 | +1584 | 1 | orange.com |
| 17 | PeterSuna | 22 | +3321 | 3474 | +144 | 10 | pantheon.tech |
| 18 | Branislav Taran | 12 | +3323 | 3673 | +247 | 2 | pantheon.tech |
| 19 | Oleksandr Akaiomov | 6 | +340 | 1113 | -72 | 1 | pantheon.tech |
| 20 | Tibor Král | 5 | +1838 | 2306 | +274 | 6 | pantheon.tech |
| 21 | Jimmi Wimmersjö | 4 | +390 | 496 | +71 | 4 | smartoptics.com |
| 22 | Olivier Dugeon | 4 | +1634 | 2590 | +169 | 4 | orange.com |
| 23 | Anil Belur | 2 | +3 | 3 | +1 | 1 | gmail.com |
| 24 | Balagangadhar Bathula | 2 | +570 | 1044 | +48 | 2 | att.com |
| 25 | Matthew Watkins | 2 | +3 | 8 | -1 | 3 | linuxfoundation.org |
| 26 | Richard Kosegi | 2 | +1 | 2 | 0 | 8 | gmail.com |
| 27 | Roshan Joyce | 2 | +11888 | 13056 | +5360 | 1 | fujitsu.com |
| 28 | Sangwook Ha | 2 | +4 | 5 | +1 | 11 | verizon.com |
| 29 | Akashkumar Bhavsar | 1 | +160 | 290 | +30 | 1 | gmail.com |
| 30 | LF Jenkins CI | 1 | +1 | 2 | 0 | 2 | linuxfoundation.org |

---
## 📊 Gerrit Projects

| Gerrit Project | Commits | LOC | Contributors | Days Inactive | Last Commit Date | Status |
| --- | --- | --- | --- | --- | --- | --- |
| [releng/autorelease](https://git.opendaylight.org/gerrit/admin/repos/releng/autorelease,general) | 28645 | +756 | 9 | 3 | 2026-10-19 | ✅ |
| [yangtools](https://git.opendaylight.org/gerrit/admin/repos/yangtools,general) | 11716 | +136635 | 8 | 22 | 2026-09-30 | ✅ |
| [docs](https://git.opendaylight.org/gerrit/admin/repos/docs,general) | 10972 | +1116 | 7 | 2 | 2026-10-20 | ✅ |
| [controller](https://git.opendaylight.org/gerrit/admin/repos/controller,general) | 10792 | +13728 | 9 | 3 | 2026-10-19 | ✅ |
| [releng/builder](https://git.opendaylight.org/gerrit/admin/repos/releng/builder,general) | 10732 | +7743 | 10 | 1 | 2026-10-22 | ✅ |
| [netconf](https://git.opendaylight.org/gerrit/admin/repos/netconf,general) | 7244 | +42706 | 12 | 2 | 2026-10-20 | ✅ |
| [mdsal](https://git.opendaylight.org/gerrit/admin/repos/mdsal,general) | 6064 | +8276 | 7 | 3 | 2026-10-19 | ✅ |
| [bgpcep](https://git.opendaylight.org/gerrit/admin/repos/bgpcep,general) | 4846 | +42902 | 13 | 28 | 2026-09-24 | ✅ |
| [openflowplugin](https://git.opendaylight.org/gerrit/admin/repos/openflowplugin,general) | 4242 | +4605 | 5 | 2 | 2026-10-21 | ✅ |
| [integration/test](https://git.opendaylight.org/gerrit/admin/repos/integration/test,general) | 3597 | +98 | 4 | 13 | 2026-10-09 | ✅ |
| [odlparent](https://git.opendaylight.org/gerrit/admin/repos/odlparent,general) | 3323 | +7571 | 6 | 3 | 2026-10-19 | ✅ |
| [ovsdb](https://git.opendaylight.org/gerrit/admin/repos/ovsdb,general) | 3022 | +5794 | 5 | 16 | 2026-10-07 | ✅ |
| [transportpce](https://git.opendaylight.org/gerrit/admin/repos/transportpce,general) | 2244 | +90126 | 12 | 3 | 2026-10-19 | ✅ |
| [aaa](https://git.opendaylight.org/gerrit/admin/repos/aaa,general) | 1819 | +7807 | 9 | 3 | 2026-10-19 | ✅ |
| [lispflowmapping](https://git.opendaylight.org/gerrit/admin/repos/lispflowmapping,general) | 1327 | +3995 | 6 | 13 | 2026-10-10 | ✅ |
| [infrautils](https://git.opendaylight.org/gerrit/admin/repos/infrautils,general) | 1046 | +2323 | 5 | 3 | 2026-10-19 | ✅ |
| [integration/distribution](https://git.opendaylight.org/gerrit/admin/repos/integration/distribution,general) | 915 | +647 | 7 | 14 | 2026-10-09 | ✅ |
| [gnmi](https://git.opendaylight.org/gerrit/admin/repos/gnmi,general) | 727 | +9999 | 12 | 1 | 2026-10-21 | ✅ |
| [l2switch](https://git.opendaylight.org/gerrit/admin/repos/l2switch,general) | 576 | +3993 | 5 | 3 | 2026-10-19 | ✅ |
| [ietf](https://git.opendaylight.org/gerrit/admin/repos/ietf,general) | 567 | +9940 | 6 | 3 | 2026-10-19 | ✅ |
| [integration/packaging](https://git.opendaylight.org/gerrit/admin/repos/integration/packaging,general) | 507 | 0 | 0 | 1750 | 2022-01-06 | 🛑 |
| [jsonrpc](https://git.opendaylight.org/gerrit/admin/repos/jsonrpc,general) | 410 | +1534 | 7 | 13 | 2026-10-10 | ✅ |
| [daexim](https://git.opendaylight.org/gerrit/admin/repos/daexim,general) | 327 | +920 | 5 | 13 | 2026-10-10 | ✅ |
| [transportpce/models](https://git.opendaylight.org/gerrit/admin/repos/transportpce/models,general) | 107 | +128258 | 4 | 10 | 2026-10-12 | ✅ |
| [.github](https://git.opendaylight.org/gerrit/admin/repos/.github,general) | 13 | +21 | 3 | 24 | 2026-09-28 | ✅ |
| [zzz-test-release](https://git.opendaylight.org/gerrit/admin/repos/zzz-test-release,general) | 4 | 0 | 0 | 2799 | 2019-02-22 | 🛑 |
| [ieft](https://git.opendaylight.org/gerrit/admin/repos/ieft,general) | 1 | 0 | 0 | 416 | 2025-09-01 | ☑️ |

**Total:** 27 repositories

---
## 🔧 Gerrit Project Feature Matrix

| Gerrit Project | Primary Type | Other Types | Dependabot | Pre-commit | ReadTheDocs | .gitreview | G2G | Status |
|----------------|--------------|-------------|------------|------------|-------------|------------|-----|--------|
| integration/packaging | Shell | Python, Smarty | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| .github | N/A |  | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| integration/test | Robot Framework | Python, Shell | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ |
| releng/autorelease | Python | Java/Maven, Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| transportpce/models | Python | Java/Maven | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| integration/distribution | Shell | Java/Maven, Python | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| ieft | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| docs | Shell | Python, HTML, CSS | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| aaa | Java/Maven | Python, CSS | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| releng/builder | Shell | Python, HCL | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| daexim | Java/Maven | Python | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| gnmi | Java/Maven | Python, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| ietf | Java/Maven |  | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| infrautils | Java/Maven | Python | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| l2switch | Java/Maven | Python | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| jsonrpc | Java/Maven | Python | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| lispflowmapping | Java/Maven | Python, Shell, HTML, CSS | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| odlparent | Java/Maven | Python, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| controller | Java/Maven | Python, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| zzz-test-release | Python | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| mdsal | Java/Maven | Python | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| bgpcep | Java/Maven | Python, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| ovsdb | Java/Maven | Python, Dockerfile, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| transportpce | Java/Maven | Python, Shell, PLpgSQL | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| openflowplugin | Java/Maven | Python, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| yangtools | Java/Maven | JavaScript, Python, Groovy | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| netconf | Java/Maven | JavaScript, Python, Shell, HTML, CSS | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |

---
## 🏁 Deployed CI/CD Jobs

**Total GitHub workflows:** 166

**Total Jenkins jobs:** 660

| Gerrit Project | GitHub Workflows | Workflow Count | Jenkins Jobs | Job Count |
|----------------|-------------------|----------------|--------------|-----------|
| .github | codeql<br>gerrit-required-verify.yaml<br>gerrit-verify.yaml | 3 |  | 0 |
| aaa | aaa-csit-1node-authn-all.yaml<br>call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 9 | aaa-csit-1node-authn-all-chromium<br>aaa-csit-1node-authn-all-titanium<br>aaa-csit-1node-authn-all-vanadium<br>aaa-csit-verify-1node-authn<br>aaa-maven-clm-0.20.x<br>aaa-maven-clm-0.21.x<br>aaa-maven-clm-0.22.x<br>aaa-maven-clm-master<br>aaa-maven-merge-0.20.x<br>aaa-maven-merge-0.21.x<br>aaa-maven-merge-0.22.x<br>aaa-maven-merge-master<br>aaa-maven-mri-stage-0.20.x<br>aaa-maven-mri-stage-0.21.x<br>aaa-maven-mri-stage-0.22.x<br>aaa-maven-mri-stage-master<br>aaa-maven-stage-0.20.x<br>aaa-maven-stage-0.21.x<br>aaa-maven-stage-0.22.x<br>aaa-maven-stage-master<br>aaa-maven-verify-0.20.x-mvn39-openjdk21<br>aaa-maven-verify-0.21.x-mvn39-openjdk21<br>aaa-maven-verify-0.22.x-mvn39-openjdk21<br>aaa-maven-verify-deps-0.20.x-mvn39-openjdk21<br>aaa-maven-verify-deps-0.21.x-mvn39-openjdk21<br>aaa-maven-verify-deps-0.22.x-mvn39-openjdk21<br>aaa-maven-verify-deps-master-mvn39-openjdk21<br>aaa-maven-verify-master-mvn39-openjdk21<br>aaa-release-merge-0.20.x<br>aaa-release-merge-0.21.x<br>aaa-release-merge-0.22.x<br>aaa-release-merge-master | 32 |
| bgpcep | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | bgpcep-csit-1node-bgp-ingest-all-chromium<br>bgpcep-csit-1node-bgp-ingest-all-manganese<br>bgpcep-csit-1node-bgp-ingest-all-titanium<br>bgpcep-csit-1node-bgp-ingest-all-vanadium<br>bgpcep-csit-1node-bgp-ingest-mixed-all-chromium<br>bgpcep-csit-1node-bgp-ingest-mixed-all-manganese<br>bgpcep-csit-1node-bgp-ingest-mixed-all-titanium<br>bgpcep-csit-1node-bgp-ingest-mixed-all-vanadium<br>bgpcep-csit-1node-gate-bgp-ingest-mixed-all-chromium<br>bgpcep-csit-1node-gate-bgp-ingest-mixed-all-manganese<br>bgpcep-csit-1node-gate-bgp-ingest-mixed-all-titanium<br>bgpcep-csit-1node-gate-bgp-ingest-mixed-all-vanadium<br>bgpcep-csit-1node-gate-throughpcep-all-chromium<br>bgpcep-csit-1node-gate-throughpcep-all-manganese<br>bgpcep-csit-1node-gate-throughpcep-all-titanium<br>bgpcep-csit-1node-gate-throughpcep-all-vanadium<br>bgpcep-csit-1node-gate-userfeatures-all-chromium<br>bgpcep-csit-1node-gate-userfeatures-all-manganese<br>bgpcep-csit-1node-gate-userfeatures-all-titanium<br>bgpcep-csit-1node-gate-userfeatures-all-vanadium<br>bgpcep-csit-1node-throughpcep-all-chromium<br>bgpcep-csit-1node-throughpcep-all-manganese<br>bgpcep-csit-1node-throughpcep-all-titanium<br>bgpcep-csit-1node-throughpcep-all-vanadium<br>bgpcep-csit-1node-userfeatures-all-chromium<br>bgpcep-csit-1node-userfeatures-all-manganese<br>bgpcep-csit-1node-userfeatures-all-titanium<br>bgpcep-csit-1node-userfeatures-all-vanadium<br>bgpcep-csit-3node-bgpclustering-all-chromium<br>bgpcep-csit-3node-bgpclustering-all-manganese<br>bgpcep-csit-3node-bgpclustering-all-titanium<br>bgpcep-csit-3node-bgpclustering-all-vanadium<br>bgpcep-csit-3node-bgpclustering-ha-only-chromium<br>bgpcep-csit-3node-bgpclustering-ha-only-manganese<br>bgpcep-csit-3node-bgpclustering-ha-only-titanium<br>bgpcep-csit-3node-bgpclustering-ha-only-vanadium<br>bgpcep-csit-3node-bgpclustering-longevity-only-chromium<br>bgpcep-csit-3node-bgpclustering-longevity-only-manganese<br>bgpcep-csit-3node-bgpclustering-longevity-only-titanium<br>bgpcep-csit-3node-bgpclustering-longevity-only-vanadium<br>bgpcep-maven-clm-0.23.x<br>bgpcep-maven-clm-master<br>bgpcep-maven-javadoc-publish-0.23.x-openjdk21<br>bgpcep-maven-javadoc-publish-master-openjdk21<br>bgpcep-maven-javadoc-verify-0.23.x-openjdk21<br>bgpcep-maven-javadoc-verify-master-openjdk21<br>bgpcep-maven-merge-0.23.x<br>bgpcep-maven-merge-master<br>bgpcep-maven-mri-stage-0.23.x<br>bgpcep-maven-mri-stage-master<br>bgpcep-maven-stage-0.23.x<br>bgpcep-maven-stage-master<br>bgpcep-maven-verify-0.23.x-mvn39-openjdk21<br>bgpcep-maven-verify-deps-0.23.x-mvn39-openjdk21<br>bgpcep-maven-verify-deps-master-mvn39-openjdk21<br>bgpcep-maven-verify-master-mvn39-openjdk21<br>bgpcep-release-merge-0.23.x<br>bgpcep-release-merge-master<br>bgpcep-tox-verify-0.23.x<br>bgpcep-tox-verify-master | 60 |
| controller | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml<br>update-graph | 9 | controller-csit-1node-akka1-all-chromium<br>controller-csit-1node-akka1-all-titanium<br>controller-csit-1node-akka1-all-vanadium<br>controller-csit-1node-benchmark-all-chromium<br>controller-csit-1node-benchmark-all-titanium<br>controller-csit-1node-benchmark-all-vanadium<br>controller-csit-1node-notifications-longevity-only-chromium<br>controller-csit-1node-notifications-longevity-only-titanium<br>controller-csit-1node-notifications-longevity-only-vanadium<br>controller-csit-1node-rest-cars-perf-all-chromium<br>controller-csit-1node-rest-cars-perf-all-titanium<br>controller-csit-1node-rest-cars-perf-all-vanadium<br>controller-csit-3node-benchmark-all-chromium<br>controller-csit-3node-benchmark-all-titanium<br>controller-csit-3node-benchmark-all-vanadium<br>controller-csit-3node-clustering-ask-all-chromium<br>controller-csit-3node-clustering-ask-all-titanium<br>controller-csit-3node-clustering-ask-all-vanadium<br>controller-csit-3node-clustering-tell-all-chromium<br>controller-csit-3node-clustering-tell-all-titanium<br>controller-csit-3node-clustering-tell-all-vanadium<br>controller-csit-3node-cs-chasing-leader-longevity-only-chromium<br>controller-csit-3node-cs-chasing-leader-longevity-only-titanium<br>controller-csit-3node-cs-chasing-leader-longevity-only-vanadium<br>controller-csit-3node-cs-partnheal-longevity-only-chromium<br>controller-csit-3node-cs-partnheal-longevity-only-titanium<br>controller-csit-3node-cs-partnheal-longevity-only-vanadium<br>controller-csit-3node-ddb-expl-lead-movement-longevity-only-chromium<br>controller-csit-3node-ddb-expl-lead-movement-longevity-only-titanium<br>controller-csit-3node-ddb-expl-lead-movement-longevity-only-vanadium<br>controller-csit-3node-drb-partnheal-longevity-only-chromium<br>controller-csit-3node-drb-partnheal-longevity-only-titanium<br>controller-csit-3node-drb-partnheal-longevity-only-vanadium<br>controller-csit-3node-drb-precedence-longevity-only-chromium<br>controller-csit-3node-drb-precedence-longevity-only-titanium<br>controller-csit-3node-drb-precedence-longevity-only-vanadium<br>controller-csit-3node-rest-clust-cars-perf-ask-only-chromium<br>controller-csit-3node-rest-clust-cars-perf-ask-only-titanium<br>controller-csit-3node-rest-clust-cars-perf-ask-only-vanadium<br>controller-csit-3node-rest-clust-cars-perf-tell-only-chromium<br>controller-csit-3node-rest-clust-cars-perf-tell-only-titanium<br>controller-csit-3node-rest-clust-cars-perf-tell-only-vanadium<br>controller-maven-clm-11.0.x<br>controller-maven-clm-12.0.x<br>controller-maven-clm-master<br>controller-maven-merge-11.0.x<br>controller-maven-merge-12.0.x<br>controller-maven-merge-master<br>controller-maven-mri-stage-11.0.x<br>controller-maven-mri-stage-12.0.x<br>controller-maven-mri-stage-master<br>controller-maven-stage-11.0.x<br>controller-maven-stage-12.0.x<br>controller-maven-stage-master<br>controller-maven-verify-11.0.x-mvn39-openjdk21<br>controller-maven-verify-12.0.x-mvn39-openjdk21<br>controller-maven-verify-deps-11.0.x-mvn39-openjdk21<br>controller-maven-verify-deps-12.0.x-mvn39-openjdk21<br>controller-maven-verify-deps-master-mvn39-openjdk21<br>controller-maven-verify-master-mvn39-openjdk21<br>controller-release-merge-11.0.x<br>controller-release-merge-12.0.x<br>controller-release-merge-master | 63 |
| daexim | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | daexim-csit-1node-basic-only-chromium<br>daexim-csit-1node-basic-only-manganese<br>daexim-csit-1node-basic-only-titanium<br>daexim-csit-3node-clustering-basic-only-chromium<br>daexim-csit-3node-clustering-basic-only-manganese<br>daexim-csit-3node-clustering-basic-only-titanium<br>daexim-distribution-check-chromium<br>daexim-distribution-check-manganese<br>daexim-distribution-check-titanium<br>daexim-maven-clm-chromium<br>daexim-maven-clm-manganese<br>daexim-maven-clm-titanium<br>daexim-maven-merge-chromium<br>daexim-maven-merge-manganese<br>daexim-maven-merge-titanium<br>daexim-maven-mri-stage-chromium<br>daexim-maven-mri-stage-manganese<br>daexim-maven-mri-stage-titanium<br>daexim-maven-stage-chromium<br>daexim-maven-stage-manganese<br>daexim-maven-stage-titanium<br>daexim-maven-verify-chromium-mvn39-openjdk21<br>daexim-maven-verify-deps-chromium-mvn39-openjdk21<br>daexim-maven-verify-deps-manganese-mvn39-openjdk21<br>daexim-maven-verify-deps-titanium-mvn39-openjdk21<br>daexim-maven-verify-manganese-mvn39-openjdk21<br>daexim-maven-verify-titanium-mvn39-openjdk21<br>daexim-validate-autorelease-chromium<br>daexim-validate-autorelease-manganese<br>daexim-validate-autorelease-titanium | 30 |
| docs | call-github2gerrit.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 4 | docs-tox-verify-chromium<br>docs-tox-verify-manganese<br>docs-tox-verify-titanium<br>docs-update-master | 4 |
| gnmi | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | gnmi-maven-clm-1.0.x<br>gnmi-maven-clm-2.0.x<br>gnmi-maven-clm-3.0.x<br>gnmi-maven-clm-master<br>gnmi-maven-merge-1.0.x<br>gnmi-maven-merge-2.0.x<br>gnmi-maven-merge-3.0.x<br>gnmi-maven-merge-master<br>gnmi-maven-mri-stage-1.0.x<br>gnmi-maven-mri-stage-2.0.x<br>gnmi-maven-mri-stage-3.0.x<br>gnmi-maven-mri-stage-master<br>gnmi-maven-stage-1.0.x<br>gnmi-maven-stage-2.0.x<br>gnmi-maven-stage-3.0.x<br>gnmi-maven-stage-master<br>gnmi-maven-verify-1.0.x-mvn39-openjdk21<br>gnmi-maven-verify-2.0.x-mvn39-openjdk21<br>gnmi-maven-verify-3.0.x-mvn39-openjdk21<br>gnmi-maven-verify-deps-1.0.x-mvn39-openjdk21<br>gnmi-maven-verify-deps-2.0.x-mvn39-openjdk21<br>gnmi-maven-verify-deps-3.0.x-mvn39-openjdk21<br>gnmi-maven-verify-deps-master-mvn39-openjdk21<br>gnmi-maven-verify-master-mvn39-openjdk21<br>gnmi-release-merge-1.0.x<br>gnmi-release-merge-2.0.x<br>gnmi-release-merge-3.0.x<br>gnmi-release-merge-master | 28 |
| ietf | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | ietf-maven-clm-master<br>ietf-maven-merge-master<br>ietf-maven-mri-stage-master<br>ietf-maven-stage-master<br>ietf-maven-verify-deps-master-mvn39-openjdk21<br>ietf-maven-verify-master-mvn39-openjdk21<br>ietf-release-merge-master | 7 |
| infrautils | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 7 | infrautils-maven-clm-master<br>infrautils-maven-merge-master<br>infrautils-maven-mri-stage-master<br>infrautils-maven-stage-master<br>infrautils-maven-verify-deps-master-mvn39-openjdk21<br>infrautils-maven-verify-master-mvn39-openjdk21<br>infrautils-release-merge-master | 7 |
| integration/distribution | call-github2gerrit.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 4 | distribution-docker-merge-chromium<br>distribution-docker-merge-manganese<br>distribution-docker-merge-titanium<br>distribution-docker-verify-chromium<br>distribution-docker-verify-manganese<br>distribution-docker-verify-titanium<br>distribution-maven-clm-chromium<br>distribution-maven-clm-manganese<br>distribution-maven-clm-titanium<br>distribution-maven-verify-deps-chromium-mvn39-openjdk21<br>distribution-maven-verify-deps-manganese-mvn39-openjdk21<br>distribution-maven-verify-deps-titanium-mvn39-openjdk21<br>distribution-tox-verify-chromium<br>distribution-tox-verify-manganese<br>distribution-tox-verify-titanium<br>integration-distribution-mri-test-chromium<br>integration-distribution-mri-test-manganese<br>integration-distribution-mri-test-titanium<br>integration-distribution-test-chromium<br>integration-distribution-test-manganese<br>integration-distribution-test-titanium<br>integration-distribution-validate-autorelease-chromium<br>integration-distribution-validate-autorelease-manganese<br>integration-distribution-validate-autorelease-titanium<br>integration-distribution-weekly-test-trigger-chromium<br>integration-distribution-weekly-test-trigger-manganese<br>integration-distribution-weekly-test-trigger-titanium | 27 |
| integration/test |  | 0 | integration-test-tox-verify-master | 1 |
| jsonrpc | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | jsonrpc-csit-1node-basic-only-chromium<br>jsonrpc-csit-1node-basic-only-manganese<br>jsonrpc-csit-1node-basic-only-titanium<br>jsonrpc-distribution-check-chromium<br>jsonrpc-distribution-check-manganese<br>jsonrpc-distribution-check-titanium<br>jsonrpc-maven-clm-chromium<br>jsonrpc-maven-clm-manganese<br>jsonrpc-maven-clm-titanium<br>jsonrpc-maven-merge-chromium<br>jsonrpc-maven-merge-manganese<br>jsonrpc-maven-merge-titanium<br>jsonrpc-maven-mri-stage-chromium<br>jsonrpc-maven-mri-stage-manganese<br>jsonrpc-maven-mri-stage-titanium<br>jsonrpc-maven-stage-chromium<br>jsonrpc-maven-stage-manganese<br>jsonrpc-maven-stage-titanium<br>jsonrpc-maven-verify-chromium-mvn39-openjdk21<br>jsonrpc-maven-verify-deps-chromium-mvn39-openjdk21<br>jsonrpc-maven-verify-deps-manganese-mvn39-openjdk21<br>jsonrpc-maven-verify-deps-titanium-mvn39-openjdk21<br>jsonrpc-maven-verify-manganese-mvn39-openjdk21<br>jsonrpc-maven-verify-titanium-mvn39-openjdk21<br>jsonrpc-release-merge-chromium<br>jsonrpc-release-merge-manganese<br>jsonrpc-release-merge-titanium<br>jsonrpc-validate-autorelease-chromium<br>jsonrpc-validate-autorelease-manganese<br>jsonrpc-validate-autorelease-titanium | 30 |
| l2switch | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | l2switch-csit-1node-host-scalability-daily-only-chromium<br>l2switch-csit-1node-host-scalability-daily-only-manganese<br>l2switch-csit-1node-host-scalability-daily-only-titanium<br>l2switch-csit-1node-scalability-all-chromium<br>l2switch-csit-1node-scalability-all-manganese<br>l2switch-csit-1node-scalability-all-titanium<br>l2switch-csit-1node-switch-all-chromium<br>l2switch-csit-1node-switch-all-manganese<br>l2switch-csit-1node-switch-all-titanium<br>l2switch-csit-verify-1node-switch<br>l2switch-maven-clm-1.0.x<br>l2switch-maven-clm-2.0.x<br>l2switch-maven-clm-master<br>l2switch-maven-merge-1.0.x<br>l2switch-maven-merge-2.0.x<br>l2switch-maven-merge-master<br>l2switch-maven-mri-stage-1.0.x<br>l2switch-maven-mri-stage-2.0.x<br>l2switch-maven-mri-stage-master<br>l2switch-maven-stage-1.0.x<br>l2switch-maven-stage-2.0.x<br>l2switch-maven-stage-master<br>l2switch-maven-verify-1.0.x-mvn39-openjdk21<br>l2switch-maven-verify-2.0.x-mvn39-openjdk21<br>l2switch-maven-verify-deps-1.0.x-mvn39-openjdk21<br>l2switch-maven-verify-deps-2.0.x-mvn39-openjdk21<br>l2switch-maven-verify-deps-master-mvn39-openjdk21<br>l2switch-maven-verify-master-mvn39-openjdk21<br>l2switch-release-merge-1.0.x<br>l2switch-release-merge-2.0.x<br>l2switch-release-merge-master | 31 |
| lispflowmapping | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | lispflowmapping-csit-1node-msmr-all-chromium<br>lispflowmapping-csit-1node-msmr-all-manganese<br>lispflowmapping-csit-1node-msmr-all-titanium<br>lispflowmapping-csit-3node-msmr-all-chromium<br>lispflowmapping-csit-3node-msmr-all-manganese<br>lispflowmapping-csit-3node-msmr-all-titanium<br>lispflowmapping-csit-verify-1node-msmr<br>lispflowmapping-distribution-check-chromium<br>lispflowmapping-distribution-check-manganese<br>lispflowmapping-distribution-check-titanium<br>lispflowmapping-maven-clm-chromium<br>lispflowmapping-maven-clm-manganese<br>lispflowmapping-maven-clm-titanium<br>lispflowmapping-maven-javadoc-publish-chromium-openjdk21<br>lispflowmapping-maven-javadoc-publish-manganese-openjdk21<br>lispflowmapping-maven-javadoc-publish-titanium-openjdk21<br>lispflowmapping-maven-javadoc-verify-chromium-openjdk21<br>lispflowmapping-maven-javadoc-verify-manganese-openjdk21<br>lispflowmapping-maven-javadoc-verify-titanium-openjdk21<br>lispflowmapping-maven-merge-chromium<br>lispflowmapping-maven-merge-manganese<br>lispflowmapping-maven-merge-titanium<br>lispflowmapping-maven-mri-stage-chromium<br>lispflowmapping-maven-mri-stage-manganese<br>lispflowmapping-maven-mri-stage-titanium<br>lispflowmapping-maven-stage-chromium<br>lispflowmapping-maven-stage-manganese<br>lispflowmapping-maven-stage-titanium<br>lispflowmapping-maven-verify-chromium-mvn39-openjdk21<br>lispflowmapping-maven-verify-deps-chromium-mvn39-openjdk21<br>lispflowmapping-maven-verify-deps-manganese-mvn39-openjdk21<br>lispflowmapping-maven-verify-deps-titanium-mvn39-openjdk21<br>lispflowmapping-maven-verify-manganese-mvn39-openjdk21<br>lispflowmapping-maven-verify-titanium-mvn39-openjdk21<br>lispflowmapping-validate-autorelease-chromium<br>lispflowmapping-validate-autorelease-manganese<br>lispflowmapping-validate-autorelease-titanium | 37 |
| mdsal | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | mdsal-csit-1node-bindingv1-only-titanium<br>mdsal-csit-1node-bindingv1-only-vanadium<br>mdsal-csit-3node-netty-replicate-only-titanium<br>mdsal-csit-3node-netty-replicate-only-vanadium<br>mdsal-maven-clm-14.0.x<br>mdsal-maven-clm-master<br>mdsal-maven-clm-vanadium<br>mdsal-maven-merge-14.0.x<br>mdsal-maven-merge-master<br>mdsal-maven-merge-vanadium<br>mdsal-maven-mri-stage-14.0.x<br>mdsal-maven-mri-stage-master<br>mdsal-maven-mri-stage-vanadium<br>mdsal-maven-stage-14.0.x<br>mdsal-maven-stage-master<br>mdsal-maven-stage-vanadium<br>mdsal-maven-verify-14.0.x-mvn39-openjdk21<br>mdsal-maven-verify-deps-14.0.x-mvn39-openjdk21<br>mdsal-maven-verify-deps-master-mvn39-openjdk21<br>mdsal-maven-verify-deps-vanadium-mvn39-openjdk21<br>mdsal-maven-verify-master-mvn39-openjdk21<br>mdsal-maven-verify-vanadium-mvn39-openjdk21<br>mdsal-release-merge-14.0.x<br>mdsal-release-merge-master<br>mdsal-release-merge-vanadium | 25 |
| netconf | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml<br>update-graph | 9 | netconf-csit-1node-callhome-only-titanium<br>netconf-csit-1node-callhome-only-vanadium<br>netconf-csit-1node-gate-callhome-only-titanium<br>netconf-csit-1node-gate-callhome-only-vanadium<br>netconf-csit-1node-gate-userfeatures-all-titanium<br>netconf-csit-1node-gate-userfeatures-all-vanadium<br>netconf-csit-1node-gate-userfeatures-netty-all-titanium<br>netconf-csit-1node-gate-userfeatures-netty-all-vanadium<br>netconf-csit-1node-scale-max-devices-only-titanium<br>netconf-csit-1node-scale-max-devices-only-vanadium<br>netconf-csit-1node-scale-only-titanium<br>netconf-csit-1node-scale-only-vanadium<br>netconf-csit-1node-userfeatures-all-titanium<br>netconf-csit-1node-userfeatures-all-vanadium<br>netconf-csit-1node-userfeatures-netty-all-titanium<br>netconf-csit-1node-userfeatures-netty-all-vanadium<br>netconf-csit-3node-clustering-only-titanium<br>netconf-csit-3node-clustering-only-vanadium<br>netconf-csit-3node-clustering-scale-only-titanium<br>netconf-csit-3node-clustering-scale-only-vanadium<br>netconf-distribution-mri-test-titanium<br>netconf-distribution-mri-test-vanadium<br>netconf-maven-clm-10.0.x<br>netconf-maven-clm-11.0.x<br>netconf-maven-clm-9.0.x<br>netconf-maven-clm-master<br>netconf-maven-merge-10.0.x<br>netconf-maven-merge-11.0.x<br>netconf-maven-merge-9.0.x<br>netconf-maven-merge-master<br>netconf-maven-mri-stage-10.0.x<br>netconf-maven-mri-stage-11.0.x<br>netconf-maven-mri-stage-9.0.x<br>netconf-maven-mri-stage-master<br>netconf-maven-stage-10.0.x<br>netconf-maven-stage-11.0.x<br>netconf-maven-stage-9.0.x<br>netconf-maven-stage-master<br>netconf-maven-verify-9.0.x-mvn39-openjdk21<br>netconf-maven-verify-deps-9.0.x-mvn39-openjdk21<br>netconf-maven-verify-deps-master-mvn39-openjdk21<br>netconf-maven-verify-master-mvn39-openjdk21<br>netconf-mri-patch-test-core-titanium<br>netconf-mri-patch-test-core-vanadium<br>netconf-release-merge-10.0.x<br>netconf-release-merge-11.0.x<br>netconf-release-merge-9.0.x<br>netconf-release-merge-master<br>netconf-tox-verify-10.0.x<br>netconf-tox-verify-11.0.x<br>netconf-tox-verify-9.0.x<br>netconf-tox-verify-master | 52 |
| odlparent | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | odlparent-maven-clm-14.3.x<br>odlparent-maven-clm-master<br>odlparent-maven-merge-14.3.x<br>odlparent-maven-merge-master<br>odlparent-maven-mri-stage-14.3.x<br>odlparent-maven-mri-stage-master<br>odlparent-maven-stage-14.3.x<br>odlparent-maven-stage-master<br>odlparent-maven-verify-14.3.x-mvn39-openjdk21<br>odlparent-maven-verify-deps-14.3.x-mvn39-openjdk21<br>odlparent-maven-verify-deps-master-mvn39-openjdk21<br>odlparent-maven-verify-master-mvn39-openjdk21<br>odlparent-release-merge-14.3.x<br>odlparent-release-merge-master<br>odlparent-tox-verify-14.3.x<br>odlparent-tox-verify-master | 16 |
| openflowplugin | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | openflowplugin-csit-1node-cbench-only-chromium<br>openflowplugin-csit-1node-cbench-only-manganese<br>openflowplugin-csit-1node-cbench-only-titanium<br>openflowplugin-csit-1node-flow-services-all-chromium<br>openflowplugin-csit-1node-flow-services-all-manganese<br>openflowplugin-csit-1node-flow-services-all-titanium<br>openflowplugin-csit-1node-gate-flow-services-all-chromium<br>openflowplugin-csit-1node-gate-flow-services-all-manganese<br>openflowplugin-csit-1node-gate-flow-services-all-titanium<br>openflowplugin-csit-1node-gate-perf-bulkomatic-only-chromium<br>openflowplugin-csit-1node-gate-perf-bulkomatic-only-manganese<br>openflowplugin-csit-1node-gate-perf-bulkomatic-only-titanium<br>openflowplugin-csit-1node-gate-perf-stats-collection-only-chromium<br>openflowplugin-csit-1node-gate-perf-stats-collection-only-manganese<br>openflowplugin-csit-1node-gate-perf-stats-collection-only-titanium<br>openflowplugin-csit-1node-gate-scale-only-chromium<br>openflowplugin-csit-1node-gate-scale-only-manganese<br>openflowplugin-csit-1node-gate-scale-only-titanium<br>openflowplugin-csit-1node-longevity-only-chromium<br>openflowplugin-csit-1node-longevity-only-manganese<br>openflowplugin-csit-1node-longevity-only-titanium<br>openflowplugin-csit-1node-perf-bulkomatic-only-chromium<br>openflowplugin-csit-1node-perf-bulkomatic-only-manganese<br>openflowplugin-csit-1node-perf-bulkomatic-only-titanium<br>openflowplugin-csit-1node-perf-stats-collection-only-chromium<br>openflowplugin-csit-1node-perf-stats-collection-only-manganese<br>openflowplugin-csit-1node-perf-stats-collection-only-titanium<br>openflowplugin-csit-1node-sanity-only-chromium<br>openflowplugin-csit-1node-sanity-only-manganese<br>openflowplugin-csit-1node-sanity-only-titanium<br>openflowplugin-csit-1node-scale-link-only-chromium<br>openflowplugin-csit-1node-scale-link-only-manganese<br>openflowplugin-csit-1node-scale-link-only-titanium<br>openflowplugin-csit-1node-scale-only-chromium<br>openflowplugin-csit-1node-scale-only-manganese<br>openflowplugin-csit-1node-scale-only-titanium<br>openflowplugin-csit-1node-scale-switch-only-chromium<br>openflowplugin-csit-1node-scale-switch-only-manganese<br>openflowplugin-csit-1node-scale-switch-only-titanium<br>openflowplugin-csit-3node-clustering-bulkomatic-only-chromium<br>openflowplugin-csit-3node-clustering-bulkomatic-only-manganese<br>openflowplugin-csit-3node-clustering-bulkomatic-only-titanium<br>openflowplugin-csit-3node-clustering-only-chromium<br>openflowplugin-csit-3node-clustering-only-manganese<br>openflowplugin-csit-3node-clustering-only-titanium<br>openflowplugin-csit-3node-clustering-perf-bulkomatic-only-chromium<br>openflowplugin-csit-3node-clustering-perf-bulkomatic-only-manganese<br>openflowplugin-csit-3node-clustering-perf-bulkomatic-only-titanium<br>openflowplugin-csit-3node-gate-clustering-bulkomatic-only-chromium<br>openflowplugin-csit-3node-gate-clustering-bulkomatic-only-manganese<br>openflowplugin-csit-3node-gate-clustering-bulkomatic-only-titanium<br>openflowplugin-csit-3node-gate-clustering-only-chromium<br>openflowplugin-csit-3node-gate-clustering-only-manganese<br>openflowplugin-csit-3node-gate-clustering-only-titanium<br>openflowplugin-csit-3node-gate-clustering-perf-bulkomatic-only-chromium<br>openflowplugin-csit-3node-gate-clustering-perf-bulkomatic-only-manganese<br>openflowplugin-csit-3node-gate-clustering-perf-bulkomatic-only-titanium<br>openflowplugin-csit-verify-1node-sanity<br>openflowplugin-maven-clm-chromium<br>openflowplugin-maven-clm-manganese<br>openflowplugin-maven-clm-titanium<br>openflowplugin-maven-javadoc-publish-chromium-openjdk21<br>openflowplugin-maven-javadoc-publish-manganese-openjdk21<br>openflowplugin-maven-javadoc-publish-titanium-openjdk21<br>openflowplugin-maven-javadoc-verify-chromium-openjdk21<br>openflowplugin-maven-javadoc-verify-manganese-openjdk21<br>openflowplugin-maven-javadoc-verify-titanium-openjdk21<br>openflowplugin-maven-merge-chromium<br>openflowplugin-maven-merge-manganese<br>openflowplugin-maven-merge-titanium<br>openflowplugin-maven-mri-stage-chromium<br>openflowplugin-maven-mri-stage-manganese<br>openflowplugin-maven-mri-stage-titanium<br>openflowplugin-maven-stage-chromium<br>openflowplugin-maven-stage-manganese<br>openflowplugin-maven-stage-titanium<br>openflowplugin-maven-verify-chromium-mvn39-openjdk21<br>openflowplugin-maven-verify-deps-chromium-mvn39-openjdk21<br>openflowplugin-maven-verify-deps-manganese-mvn39-openjdk21<br>openflowplugin-maven-verify-deps-titanium-mvn39-openjdk21<br>openflowplugin-maven-verify-manganese-mvn39-openjdk21<br>openflowplugin-maven-verify-titanium-mvn39-openjdk21<br>openflowplugin-patch-test-cbench-chromium<br>openflowplugin-patch-test-cbench-manganese<br>openflowplugin-patch-test-cbench-titanium<br>openflowplugin-patch-test-core-chromium<br>openflowplugin-patch-test-core-manganese<br>openflowplugin-patch-test-core-titanium<br>openflowplugin-release-merge-chromium<br>openflowplugin-release-merge-manganese<br>openflowplugin-release-merge-titanium | 91 |
| ovsdb | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | ovsdb-csit-1node-gate-southbound-all-chromium<br>ovsdb-csit-1node-gate-southbound-all-manganese<br>ovsdb-csit-1node-gate-southbound-all-titanium<br>ovsdb-csit-1node-upstream-southbound-all-chromium<br>ovsdb-csit-1node-upstream-southbound-all-manganese<br>ovsdb-csit-1node-upstream-southbound-all-titanium<br>ovsdb-csit-3node-gate-clustering-only-chromium<br>ovsdb-csit-3node-gate-clustering-only-manganese<br>ovsdb-csit-3node-gate-clustering-only-titanium<br>ovsdb-csit-3node-upstream-clustering-only-chromium<br>ovsdb-csit-3node-upstream-clustering-only-manganese<br>ovsdb-csit-3node-upstream-clustering-only-titanium<br>ovsdb-daily-full-integration-chromium<br>ovsdb-daily-full-integration-manganese<br>ovsdb-daily-full-integration-titanium<br>ovsdb-distribution-check-chromium<br>ovsdb-distribution-check-manganese<br>ovsdb-distribution-check-titanium<br>ovsdb-maven-clm-chromium<br>ovsdb-maven-clm-manganese<br>ovsdb-maven-clm-titanium<br>ovsdb-maven-javadoc-publish-chromium-openjdk21<br>ovsdb-maven-javadoc-publish-manganese-openjdk21<br>ovsdb-maven-javadoc-publish-titanium-openjdk21<br>ovsdb-maven-javadoc-verify-chromium-openjdk21<br>ovsdb-maven-javadoc-verify-manganese-openjdk21<br>ovsdb-maven-javadoc-verify-titanium-openjdk21<br>ovsdb-maven-merge-chromium<br>ovsdb-maven-merge-manganese<br>ovsdb-maven-merge-titanium<br>ovsdb-maven-mri-stage-chromium<br>ovsdb-maven-mri-stage-manganese<br>ovsdb-maven-mri-stage-titanium<br>ovsdb-maven-stage-chromium<br>ovsdb-maven-stage-manganese<br>ovsdb-maven-stage-titanium<br>ovsdb-maven-verify-chromium-mvn39-openjdk21<br>ovsdb-maven-verify-deps-chromium-mvn39-openjdk21<br>ovsdb-maven-verify-deps-manganese-mvn39-openjdk21<br>ovsdb-maven-verify-deps-titanium-mvn39-openjdk21<br>ovsdb-maven-verify-manganese-mvn39-openjdk21<br>ovsdb-maven-verify-titanium-mvn39-openjdk21<br>ovsdb-patch-test-core-chromium<br>ovsdb-patch-test-core-manganese<br>ovsdb-patch-test-core-titanium<br>ovsdb-validate-autorelease-chromium<br>ovsdb-validate-autorelease-manganese<br>ovsdb-validate-autorelease-titanium | 48 |
| releng/autorelease | call-github2gerrit.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 4 | autorelease-version-management-tox-verify-chromium<br>autorelease-version-management-tox-verify-manganese<br>autorelease-version-management-tox-verify-titanium | 3 |
| releng/builder | call-composed-github2gerrit.yaml<br>codeql<br>dependabot-updates<br>gerrit-ci-management-merge.yaml<br>gerrit-packer-merge-builder.yaml<br>gerrit-packer-merge-docker.yaml<br>gerrit-packer-merge-mininet.yaml<br>gerrit-packer-merge-robot.yaml<br>gerrit-verify.yaml<br>openstack-cron-cleanup.yaml | 10 | builder-info-yaml-verify<br>builder-jenkins-cfg-verify<br>builder-jenkins-sandbox-cleanup<br>builder-jjb-deploy-job<br>builder-openstack-cron | 5 |
| transportpce | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | transportpce-maven-clm-chromium<br>transportpce-maven-clm-titanium<br>transportpce-maven-clm-transportpce-master<br>transportpce-maven-merge-chromium<br>transportpce-maven-merge-titanium<br>transportpce-maven-merge-transportpce-master<br>transportpce-maven-mri-stage-chromium<br>transportpce-maven-mri-stage-titanium<br>transportpce-maven-mri-stage-transportpce-master<br>transportpce-maven-stage-chromium<br>transportpce-maven-stage-titanium<br>transportpce-maven-stage-transportpce-master<br>transportpce-maven-verify-chromium-mvn39-openjdk21<br>transportpce-maven-verify-deps-chromium-mvn39-openjdk21<br>transportpce-maven-verify-deps-titanium-mvn39-openjdk21<br>transportpce-maven-verify-deps-transportpce-master-mvn39-openjdk21<br>transportpce-maven-verify-titanium-mvn39-openjdk21<br>transportpce-maven-verify-transportpce-master-mvn39-openjdk21<br>transportpce-release-merge-chromium<br>transportpce-release-merge-titanium<br>transportpce-release-merge-transportpce-master<br>transportpce-tox-verify-chromium<br>transportpce-tox-verify-titanium<br>transportpce-tox-verify-transportpce-master | 24 |
| transportpce/models | codeql<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml | 3 | transportpce-models-maven-clm-chromium<br>transportpce-models-maven-clm-master<br>transportpce-models-maven-clm-titanium<br>transportpce-models-maven-merge-chromium<br>transportpce-models-maven-merge-master<br>transportpce-models-maven-merge-titanium<br>transportpce-models-maven-mri-stage-chromium<br>transportpce-models-maven-mri-stage-master<br>transportpce-models-maven-mri-stage-titanium<br>transportpce-models-maven-stage-chromium<br>transportpce-models-maven-stage-master<br>transportpce-models-maven-stage-titanium<br>transportpce-models-maven-verify-chromium-mvn39-openjdk21<br>transportpce-models-maven-verify-deps-chromium-mvn39-openjdk21<br>transportpce-models-maven-verify-deps-master-mvn39-openjdk21<br>transportpce-models-maven-verify-deps-titanium-mvn39-openjdk21<br>transportpce-models-maven-verify-master-mvn39-openjdk21<br>transportpce-models-maven-verify-titanium-mvn39-openjdk21 | 18 |
| yangtools | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge-stable.yaml<br>gerrit-maven-merge.yaml<br>gerrit-sonar.yaml<br>gerrit-verify.yaml | 8 | yangtools-csit-1node-system-only-chromium<br>yangtools-csit-1node-system-only-titanium<br>yangtools-csit-1node-system-only-vanadium<br>yangtools-maven-clm-chromium<br>yangtools-maven-clm-master<br>yangtools-maven-clm-titanium<br>yangtools-maven-merge-chromium<br>yangtools-maven-merge-master<br>yangtools-maven-merge-titanium<br>yangtools-maven-mri-stage-chromium<br>yangtools-maven-mri-stage-master<br>yangtools-maven-mri-stage-titanium<br>yangtools-maven-stage-chromium<br>yangtools-maven-stage-master<br>yangtools-maven-stage-titanium<br>yangtools-maven-verify-deps-titanium-mvn39-openjdk21<br>yangtools-maven-verify-titanium-mvn39-openjdk21<br>yangtools-release-merge-chromium<br>yangtools-release-merge-master<br>yangtools-release-merge-titanium | 20 |
| zzz-test-release |  | 0 | zzz-test-release-maven-stage-master | 1 |

**Total:** 25 repositories with CI/CD jobs

---
## Orphaned Jenkins Jobs

These Jenkins jobs are matched to archived or read-only Gerrit projects:

### By State

- **READ_ONLY:** 14 jobs

### Job Details

| Job Name | Matched Project | State | Match Score |
|----------|----------------|-------|-------------|
| integration-sanity-test-manganese | integration | READ_ONLY | 550% |
| integration-sanity-test-titanium | integration | READ_ONLY | 550% |
| integration-update-csit-tests-manganese | integration | READ_ONLY | 550% |
| integration-multipatch-test-titanium | integration | READ_ONLY | 550% |
| integration-sanity-test-chromium | integration | READ_ONLY | 550% |
| integration-patch-test-chromium | integration | READ_ONLY | 550% |
| integration-multipatch-test-manganese | integration | READ_ONLY | 550% |
| integration-update-csit-tests-titanium | integration | READ_ONLY | 550% |
| integration-update-csit-tests-chromium | integration | READ_ONLY | 550% |
| integration-patch-test-manganese | integration | READ_ONLY | 550% |
| integration-patch-test-titanium | integration | READ_ONLY | 550% |
| integration-multipatch-test-chromium | integration | READ_ONLY | 550% |
| integration-info-yaml-verify | integration | READ_ONLY | 550% |
| integration-merge-dashboard | integration | READ_ONLY | 550% |

**Total Orphaned Jobs:** 14

---
## Unattributed Jenkins Jobs


These jobs could not be matched to any active or archived repository. They may be infrastructure jobs, release jobs, build pipelines, or jobs that use naming conventions different from the repository names. Consider reviewing the job names and repository naming patterns to improve attribution.


**Total:** 108 unattributed jobs

### Job Details

| Job Name | Status | URL |
|----------|--------|-----|
| autorelease-branch-cut | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-branch-cut/) |
| autorelease-generate-release-notes-chromium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-generate-release-notes-chromium/) |
| autorelease-generate-release-notes-manganese | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-generate-release-notes-manganese/) |
| autorelease-generate-release-notes-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-generate-release-notes-titanium/) |
| autorelease-gerrit-branch-lock-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-gerrit-branch-lock-chromium/) |
| autorelease-gerrit-branch-lock-manganese | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-gerrit-branch-lock-manganese/) |
| autorelease-gerrit-branch-lock-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-gerrit-branch-lock-titanium/) |
| autorelease-info-yaml-verify | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-info-yaml-verify/) |
| autorelease-release-chromium-mvn39-openjdk21 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-release-chromium-mvn39-openjdk21/) |
| autorelease-release-manganese-mvn39-openjdk21 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-release-manganese-mvn39-openjdk21/) |
| autorelease-release-titanium-mvn39-openjdk21 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-release-titanium-mvn39-openjdk21/) |
| autorelease-tox-verify-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-tox-verify-chromium/) |
| autorelease-tox-verify-manganese | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-tox-verify-manganese/) |
| autorelease-tox-verify-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-tox-verify-titanium/) |
| autorelease-update-submodules-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-submodules-chromium/) |
| autorelease-update-submodules-manganese | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-submodules-manganese/) |
| autorelease-update-submodules-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-submodules-titanium/) |
| autorelease-update-validate-jobs-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-validate-jobs-chromium/) |
| autorelease-update-validate-jobs-manganese | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-validate-jobs-manganese/) |
| autorelease-update-validate-jobs-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-validate-jobs-titanium/) |
| autorelease-validate-autorelease-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-validate-autorelease-chromium/) |
| autorelease-validate-autorelease-manganese | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-validate-autorelease-manganese/) |
| autorelease-validate-autorelease-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-validate-autorelease-titanium/) |
| autorelease-version-bump-chromium-mvn39-openjdk21 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-version-bump-chromium-mvn39-openjdk21/) |
| autorelease-version-bump-manganese-mvn39-openjdk21 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-version-bump-manganese-mvn39-openjdk21/) |
| autorelease-version-bump-titanium-mvn39-openjdk21 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-version-bump-titanium-mvn39-openjdk21/) |
| builder-check-poms | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-check-poms/) |
| builder-copy-sandbox-logs | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-copy-sandbox-logs/) |
| builder-openstack-update-cloud-image | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-openstack-update-cloud-image/) |
| builder-packer-merge-centos-7-builder | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-7-builder/) |
| builder-packer-merge-centos-7-docker | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-7-docker/) |
| builder-packer-merge-centos-7-robot | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-7-robot/) |
| builder-packer-merge-centos-cs-8-builder | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-cs-8-builder/) |
| builder-packer-merge-centos-cs-8-robot | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-cs-8-robot/) |
| builder-packer-merge-centos-cs-9-builder | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-cs-9-builder/) |
| builder-packer-merge-centos-cs-9-robot | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-cs-9-robot/) |
| builder-packer-merge-ubuntu-18.04-docker | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-18.04-docker/) |
| builder-packer-merge-ubuntu-20.04-builder | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-20.04-builder/) |
| builder-packer-merge-ubuntu-20.04-docker | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-20.04-docker/) |
| builder-packer-merge-ubuntu-22.04-builder | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-22.04-builder/) |
| builder-packer-merge-ubuntu-22.04-docker | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-22.04-docker/) |
| builder-packer-merge-ubuntu-22.04-mininet-ovs-217 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-22.04-mininet-ovs-217/) |
| builder-packer-merge-ubuntu-22.04-robot | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-22.04-robot/) |
| builder-packer-merge-ubuntu-24.04-builder | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-24.04-builder/) |
| builder-packer-merge-ubuntu-24.04-mininet-ovs-217 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-24.04-mininet-ovs-217/) |
| builder-packer-merge-ubuntu-24.04-robot | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-24.04-robot/) |
| builder-packer-verify | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-verify/) |
| builder-tox-verify-master | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-tox-verify-master/) |
| builder-update-image-list | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-update-image-list/) |
| distribution-check-managed-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-check-managed-chromium/) |
| distribution-check-managed-manganese | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-check-managed-manganese/) |
| distribution-check-managed-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-check-managed-titanium/) |
| distribution-csit-1node-userfeatures-all-silicon | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-csit-1node-userfeatures-all-silicon/) |
| distribution-csit-managed-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-csit-managed-chromium/) |
| distribution-csit-managed-manganese | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-csit-managed-manganese/) |
| distribution-csit-managed-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-csit-managed-titanium/) |
| distribution-docker-release-merge-master | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-docker-release-merge-master/) |
| distribution-docker-release-verify-master | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-docker-release-verify-master/) |
| distribution-merge-managed-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-merge-managed-chromium/) |
| distribution-merge-managed-manganese | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-merge-managed-manganese/) |
| distribution-merge-managed-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-merge-managed-titanium/) |
| distribution-sanity-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-sanity-chromium/) |
| distribution-sanity-manganese | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-sanity-manganese/) |
| distribution-sanity-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-sanity-titanium/) |
| distribution-sonar | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-sonar/) |
| distribution-verify-managed-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-verify-managed-chromium/) |
| distribution-verify-managed-manganese | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-verify-managed-manganese/) |
| distribution-verify-managed-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-verify-managed-titanium/) |
| integration-info-yaml-verify | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-info-yaml-verify/) |
| integration-merge-dashboard | Success | [View Job](https://jenkins.opendaylight.org/releng/job/integration-merge-dashboard/) |
| integration-multipatch-test-chromium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-multipatch-test-chromium/) |
| integration-multipatch-test-manganese | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-multipatch-test-manganese/) |
| integration-multipatch-test-titanium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-multipatch-test-titanium/) |
| integration-patch-test-chromium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-patch-test-chromium/) |
| integration-patch-test-manganese | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-patch-test-manganese/) |
| integration-patch-test-titanium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-patch-test-titanium/) |
| integration-sanity-test-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/integration-sanity-test-chromium/) |
| integration-sanity-test-manganese | Unstable | [View Job](https://jenkins.opendaylight.org/releng/job/integration-sanity-test-manganese/) |
| integration-sanity-test-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/integration-sanity-test-titanium/) |
| integration-update-csit-tests-chromium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-update-csit-tests-chromium/) |
| integration-update-csit-tests-manganese | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-update-csit-tests-manganese/) |
| integration-update-csit-tests-titanium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-update-csit-tests-titanium/) |
| lf-infra-ci-workshop-tox-verify-any | Success | [View Job](https://jenkins.opendaylight.org/releng/job/lf-infra-ci-workshop-tox-verify-any/) |
| lf-infra-license-checker-tox-verify-any | Success | [View Job](https://jenkins.opendaylight.org/releng/job/lf-infra-license-checker-tox-verify-any/) |
| lf-odl-release-docker-hub | Success | [View Job](https://jenkins.opendaylight.org/releng/job/lf-odl-release-docker-hub/) |
| lf-pipelines-verify | Aborted | [View Job](https://jenkins.opendaylight.org/releng/job/lf-pipelines-verify/) |
| lf-test-release-tox-verify-tox-verify-any | Success | [View Job](https://jenkins.opendaylight.org/releng/job/lf-test-release-tox-verify-tox-verify-any/) |
| ODL-pipelines | Unknown | [View Job](https://jenkins.opendaylight.org/releng/job/ODL-pipelines/) |
| packaging-chromium-merge-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-chromium-merge-helm/) |
| packaging-chromium-release-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-chromium-release-helm/) |
| packaging-chromium-update-helm-weekly | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-chromium-update-helm-weekly/) |
| packaging-chromium-verify-helm3.5 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-chromium-verify-helm3.5/) |
| packaging-chromium-verify-helm3.7 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-chromium-verify-helm3.7/) |
| packaging-docker-merge-phosphorus | Failed | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-docker-merge-phosphorus/) |
| packaging-docker-verify-phosphorus | Success | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-docker-verify-phosphorus/) |
| packaging-k8s-odl-deploy-test | Failed | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-k8s-odl-deploy-test/) |
| packaging-manganese-merge-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-manganese-merge-helm/) |
| packaging-manganese-release-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-manganese-release-helm/) |
| packaging-manganese-update-helm-weekly | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-manganese-update-helm-weekly/) |
| packaging-manganese-verify-helm3.5 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-manganese-verify-helm3.5/) |
| packaging-manganese-verify-helm3.7 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-manganese-verify-helm3.7/) |
| packaging-release-merge-master | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-release-merge-master/) |
| packaging-release-verify-master | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-release-verify-master/) |
| packaging-titanium-merge-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-titanium-merge-helm/) |
| packaging-titanium-release-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-titanium-release-helm/) |
| packaging-titanium-update-helm-weekly | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-titanium-update-helm-weekly/) |
| packaging-titanium-verify-helm3.5 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-titanium-verify-helm3.5/) |
| packaging-titanium-verify-helm3.7 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-titanium-verify-helm3.7/) |

---
## 📋 Committer INFO.yaml Report

## 📋 Committer INFO.yaml Report

This report shows project information from INFO.yaml files, including lifecycle state, project leads, and committer activity status.

| Project | Creation Date | Lifecycle State | Project Lead | Committers |
|---------|---------------|-----------------|--------------|------------|
| <a href="https://jira.opendaylight.org/projects/" target="_blank">.github</a> | 2023-11-7 | Incubation | <span style="color: gray;" title="Unknown activity status">Anil Belur</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Andrew Grimberg</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Guillaume Lambert</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Robert Varga</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Sangwook Ha</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Venkatrangan Govindarajan</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">aaa</a> | 2014-05-15 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Mohamed ElSerngawy</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">alt_datastores</a> | 2019-04-04 | Incubation | <span style="color: gray;" title="Unknown activity status">Michael Vorburger</span> | <span style="color: gray;" title="Unknown activity status">Anil Belur</span><br><span style="color: gray;" title="Unknown activity status">Jie Han</span><br><span style="color: gray;" title="Unknown activity status">Quan Xiong</span><br><span style="color: gray;" title="Unknown activity status">li jiansong</span><br><span style="color: gray;" title="Unknown activity status">Guobiao Mo</span><br><span style="color: gray;" title="Unknown activity status">Zhang Min</span><br><span style="color: gray;" title="Unknown activity status">Kaiwen Jin</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">archetypes</a> | 2018-02-27 | Incubation | <span style="color: gray;" title="Unknown activity status">Michael Vorburger</span> | <span style="color: gray;" title="Unknown activity status">Stephen Kitt</span><br><span style="color: gray;" title="Unknown activity status">Tom Pantelis</span><br><span style="color: gray;" title="Unknown activity status">Sam Hague</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">bgpcep</a> | 2013-07-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Claudio David Gasparini</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Dana Kutenicsova</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ajay Lele</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Olivier Dugeon</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">bier</a> | 22-06-2017 | Incubation | <span style="color: gray;" title="Unknown activity status">Quan Xiong</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">coe</a> | 2017-01-05 | Incubation | <span style="color: gray;" title="Unknown activity status">Faseela K</span> | <span style="color: gray;" title="Unknown activity status">Sam Hague</span><br><span style="color: gray;" title="Unknown activity status">Isaku Yamahata</span><br><span style="color: gray;" title="Unknown activity status">Yi Yang</span><br><span style="color: gray;" title="Unknown activity status">Shai Amir</span><br><span style="color: gray;" title="Unknown activity status">Mohamed ElSerngawy</span><br><span style="color: gray;" title="Unknown activity status">Andre Fredette</span><br><span style="color: gray;" title="Unknown activity status">Frederick Kautz</span><br><span style="color: gray;" title="Unknown activity status">Prem Sankar G</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">controller</a> | 2015-01-08 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Stephen Kitt</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ed Warnicke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Michael Vorburger</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Vishnoi</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">daexim</a> | 2016-10-13 | Incubation | <span style="color: gray;" title="Unknown activity status">Shaleen Saxena</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Anton Ivanov</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Michael Vorburger</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">sreekalyan devaraj</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Balaji Varadaraju</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ajay Lele</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Richard Kosegi</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">detnet</a> | 2018-12-13 | Incubation | <span style="color: gray;" title="Unknown activity status">Quan Xiong</span> | <span style="color: gray;" title="Unknown activity status">Anil Belur</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">dluxapps</a> | 2016-10-27 | Incubation | <span style="color: gray;" title="Unknown activity status">Daniel Malachovsky</span> | <span style="color: gray;" title="Unknown activity status">Stanislav Jamrich</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">docs</a> | 2014-03-26 | Incubation | <span style="color: gray;" title="Unknown activity status">Ivan Hraško</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Guillaume Lambert</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha (zxiiro)</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Daniel Farrell</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">genius</a> | 2016-03-24 | Incubation | <span style="color: gray;" title="Unknown activity status">Hema Gopalakrishnan</span> | <span style="color: gray;" title="Unknown activity status">Faseela K</span><br><span style="color: gray;" title="Unknown activity status">Chetan Arakere Gowdru</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">gnmi</a> | 2025-10-25 | Incubation | <span style="color: gray;" title="Unknown activity status">Ivan Hraško</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">groupbasedpolicy</a> | 2014-03-23 | Incubation | <span style="color: gray;" title="Unknown activity status">Michal Cmarada</span> | <span style="color: gray;" title="Unknown activity status">Keith Burns</span><br><span style="color: gray;" title="Unknown activity status">Rob Adams</span><br><span style="color: gray;" title="Unknown activity status">Tomas Cechvala</span><br><span style="color: gray;" title="Unknown activity status">Martin Sunal</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">honeycomb_vbd</a> | 2016-03-17 | Incubation | <span style="color: gray;" title="Unknown activity status">Michal Cmarada</span> | <span style="color: gray;" title="Unknown activity status">Ed Warnicke</span><br><span style="color: gray;" title="Unknown activity status">Daniel Malachovsky</span><br><span style="color: gray;" title="Unknown activity status">Marek Gradzki</span><br><span style="color: gray;" title="Unknown activity status">Robert Varga</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">ietf</a> | 2025-09-01 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jie Han</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">infrautils</a> | 2016-03-17 | Incubation | <span style="color: gray;" title="Unknown activity status">Faseela K</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Robert Varga</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Michael Vorburger</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">integration</a> | 2015-08-20 | Incubation | <span style="color: gray;" title="Unknown activity status">Luis Gomez</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha (zxiiro)</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Belur</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">integration_packaging</a> | 2015-08-20 | Incubation | <span style="color: gray;" title="Unknown activity status">Anil Belur</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Jamo Luhrsen</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Thanh Ha (zxiiro)</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Tim Rozet</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Daniel Farrell</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">integration_test</a> | 2015-08-20 | Incubation | <span style="color: gray;" title="Unknown activity status">Venkatrangan Govindarajan (Rangan)</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Sangwook Ha</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tomas Cere</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">jsonrpc</a> | 2016-04-21 | Incubation | <span style="color: gray;" title="Unknown activity status">Anton Ivanov</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">David Spence</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Shaleen Saxena</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Richard Kosegi</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">l2switch</a> | 2014-05-15 | Incubation | <span style="color: gray;" title="Unknown activity status">Hema Gopalakrishnan</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Sai MarapaReddy</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Evan Zeller</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Belur</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Robert Varga</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Abhijit Kumbhare</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Faseela K</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Venkatrangan Govindarajan</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tejas Nevrekar</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Balaji Varadaraju</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Arunprakash D</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">lispflowmapping</a> | 2013-07-13 | Incubation | <span style="color: gray;" title="Unknown activity status">Lori Jakab</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Florin Coras</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vina Ermagan</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">mdsal</a> | 2014-04-17 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jie Han</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">nemo</a> | 2015-05-08 | Incubation | <span style="color: gray;" title="Unknown activity status">A H</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">netconf</a> | 2020-06-25 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Tomáš Cére</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ivan Hraško</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">netvirt</a> | 2020-06-25 | Incubation | <span style="color: gray;" title="Unknown activity status">Karthikeyan Krishnan</span> | <span style="color: gray;" title="Unknown activity status">Stephen Kitt</span><br><span style="color: gray;" title="Unknown activity status">Chetan Arakere Gowdru</span><br><span style="color: gray;" title="Unknown activity status">Shashidhar Raja</span><br><span style="color: gray;" title="Unknown activity status">Manu B</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">neutron</a> | 2015-02-12 | Incubation | <span style="color: gray;" title="Unknown activity status">Achuth Maniyedath</span> | <span style="color: gray;" title="Unknown activity status">Karthikeyan Krishnan</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">odlguice</a> | 2020-03-19 | Incubation | <span style="color: gray;" title="Unknown activity status">Tejas Nevrekar</span> | <span style="color: gray;" title="Unknown activity status">Jamo Luhrsen</span><br><span style="color: gray;" title="Unknown activity status">Ravi Sankar</span><br><span style="color: gray;" title="Unknown activity status">Nikhil Soni</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">odlmicro</a> | 2020-03-19 | Incubation | <span style="color: gray;" title="Unknown activity status">Tejas Nevrekar</span> | <span style="color: gray;" title="Unknown activity status">Jamo Luhrsen</span><br><span style="color: gray;" title="Unknown activity status">Dhiman Ghosh</span><br><span style="color: gray;" title="Unknown activity status">Ravi Sankar</span><br><span style="color: gray;" title="Unknown activity status">Nikhil Soni</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">odlparent</a> | 2014-04-24 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Stephen Kitt</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Michael Vorburger</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">odlsaf</a> | 2020-20-04 | Incubation | <span style="color: gray;" title="Unknown activity status">Prem Sankar Gopannan</span> | <span style="color: gray;" title="Unknown activity status">Richard Kosegi</span><br><span style="color: gray;" title="Unknown activity status">Kanagasundaram  K</span><br><span style="color: gray;" title="Unknown activity status">Pravin Kumar Damodaran</span><br><span style="color: gray;" title="Unknown activity status">Mahesh Lokhande</span><br><span style="color: gray;" title="Unknown activity status">Jeff Hartley</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">odltools</a> | 2020-06-25 | Incubation | <span style="color: gray;" title="Unknown activity status">Tim Rozet</span> | <span style="color: gray;" title="Unknown activity status">Sam Hague</span><br><span style="color: gray;" title="Unknown activity status">Jamo Luhrsen</span><br><span style="color: gray;" title="Unknown activity status">Hema Gopalakrishnan</span><br><span style="color: gray;" title="Unknown activity status">Vishal Thapar</span><br><span style="color: gray;" title="Unknown activity status">Faseela K</span><br><span style="color: gray;" title="Unknown activity status">Deepthi V V</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">of_config</a> | 2015-08-27 | Incubation | <span style="color: gray;" title="Unknown activity status">WEI MENG</span> | <span style="color: gray;" title="Unknown activity status">ANANTHA RAMAIAH</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">openflowplugin</a> | 2013-07-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Sangwook Ha</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Gobinath Suganthan</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Robert Varga</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">opflex</a> | 2014-05-02 | Incubation | <span style="color: gray;" title="Unknown activity status">Tom Flynn</span> | <span style="color: gray;" title="Unknown activity status">Rob Adams</span><br><span style="color: gray;" title="Unknown activity status">Amit Bose</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">ovsdb</a> | 2013-07-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Chetan Arakere Gowdru</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Sam Hague</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Stephen Kitt</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Vishnoi</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vishal Thapar</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">p4plugin</a> | 2017-06-22 | Incubation | <span style="color: gray;" title="Unknown activity status">Ding Rui</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">plastic</a> | 2019-11-01 | Incubation | <span style="color: gray;" title="Unknown activity status">Allan Clarke</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">releng_autorelease</a> | 2015-01-08 | Incubation | <span style="color: gray;" title="Unknown activity status">Anil Belur</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">A H</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha (zxiiro)</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Kit Lou</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Sam Hague</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">releng_builder</a> | 2014-10-22 | Incubation | <span style="color: gray;" title="Unknown activity status">Anil Belur</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Andrew Grimberg</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Guillaume Lambert</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Robert Varga</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Sangwook Ha</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Venkatrangan Govindarajan</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">serviceutils</a> | 2018-06-14 | Incubation | <span style="color: gray;" title="Unknown activity status">Faseela K</span> | <span style="color: gray;" title="Unknown activity status">Sam Hague</span><br><span style="color: gray;" title="Unknown activity status">Michael Vorburger</span><br><span style="color: gray;" title="Unknown activity status">Vishal Thapar</span><br><span style="color: gray;" title="Unknown activity status">David Suárez Fuentes</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">sfc</a> |  | Incubation | <span style="color: gray;" title="Unknown activity status">Brady Johnson</span> | <span style="color: gray;" title="Unknown activity status">Yi Yang</span><br><span style="color: gray;" title="Unknown activity status">Reinaldo Penno</span><br><span style="color: gray;" title="Unknown activity status">Vinayak Joshi</span><br><span style="color: gray;" title="Unknown activity status">Jaime Caamaño Ruiz</span><br><span style="color: gray;" title="Unknown activity status">David Suárez Fuentes</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">snmp4sdn</a> | 2013-08-15 | Incubation | <span style="color: gray;" title="Unknown activity status">Christine Hsieh</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">sxp</a> | 2014-09-12 | Incubation | <span style="color: gray;" title="Unknown activity status">Ivan Hrasko</span> | <span style="color: gray;" title="Unknown activity status">Martin Dindoffer</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">telemetry</a> | 2018-03-14 | Incubation | <span style="color: gray;" title="Unknown activity status">wang senxiao</span> | <span style="color: gray;" title="Unknown activity status">Ding Rui</span><br><span style="color: gray;" title="Unknown activity status">Wang Senxiao</span><br><span style="color: gray;" title="Unknown activity status">huan linying</span><br><span style="color: gray;" title="Unknown activity status">li jiansong</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">transportpce</a> | 2016-05-26 | Incubation | <span style="color: gray;" title="Unknown activity status">Gilles Thouenon</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Christophe Betoule</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Balagangadhar Bathula</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Guillaume Lambert</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Shweta Vachhani</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Cédric Ollivier</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">transportpce_models</a> | 2022-08-12 | Incubation | <span style="color: gray;" title="Unknown activity status">Gilles Thouenon</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Christophe Betoule</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Balagangadhar Bathula</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Guillaume Lambert</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Shweta Vachhani</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Cedric Ollivier</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">tsdr</a> | 2014-12-11 | Incubation | <span style="color: gray;" title="Unknown activity status">Scott Melton</span> | <span style="color: gray;" title="Unknown activity status">Syed B.  Ahmed</span><br><span style="color: gray;" title="Unknown activity status">Tom Pantelis</span><br><span style="color: gray;" title="Unknown activity status">YuLing Chen</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">unimgr</a> | 2015-08-13 | Incubation | <span style="color: gray;" title="Unknown activity status">Donald Hunter</span> | <span style="color: gray;" title="Unknown activity status">Bartosz Michalik</span><br><span style="color: gray;" title="Unknown activity status">Mohamed ElSerngawy</span><br><span style="color: gray;" title="Unknown activity status">Gabriel Robitaille-Montpetit</span><br><span style="color: gray;" title="Unknown activity status">Mahesh Jethanandani</span><br><span style="color: gray;" title="Unknown activity status">Santanu De</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">yangtools</a> | 2013-07-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | None |


---

## 📊 INFO.yaml Lifecycle State Summary

### Lifecycle State Summary

| Lifecycle State | Gerrit Project Count | Percentage |
|----------------|---------------------|------------|
| Incubation | 52 | 100.0% |

**Total Projects:** 52
---

---*Generated with ❤️ by Release Engineering*