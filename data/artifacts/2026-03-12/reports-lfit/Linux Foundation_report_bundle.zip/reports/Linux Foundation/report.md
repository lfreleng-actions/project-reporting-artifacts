# 📊 GitHub Project Analysis Report: Linux Foundation

**Generated:** 2026-03-12 07:18:43 UTC
**Schema Version:** 1.5.0

---## Table of Contents

- [Global Summary](#summary)
- [Gerrit Projects](#repositories)
- [Top Contributors](#contributors)
- [Top Organizations](#organizations)
- [Repository Feature Matrix](#features)
- [Deployed CI/CD Jobs](#workflows)

---

## 📈 Global Summary

**✅ Current** commits within last 365 days

**☑️ Active** commits between 365-1095 days

**🛑 Inactive** no commits in 1095+ days

| Metric | Count | Percentage |
| --- | --- | --- |
| Total Repositories | 35 | 100% |
| Current Repositories | 21 | 60.0% |
| Active Repositories | 5 | 14.3% |
| Inactive Repositories | 9 | 25.7% |
| No Apparent Commits | 0 | 0.0% |
| Total Commits | 7.8K | - |
| Total Lines of Code | 448.6K | - |

---
## 🏢 Top Organizations

The data presented in the table below covers the past 365 days.

**Organizations Found:** 37

| Rank | Organization | Contributors | Commits | LOC | Δ LOC | Avg LOC/Commit | Unique Repositories |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | linuxfoundation.org | 31 | 400 | +220959 | 224292 | +544 | 35 |
| 2 | github.com | 1 | 34 | +70 | 140 | 0 | 2 |
| 3 | highstreet-technologies.com | 1 | 2 | +103 | 103 | +51 | 1 |
| 4 | samsung.com | 3 | 1 | +44 | 44 | +44 | 1 |
| 5 | t-mobile.pl | 2 | 1 | +45 | 45 | +45 | 1 |
| 6 | att.com | 8 | 0 | 0 | 0 | 0 | 5 |
| 7 | bell.ca | 1 | 0 | 0 | 0 | 0 | 1 |
| 8 | chinamobile.com | 2 | 0 | 0 | 0 | 0 | 1 |
| 9 | cisco.com | 1 | 0 | 0 | 0 | 0 | 2 |
| 10 | colindixon.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 11 | enea.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 12 | ensicaen.fr | 1 | 0 | 0 | 0 | 0 | 1 |
| 13 | ericsson.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 14 | est.tech | 3 | 0 | 0 | 0 | 0 | 1 |
| 15 | gmail.com | 13 | 0 | 0 | 0 | 0 | 21 |
| 16 | hcl.com | 2 | 0 | 0 | 0 | 0 | 1 |
| 17 | hpe.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 18 | hq.sk | 1 | 0 | 0 | 0 | 0 | 2 |
| 19 | huawei.com | 2 | 0 | 0 | 0 | 0 | 1 |
| 20 | intel.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 21 | intracom-telecom.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 22 | linux.com | 1 | 0 | 0 | 0 | 0 | 9 |
| 23 | navy.mil | 3 | 0 | 0 | 0 | 0 | 1 |
| 24 | nokia.com | 3 | 0 | 0 | 0 | 0 | 1 |
| 25 | opennetworking.org | 1 | 0 | 0 | 0 | 0 | 1 |
| 26 | orange.com | 5 | 0 | 0 | 0 | 0 | 4 |
| 27 | pantheon.tech | 1 | 0 | 0 | 0 | 0 | 1 |
| 28 | protonmail.ch | 1 | 0 | 0 | 0 | 0 | 1 |
| 29 | redhat.com | 4 | 0 | 0 | 0 | 0 | 3 |
| 30 | schweflinghaus.de | 1 | 0 | 0 | 0 | 0 | 1 |

---
## 👥 Top Contributors

The data presented in the table below covers the past 365 days.

**Contributors Found:** 106

| Rank | Contributor | Commits | LOC | Δ LOC | Avg LOC/Commit | Repositories | Organization |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Anil Belur | 128 | +4184 | 5234 | +24 | 23 | linuxfoundation.org |
| 2 | lf-jobbuilder | 114 | +1416 | 2495 | +2 | 1 | linuxfoundation.org |
| 3 | Matthew Watkins | 109 | +214251 | 215234 | +1956 | 10 | linuxfoundation.org |
| 4 | dependabot[bot] | 34 | +70 | 140 | 0 | 2 | github.com |
| 5 | Andrew Grimberg | 21 | +34 | 51 | 0 | 29 | linuxfoundation.org |
| 6 | Eric Ball | 17 | +176 | 312 | +2 | 16 | linuxfoundation.org |
| 7 | Kevin Sandi | 9 | +268 | 335 | +22 | 5 | linuxfoundation.org |
| 8 | Vanessa Valderrama | 2 | +630 | 631 | +314 | 6 | linuxfoundation.org |
| 9 | alex.stancu | 2 | +103 | 103 | +51 | 1 | highstreet-technologies.com |
| 10 | Marek Szwalkiewicz | 1 | +45 | 45 | +45 | 1 | t-mobile.pl |
| 11 | Subhash Kumar Singh | 1 | +44 | 44 | +44 | 1 | samsung.com |
| 12 | Alexandru Avadanii | 0 | 0 | 0 | 0 | 1 | enea.com |
| 13 | Anil Belur | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 14 | Aric Gardner | 0 | 0 | 0 | 0 | 11 | linuxfoundation.org |
| 15 | Ayush | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 16 | Bengt Thuree | 0 | 0 | 0 | 0 | 7 | linuxfoundation.org |
| 17 | Bruno Sakoto | 0 | 0 | 0 | 0 | 1 | bell.ca |
| 18 | C.J. Collier | 0 | 0 | 0 | 0 | 1 | linuxfoundation.org |
| 19 | Chandra Dasari | 0 | 0 | 0 | 0 | 1 | linuxfoundation.org |
| 20 | Chau Do | 0 | 0 | 0 | 0 | 1 | navy.mil |
| 21 | Christopher Lott (cl778h) | 0 | 0 | 0 | 0 | 1 | att.com |
| 22 | Claudio D. Gasparini | 0 | 0 | 0 | 0 | 1 | att.com |
| 23 | Claudio D. Gasparini | 0 | 0 | 0 | 0 | 1 | pantheon.tech |
| 24 | Colin Dixon | 0 | 0 | 0 | 0 | 1 | colindixon.com |
| 25 | Cédric Ollivier | 0 | 0 | 0 | 0 | 1 | orange.com |
| 26 | DW Talton | 0 | 0 | 0 | 0 | 4 | linuxfoundation.org |
| 27 | Dan Timoney | 0 | 0 | 0 | 0 | 1 | att.com |
| 28 | Daniel Farrell | 0 | 0 | 0 | 0 | 2 | redhat.com |
| 29 | Daniel Farrell | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 30 | Daniel Pono Takamori | 0 | 0 | 0 | 0 | 4 | linuxfoundation.org |

---
## 📊 Repositories

| Repository | Commits | LOC | Contributors | Days Inactive | Last Commit Date | Status |
| --- | --- | --- | --- | --- | --- | --- |
| [releng/info-master](https://github.com/gerrit.linuxfoundation.org/releng/info-master) | 3706 | +1704 | 7 | 5 | 2026-03-06 | ✅ |
| [releng/global-jjb](https://github.com/gerrit.linuxfoundation.org/releng/global-jjb) | 1567 | +1196 | 5 | 0 | 2026-03-11 | ✅ |
| [releng/lftools](https://github.com/gerrit.linuxfoundation.org/releng/lftools) | 702 | +1269 | 4 | 9 | 2026-03-03 | ✅ |
| [releng/docs](https://github.com/gerrit.linuxfoundation.org/releng/docs) | 362 | +43 | 3 | 205 | 2025-08-18 | ✅ |
| [releng/common-packer](https://github.com/gerrit.linuxfoundation.org/releng/common-packer) | 293 | +1659 | 4 | 63 | 2026-01-07 | ✅ |
| [sandbox](https://github.com/gerrit.linuxfoundation.org/sandbox) | 203 | +212847 | 3 | 1 | 2026-03-10 | ✅ |
| [releng/docs-conf](https://github.com/gerrit.linuxfoundation.org/releng/docs-conf) | 143 | +209 | 2 | 21 | 2026-02-18 | ✅ |
| [releng/gerrit_to_platform](https://github.com/gerrit.linuxfoundation.org/releng/gerrit_to_platform) | 139 | +849 | 5 | 35 | 2026-02-04 | ✅ |
| [releng](https://github.com/gerrit.linuxfoundation.org/releng) | 109 | 0 | 0 | 736 | 2024-03-05 | ☑️ |
| [ansible/roles](https://github.com/gerrit.linuxfoundation.org/ansible/roles) | 68 | +24 | 1 | 61 | 2026-01-10 | ✅ |
| [ansible/roles/lf-recommended-tools](https://github.com/gerrit.linuxfoundation.org/ansible/roles/lf-recommended-tools) | 62 | +158 | 2 | 63 | 2026-01-08 | ✅ |
| [ansible/roles/java-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/java-install) | 55 | +152 | 2 | 90 | 2025-12-12 | ✅ |
| [releng/ci-workshop](https://github.com/gerrit.linuxfoundation.org/releng/ci-workshop) | 47 | 0 | 0 | 1285 | 2022-09-03 | 🛑 |
| [ansible/roles/python-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/python-install) | 46 | +174 | 2 | 81 | 2025-12-21 | ✅ |
| [ansible/roles/puppet-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/puppet-install) | 34 | +171 | 2 | 62 | 2026-01-09 | ✅ |
| [ansible/roles/system-update](https://github.com/gerrit.linuxfoundation.org/ansible/roles/system-update) | 33 | +64 | 1 | 73 | 2025-12-29 | ✅ |
| [ansible/roles/lf-dev-libs](https://github.com/gerrit.linuxfoundation.org/ansible/roles/lf-dev-libs) | 33 | +160 | 1 | 86 | 2025-12-16 | ✅ |
| [ansible/roles/docker-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/docker-install) | 29 | +87 | 1 | 63 | 2026-01-08 | ✅ |
| [ansible/roles/haveged-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/haveged-install) | 25 | +94 | 1 | 86 | 2025-12-16 | ✅ |
| [releng/pipelines](https://github.com/gerrit.linuxfoundation.org/releng/pipelines) | 24 | 0 | 0 | 1312 | 2022-08-08 | 🛑 |
| [ansible/roles/shellcheck-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/shellcheck-install) | 23 | +98 | 1 | 86 | 2025-12-16 | ✅ |
| [ansible/roles/packer-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/packer-install) | 21 | +92 | 1 | 86 | 2025-12-16 | ✅ |
| [puppet/modules/mailman3](https://github.com/gerrit.linuxfoundation.org/puppet/modules/mailman3) | 21 | 0 | 0 | 3542 | 2016-06-29 | 🛑 |
| [ansible/roles/sysstat-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/sysstat-install) | 16 | +60 | 1 | 86 | 2025-12-15 | ✅ |
| [ansible/roles/mono-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/mono-install) | 15 | +111 | 1 | 86 | 2025-12-16 | ✅ |
| [lfn/process](https://github.com/gerrit.linuxfoundation.org/lfn/process) | 13 | 0 | 0 | 2833 | 2018-06-08 | 🛑 |
| [ansible/roles/protobuf-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/protobuf-install) | 12 | 0 | 0 | 504 | 2024-10-24 | ☑️ |
| [releng/python-one-password](https://github.com/gerrit.linuxfoundation.org/releng/python-one-password) | 9 | 0 | 0 | 904 | 2023-09-19 | ☑️ |
| [puppet/modules/gce](https://github.com/gerrit.linuxfoundation.org/puppet/modules/gce) | 5 | 0 | 0 | 3324 | 2017-02-02 | 🛑 |
| [releng/license-checker](https://github.com/gerrit.linuxfoundation.org/releng/license-checker) | 4 | 0 | 0 | 2840 | 2018-06-01 | 🛑 |
| [releng/nexus-upload](https://github.com/gerrit.linuxfoundation.org/releng/nexus-upload) | 4 | 0 | 0 | 650 | 2024-05-30 | ☑️ |
| [releng/sigul-docker](https://github.com/gerrit.linuxfoundation.org/releng/sigul-docker) | 3 | 0 | 0 | 846 | 2023-11-16 | ☑️ |
| [clav2test/icla-and-ccla-project](https://github.com/gerrit.linuxfoundation.org/clav2test/icla-and-ccla-project) | 2 | 0 | 0 | 1821 | 2021-03-16 | 🛑 |
| [clav2test/ccla-only-project](https://github.com/gerrit.linuxfoundation.org/clav2test/ccla-only-project) | 1 | 0 | 0 | 2624 | 2019-01-03 | 🛑 |
| [sandbox-info-master](https://github.com/gerrit.linuxfoundation.org/sandbox-info-master) | 1 | 0 | 0 | 1995 | 2020-09-24 | 🛑 |

**Total:** 35 repositories

---
## 🔧 Gerrit Project Feature Matrix

| Gerrit Project | Primary Type | Other Types | Dependabot | Pre-commit | ReadTheDocs | .gitreview | G2G | Status |
|----------------|--------------|-------------|------------|------------|-------------|------------|-----|--------|
| ansible/roles/mono-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/docker-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/lf-dev-libs | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/lf-recommended-tools | Python | Shell | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/java-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/protobuf-install | Shell |  | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| ansible/roles/packer-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/haveged-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| puppet/modules/gce | Ruby | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/roles/shellcheck-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/puppet-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/system-update | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/python-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/sysstat-install | Python | Shell | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| puppet/modules/mailman3 | Ruby | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| clav2test/ccla-only-project | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| clav2test/icla-and-ccla-project | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| lfn/process | Python |  | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| releng/ci-workshop | Groovy | Dockerfile, Shell | ❌ | ✅ | ❌ | ✅ | ❌ | 🛑 |
| releng/common-packer | HCL | Python, Shell | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ |
| releng/docs-conf | Python |  | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ |
| releng/docs | Python | Shell, HTML, CSS | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ |
| releng/gerrit_to_platform | Python |  | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| releng/license-checker | Go |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| releng/nexus-upload | Shell |  | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| releng/pipelines | Groovy | Java/Gradle, Python, Shell, HTML | ❌ | ✅ | ✅ | ✅ | ❌ | 🛑 |
| releng/sigul-docker | Dockerfile |  | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| releng/python-one-password | Python |  | ❌ | ✅ | ✅ | ✅ | ❌ | ☑️ |
| sandbox-info-master | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| releng/global-jjb | Shell | Python, Groovy, HTML | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ |
| releng/lftools | Python | HTML | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ |
| ansible/roles | Shell |  | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| releng/info-master | N/A |  | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| sandbox | Java/Maven | JavaScript, TypeScript, Python, Shell, Groovy, HTML, CSS | ✅ | ❌ | ✅ | ✅ | ❌ | ✅ |
| releng | Shell | Python, Go, Groovy, HTML, CSS, HCL | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |

---
## 🏁 Deployed CI/CD Jobs

**Total GitHub workflows:** 51

| Gerrit Project | GitHub Workflows | Workflow Count |
|----------------|-------------------|----------------|
| ansible/roles/docker-install | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/haveged-install | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/java-install | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/lf-dev-libs | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/lf-recommended-tools | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/mono-install | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/packer-install | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/protobuf-install | gerrit-verify.yaml | 1 |
| ansible/roles/puppet-install | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/python-install | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/shellcheck-install | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/sysstat-install | gerrit-verify.yaml | 1 |
| ansible/roles/system-update | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| releng/common-packer | call-composed-github2gerrit.yaml<br>gerrit-verify.yaml<br>release.yaml | 3 |
| releng/docs | call-composed-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| releng/docs-conf | gerrit-verify.yaml<br>release-drafter.yaml<br>release.yaml | 3 |
| releng/gerrit_to_platform | codeql.yaml<br>gerrit-verify.yaml<br>github2gerrit.yaml<br>release.yaml | 4 |
| releng/global-jjb | call-composed-github2gerrit.yaml<br>gerrit-verify.yaml<br>release.yaml | 3 |
| releng/info-master | call-composed-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| releng/lftools | call-composed-github2gerrit.yaml<br>gerrit-verify.yaml<br>release-drafter.yaml<br>release.yaml | 4 |
| releng/nexus-upload | gerrit-verify.yaml | 1 |
| releng/python-one-password | gerrit-verify.yaml<br>release.yaml | 2 |
| releng/sigul-docker | gerrit-verify.yaml<br>release.yaml | 2 |
| sandbox | gerrit-merge-github2gerrit.yaml | 1 |

**Total:** 24 repositories with CI/CD jobs

---


---*Generated with ❤️ by Release Engineering*