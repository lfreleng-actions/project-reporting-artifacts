# 📊 Gerrit Project Analysis Report: Opendaylight

**Generated:** 2026-03-28 07:20:17 UTC
**Schema Version:** 1.5.0

---## Table of Contents

- [Global Summary](#summary)
- [Gerrit Projects](#repositories)
- [Top Contributors](#contributors)
- [Top Organizations](#organizations)
- [Repository Feature Matrix](#features)
- [Deployed CI/CD Jobs](#workflows)
- [Orphaned Jenkins Jobs](#orphaned-jobs)
- [Unattributed Jenkins Jobs](#unattributed-jobs)

---

## 📈 Global Summary

**✅ Current** commits within last 365 days

**☑️ Active** commits between 365-1095 days

**🛑 Inactive** no commits in 1095+ days

| Metric | Count | Percentage |
| --- | --- | --- |
| Total Gerrit Projects | 76 | 100% |
| Current Gerrit Projects | 22 | 28.9% |
| Active Gerrit Projects | 2 | 2.6% |
| Inactive Gerrit Projects | 52 | 68.4% |
| No Apparent Commits | 0 | 0.0% |
| Total Commits | 126.9K | - |
| Total Lines of Code | 1.1M | - |

---
## 🏢 Top Organizations

The data presented in the table below covers the past 365 days.

**Organizations Found:** 157

| Rank | Organization | Contributors | Commits | LOC | Δ LOC | Avg LOC/Commit | Unique Repositories |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | pantheon.tech | 70 | 3297 | +262545 | 417059 | +32 | 48 |
| 2 | linuxfoundation.org | 15 | 529 | +21102 | 96947 | -103 | 75 |
| 3 | opendaylight.org | 14 | 157 | +16191 | 32223 | +1 | 28 |
| 4 | github.com | 5 | 151 | +180 | 360 | 0 | 19 |
| 5 | orange.com | 19 | 115 | +39987 | 137523 | -500 | 12 |
| 6 | hq.sk | 1 | 60 | +5 | 10 | 0 | 32 |
| 7 | smartoptics.com | 3 | 43 | +9623 | 14949 | +99 | 1 |
| 8 | verizon.com | 6 | 15 | +4 | 5 | 0 | 12 |
| 9 | snyk.io | 1 | 8 | +8 | 16 | 0 | 1 |
| 10 | att.com | 14 | 2 | +29415 | 29415 | +14707 | 7 |
| 11 | gmail.com | 210 | 2 | +1 | 2 | 0 | 63 |
| 12 | fujitsu.com | 2 | 1 | +957 | 1255 | +659 | 2 |
| 13 | 126.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 14 | 163.com | 7 | 0 | 0 | 0 | 0 | 9 |
| 15 | 2cups.com | 1 | 0 | 0 | 0 | 0 | 8 |
| 16 | 6wind.com | 4 | 0 | 0 | 0 | 0 | 4 |
| 17 | 99cloud.net | 1 | 0 | 0 | 0 | 0 | 2 |
| 18 | ac.in | 4 | 0 | 0 | 0 | 0 | 16 |
| 19 | advaoptical.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 20 | altencalsoftlabs.com | 25 | 0 | 0 | 0 | 0 | 11 |
| 21 | altran.com | 1 | 0 | 0 | 0 | 0 | 2 |
| 22 | amartus.com | 3 | 0 | 0 | 0 | 0 | 2 |
| 23 | appliedbroadband.com | 1 | 0 | 0 | 0 | 0 | 2 |
| 24 | azverev.com | 1 | 0 | 0 | 0 | 0 | 2 |
| 25 | b-com.com | 1 | 0 | 0 | 0 | 0 | 4 |
| 26 | bardicgrove.org | 1 | 0 | 0 | 0 | 0 | 1 |
| 27 | bigswitch.com | 3 | 0 | 0 | 0 | 0 | 2 |
| 28 | bluefield.tech | 1 | 0 | 0 | 0 | 0 | 2 |
| 29 | brocade.com | 22 | 0 | 0 | 0 | 0 | 26 |
| 30 | bsc.es | 1 | 0 | 0 | 0 | 0 | 2 |

---
## 👥 Top Contributors

The data presented in the table below covers the past 365 days.

**Contributors Found:** 1,256

| Rank | Contributor | Commits | LOC | Δ LOC | Avg LOC/Commit | Repositories | Organization |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Robert Varga | 2814 | +194834 | 328974 | +21 | 44 | pantheon.tech |
| 2 | Anil Belur | 521 | +21097 | 96940 | -105 | 70 | linuxfoundation.org |
| 3 | Ivan Hrasko | 202 | +6637 | 12828 | +2 | 17 | pantheon.tech |
| 4 | jenkins-releng | 157 | +16191 | 32223 | +1 | 24 | opendaylight.org |
| 5 | dependabot[bot] | 151 | +180 | 360 | 0 | 19 | github.com |
| 6 | Gilles Thouenon | 71 | +5740 | 39957 | -401 | 6 | orange.com |
| 7 | Robert Varga | 60 | +5 | 10 | 0 | 32 | hq.sk |
| 8 | Matej Sramcik | 53 | +5936 | 7182 | +88 | 10 | pantheon.tech |
| 9 | Martin Balaz | 51 | +33438 | 37520 | +575 | 6 | pantheon.tech |
| 10 | tobias.pobocik | 50 | +2346 | 3197 | +29 | 7 | pantheon.tech |
| 11 | Joakim Törnqvist | 40 | +7399 | 12180 | +65 | 1 | smartoptics.com |
| 12 | Yaroslav Lastivka | 39 | +4681 | 5347 | +102 | 11 | pantheon.tech |
| 13 | PeterSuna | 34 | +8771 | 13357 | +123 | 9 | pantheon.tech |
| 14 | Samuel Schneider | 26 | +2229 | 2735 | +66 | 11 | pantheon.tech |
| 15 | Oleksandr Zharov | 17 | +1146 | 2131 | +9 | 10 | pantheon.tech |
| 16 | Olivier Dugeon | 17 | +14165 | 28214 | +6 | 4 | orange.com |
| 17 | orenais | 17 | +8750 | 12495 | +294 | 1 | orange.com |
| 18 | Sangwook Ha | 15 | +4 | 5 | 0 | 12 | verizon.com |
| 19 | Christophe Betoule | 10 | +11332 | 56857 | -3419 | 2 | orange.com |
| 20 | Oleksandr Akaiomov | 9 | +1328 | 2231 | +47 | 1 | pantheon.tech |
| 21 | snyk-bot | 8 | +8 | 16 | 0 | 1 | snyk.io |
| 22 | Andrew Grimberg | 5 | 0 | 0 | 0 | 48 | linuxfoundation.org |
| 23 | Jimmi Wimmersjö | 3 | +2224 | 2769 | +559 | 1 | smartoptics.com |
| 24 | Balagangadhar Bathula | 2 | +29415 | 29415 | +14707 | 2 | att.com |
| 25 | Richard Kosegi | 2 | +1 | 2 | 0 | 8 | gmail.com |
| 26 | Tibor Král | 2 | +1199 | 1557 | +420 | 6 | pantheon.tech |
| 27 | Eric Ball | 1 | +1 | 2 | 0 | 3 | linuxfoundation.org |
| 28 | LF Jenkins CI | 1 | +1 | 2 | 0 | 2 | linuxfoundation.org |
| 29 | ModeSevenIndustrialSolutions | 1 | +3 | 3 | +3 | 2 | linuxfoundation.org |
| 30 | Roshan Joyce | 1 | +957 | 1255 | +659 | 1 | fujitsu.com |

---
## 📊 Gerrit Projects

| Gerrit Project | Commits | LOC | Contributors | Days Inactive | Last Commit Date | Status |
| --- | --- | --- | --- | --- | --- | --- |
| [releng/autorelease](https://git.opendaylight.org/gerrit/admin/repos/releng/autorelease,general) | 28432 | +575 | 8 | 0 | 2026-03-27 | ✅ |
| [docs](https://git.opendaylight.org/gerrit/admin/repos/docs,general) | 10918 | +2739 | 5 | 22 | 2026-03-06 | ✅ |
| [yangtools](https://git.opendaylight.org/gerrit/admin/repos/yangtools,general) | 10607 | +76577 | 11 | 0 | 2026-03-27 | ✅ |
| [controller](https://git.opendaylight.org/gerrit/admin/repos/controller,general) | 10566 | +28984 | 9 | 0 | 2026-03-27 | ✅ |
| [releng/builder](https://git.opendaylight.org/gerrit/admin/repos/releng/builder,general) | 10378 | +6824 | 13 | 0 | 2026-03-27 | ✅ |
| [netconf](https://git.opendaylight.org/gerrit/admin/repos/netconf,general) | 6940 | +37657 | 11 | 0 | 2026-03-27 | ✅ |
| [mdsal](https://git.opendaylight.org/gerrit/admin/repos/mdsal,general) | 5900 | +13022 | 6 | 1 | 2026-03-26 | ✅ |
| [bgpcep](https://git.opendaylight.org/gerrit/admin/repos/bgpcep,general) | 4572 | +50316 | 9 | 2 | 2026-03-26 | ✅ |
| [openflowplugin](https://git.opendaylight.org/gerrit/admin/repos/openflowplugin,general) | 4162 | +4881 | 4 | 2 | 2026-03-26 | ✅ |
| [integration/test](https://git.opendaylight.org/gerrit/admin/repos/integration/test,general) | 3596 | +225 | 4 | 30 | 2026-02-25 | ✅ |
| [odlparent](https://git.opendaylight.org/gerrit/admin/repos/odlparent,general) | 3103 | +6898 | 8 | 0 | 2026-03-27 | ✅ |
| [ovsdb](https://git.opendaylight.org/gerrit/admin/repos/ovsdb,general) | 2962 | +2603 | 4 | 14 | 2026-03-13 | ✅ |
| [transportpce](https://git.opendaylight.org/gerrit/admin/repos/transportpce,general) | 2081 | +24210 | 8 | 661 | 2024-06-04 | 🛑 |
| [genius](https://git.opendaylight.org/gerrit/admin/repos/genius,general) | 1905 | 0 | 0 | 1815 | 2021-04-07 | 🛑 |
| [aaa](https://git.opendaylight.org/gerrit/admin/repos/aaa,general) | 1674 | +2132 | 6 | 2 | 2026-03-26 | ✅ |
| [sfc](https://git.opendaylight.org/gerrit/admin/repos/sfc,general) | 1486 | 0 | 0 | 2085 | 2020-07-12 | 🛑 |
| [opflex](https://git.opendaylight.org/gerrit/admin/repos/opflex,general) | 1279 | 0 | 0 | 2085 | 2020-07-12 | 🛑 |
| [lispflowmapping](https://git.opendaylight.org/gerrit/admin/repos/lispflowmapping,general) | 1274 | +4009 | 5 | 0 | 2026-03-27 | ✅ |
| [groupbasedpolicy](https://git.opendaylight.org/gerrit/admin/repos/groupbasedpolicy,general) | 1070 | 0 | 0 | 2085 | 2020-07-11 | 🛑 |
| [neutron](https://git.opendaylight.org/gerrit/admin/repos/neutron,general) | 1020 | 0 | 0 | 1674 | 2021-08-26 | 🛑 |
| [vtn](https://git.opendaylight.org/gerrit/admin/repos/vtn,general) | 1019 | 0 | 0 | 2927 | 2018-03-22 | 🛑 |
| [infrautils](https://git.opendaylight.org/gerrit/admin/repos/infrautils,general) | 952 | +1844 | 4 | 2 | 2026-03-26 | ✅ |
| [integration/distribution](https://git.opendaylight.org/gerrit/admin/repos/integration/distribution,general) | 883 | +589 | 5 | 8 | 2026-03-19 | ✅ |
| [gnmi](https://git.opendaylight.org/gerrit/admin/repos/gnmi,general) | 633 | +7639 | 8 | 22 | 2026-03-05 | ✅ |
| [nic](https://git.opendaylight.org/gerrit/admin/repos/nic,general) | 536 | 0 | 0 | 2937 | 2018-03-12 | 🛑 |
| [openflowjava](https://git.opendaylight.org/gerrit/admin/repos/openflowjava,general) | 525 | 0 | 0 | 3193 | 2017-06-29 | 🛑 |
| [l2switch](https://git.opendaylight.org/gerrit/admin/repos/l2switch,general) | 508 | +4895 | 5 | 2 | 2026-03-26 | ✅ |
| [integration/packaging](https://git.opendaylight.org/gerrit/admin/repos/integration/packaging,general) | 507 | 0 | 0 | 1541 | 2022-01-06 | 🛑 |
| [sxp](https://git.opendaylight.org/gerrit/admin/repos/sxp,general) | 495 | 0 | 0 | 2085 | 2020-07-12 | 🛑 |
| [ietf](https://git.opendaylight.org/gerrit/admin/repos/ietf,general) | 485 | +60178 | 6 | 3 | 2026-03-24 | ✅ |
| [topoprocessing](https://git.opendaylight.org/gerrit/admin/repos/topoprocessing,general) | 470 | 0 | 0 | 3103 | 2017-09-27 | 🛑 |
| [tsdr](https://git.opendaylight.org/gerrit/admin/repos/tsdr,general) | 413 | 0 | 0 | 2085 | 2020-07-12 | 🛑 |
| [serviceutils](https://git.opendaylight.org/gerrit/admin/repos/serviceutils,general) | 345 | 0 | 0 | 472 | 2024-12-11 | ☑️ |
| [jsonrpc](https://git.opendaylight.org/gerrit/admin/repos/jsonrpc,general) | 343 | +640 | 7 | 0 | 2026-03-27 | ✅ |
| [daexim](https://git.opendaylight.org/gerrit/admin/repos/daexim,general) | 274 | +507 | 5 | 1 | 2026-03-27 | ✅ |
| [alt-datastores](https://git.opendaylight.org/gerrit/admin/repos/alt-datastores,general) | 272 | 0 | 0 | 2088 | 2020-07-08 | 🛑 |
| [lacp](https://git.opendaylight.org/gerrit/admin/repos/lacp,general) | 257 | 0 | 0 | 3209 | 2017-06-13 | 🛑 |
| [packetcable](https://git.opendaylight.org/gerrit/admin/repos/packetcable,general) | 242 | 0 | 0 | 2927 | 2018-03-22 | 🛑 |
| [snmp4sdn](https://git.opendaylight.org/gerrit/admin/repos/snmp4sdn,general) | 236 | 0 | 0 | 2085 | 2020-07-12 | 🛑 |
| [snbi](https://git.opendaylight.org/gerrit/admin/repos/snbi,general) | 235 | 0 | 0 | 3302 | 2017-03-13 | 🛑 |
| [faas](https://git.opendaylight.org/gerrit/admin/repos/faas,general) | 231 | 0 | 0 | 3061 | 2017-11-08 | 🛑 |
| [nemo](https://git.opendaylight.org/gerrit/admin/repos/nemo,general) | 226 | 0 | 0 | 2085 | 2020-07-12 | 🛑 |
| [iotdm](https://git.opendaylight.org/gerrit/admin/repos/iotdm,general) | 205 | 0 | 0 | 3209 | 2017-06-13 | 🛑 |
| [coe](https://git.opendaylight.org/gerrit/admin/repos/coe,general) | 194 | 0 | 0 | 2086 | 2020-07-11 | 🛑 |
| [alto](https://git.opendaylight.org/gerrit/admin/repos/alto,general) | 191 | 0 | 0 | 2927 | 2018-03-22 | 🛑 |
| [bier](https://git.opendaylight.org/gerrit/admin/repos/bier,general) | 184 | 0 | 0 | 2086 | 2020-07-11 | 🛑 |
| [centinel](https://git.opendaylight.org/gerrit/admin/repos/centinel,general) | 181 | 0 | 0 | 3390 | 2016-12-14 | 🛑 |
| [coretutorials](https://git.opendaylight.org/gerrit/admin/repos/coretutorials,general) | 176 | 0 | 0 | 2332 | 2019-11-07 | 🛑 |
| [archetypes](https://git.opendaylight.org/gerrit/admin/repos/archetypes,general) | 166 | 0 | 0 | 1832 | 2021-03-21 | 🛑 |
| [netide](https://git.opendaylight.org/gerrit/admin/repos/netide,general) | 140 | 0 | 0 | 3209 | 2017-06-13 | 🛑 |
| [honeycomb/vbd](https://git.opendaylight.org/gerrit/admin/repos/honeycomb/vbd,general) | 131 | 0 | 0 | 2085 | 2020-07-12 | 🛑 |
| [telemetry](https://git.opendaylight.org/gerrit/admin/repos/telemetry,general) | 121 | 0 | 0 | 2085 | 2020-07-12 | 🛑 |
| [detnet](https://git.opendaylight.org/gerrit/admin/repos/detnet,general) | 109 | 0 | 0 | 2086 | 2020-07-11 | 🛑 |
| [ttp](https://git.opendaylight.org/gerrit/admin/repos/ttp,general) | 108 | 0 | 0 | 3102 | 2017-09-29 | 🛑 |
| [sdninterfaceapp](https://git.opendaylight.org/gerrit/admin/repos/sdninterfaceapp,general) | 102 | 0 | 0 | 3213 | 2017-06-09 | 🛑 |
| [didm](https://git.opendaylight.org/gerrit/admin/repos/didm,general) | 99 | 0 | 0 | 3209 | 2017-06-13 | 🛑 |
| [of-config](https://git.opendaylight.org/gerrit/admin/repos/of-config,general) | 94 | 0 | 0 | 2085 | 2020-07-12 | 🛑 |
| [usc](https://git.opendaylight.org/gerrit/admin/repos/usc,general) | 90 | 0 | 0 | 2888 | 2018-04-30 | 🛑 |
| [snmp](https://git.opendaylight.org/gerrit/admin/repos/snmp,general) | 84 | 0 | 0 | 2611 | 2019-02-01 | 🛑 |
| [transportpce/models](https://git.opendaylight.org/gerrit/admin/repos/transportpce/models,general) | 81 | +42074 | 4 | 15 | 2026-03-12 | ✅ |
| [cardinal](https://git.opendaylight.org/gerrit/admin/repos/cardinal,general) | 59 | 0 | 0 | 3107 | 2017-09-23 | 🛑 |
| [capwap](https://git.opendaylight.org/gerrit/admin/repos/capwap,general) | 51 | 0 | 0 | 3273 | 2017-04-11 | 🛑 |
| [eman](https://git.opendaylight.org/gerrit/admin/repos/eman,general) | 48 | 0 | 0 | 2480 | 2019-06-12 | 🛑 |
| [ocpplugin](https://git.opendaylight.org/gerrit/admin/repos/ocpplugin,general) | 46 | 0 | 0 | 3097 | 2017-10-03 | 🛑 |
| [next](https://git.opendaylight.org/gerrit/admin/repos/next,general) | 44 | 0 | 0 | 3209 | 2017-06-13 | 🛑 |
| [usecplugin](https://git.opendaylight.org/gerrit/admin/repos/usecplugin,general) | 32 | 0 | 0 | 3390 | 2016-12-14 | 🛑 |
| [fpc](https://git.opendaylight.org/gerrit/admin/repos/fpc,general) | 28 | 0 | 0 | 3062 | 2017-11-07 | 🛑 |
| [federation](https://git.opendaylight.org/gerrit/admin/repos/federation,general) | 23 | 0 | 0 | 3208 | 2017-06-14 | 🛑 |
| [gnt](https://git.opendaylight.org/gerrit/admin/repos/gnt,general) | 17 | 0 | 0 | 2286 | 2019-12-24 | 🛑 |
| [natapp](https://git.opendaylight.org/gerrit/admin/repos/natapp,general) | 14 | 0 | 0 | 3350 | 2017-01-23 | 🛑 |
| [systemmetrics](https://git.opendaylight.org/gerrit/admin/repos/systemmetrics,general) | 11 | 0 | 0 | 3133 | 2017-08-28 | 🛑 |
| [ansible](https://git.opendaylight.org/gerrit/admin/repos/ansible,general) | 8 | 0 | 0 | 2563 | 2019-03-21 | 🛑 |
| [.github](https://git.opendaylight.org/gerrit/admin/repos/.github,general) | 5 | 0 | 0 | 750 | 2024-03-07 | 🛑 |
| [zzz-test-release](https://git.opendaylight.org/gerrit/admin/repos/zzz-test-release,general) | 4 | 0 | 0 | 2590 | 2019-02-22 | 🛑 |
| [ieft](https://git.opendaylight.org/gerrit/admin/repos/ieft,general) | 1 | 0 | 1 | 207 | 2025-09-01 | ☑️ |
| [ovil](https://git.opendaylight.org/gerrit/admin/repos/ovil,general) | 1 | 0 | 0 | 3137 | 2017-08-25 | 🛑 |

**Total:** 76 repositories

---
## 🔧 Gerrit Project Feature Matrix

| Gerrit Project | Primary Type | Other Types | Dependabot | Pre-commit | ReadTheDocs | .gitreview | G2G | Status |
|----------------|--------------|-------------|------------|------------|-------------|------------|-----|--------|
| .github | N/A |  | ❌ | ✅ | ❌ | ✅ | ❌ | 🛑 |
| integration/packaging | Shell | Python, Smarty | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| releng/autorelease | Python | Java/Maven, Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| honeycomb/vbd | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| transportpce/models | Python | Java/Maven | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| integration/distribution | Shell | Java/Maven, Python | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| ansible | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| archetypes | Java/Maven | CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| capwap | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| alt-datastores | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cardinal | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| releng/builder | Shell | Python, HCL | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| coe | Go | Python, Shell, Java/Maven | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| centinel | Java/Maven | JavaScript, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| bier | Java/Maven | JavaScript, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| aaa | Java/Maven | Python, CSS | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| integration/test | Robot Framework | Python, Shell | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ |
| alto | Java/Maven | Shell, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| didm | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| eman | Java/Maven | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| coretutorials | Java/Maven | Python, Shell, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| detnet | Java/Maven | CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| federation | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| faas | Java/Maven | Python, Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| docs | Shell | Python, HTML, CSS | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ |
| fpc | Java/Maven | Python, Shell, CSS | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ieft | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| gnt | Java/Maven |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| daexim | Java/Maven | Python | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| gnmi | Java/Maven | Python, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| infrautils | Java/Maven | Python | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| genius | Java/Maven | Python | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| lacp | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| groupbasedpolicy | Java/Maven | Python, Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ietf | Java/Maven |  | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| controller | Java/Maven | Python, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| l2switch | Java/Maven | Python | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| jsonrpc | Java/Maven | Python | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| natapp | Java/Maven | CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| netide | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| lispflowmapping | Java/Maven | Python, Shell, HTML, CSS | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| neutron | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| nemo | Java/Maven | Python, Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| next | JavaScript | Java/Maven, Node, Smarty, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| iotdm | JavaScript | TypeScript, SCSS, HTML, CSS, Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| bgpcep | Java/Maven | Python, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| of-config | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| nic | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ovil | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| openflowjava | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ocpplugin | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sdninterfaceapp | Java/Maven | JavaScript, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| packetcable | Java/Maven | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| opflex | C++ | Python, Shell, Java, C | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| odlparent | Java/Maven | Python, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| mdsal | Java/Maven | Python | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| snmp | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| snbi | C | Python, Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| snmp4sdn | Java/Maven | Python | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| serviceutils | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ✅ | ☑️ |
| systemmetrics | JavaScript | HTML, CSS, Java/Maven | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| telemetry | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sxp | Java/Maven | Python, Lua | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| ovsdb | Java/Maven | Python, Dockerfile, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| ttp | Java/Maven | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| usc | Java/Maven | JavaScript, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| usecplugin | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sfc | Java/Maven | Python, Shell, C | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| zzz-test-release | Python | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| topoprocessing | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| tsdr | Java/Maven | Python | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| netconf | Java/Maven | JavaScript, Python, Shell, HTML, CSS | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| transportpce | Java/Maven | Python, Shell, PLpgSQL | ❌ | ✅ | ✅ | ✅ | ✅ | 🛑 |
| vtn | Java/Maven | Python, Shell, C++, C, PLpgSQL | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| openflowplugin | Java/Maven | Python, Shell | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| yangtools | Java/Maven | Python, Groovy | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |

---
## 🏁 Deployed CI/CD Jobs

**Total GitHub workflows:** 119

**Total Jenkins jobs:** 625

| Gerrit Project | GitHub Workflows | Workflow Count | Jenkins Jobs | Job Count |
|----------------|-------------------|----------------|--------------|-----------|
| .github | codeql<br>gerrit-required-verify.yaml<br>gerrit-verify.yaml | 3 |  | 0 |
| aaa | aaa-csit-1node-authn-all.yaml<br>call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge.yaml<br>gerrit-verify.yaml | 7 | aaa-csit-1node-authn-all-chromium<br>aaa-csit-1node-authn-all-titanium<br>aaa-csit-1node-authn-all-vanadium<br>aaa-csit-verify-1node-authn<br>aaa-info-yaml-verify<br>aaa-maven-clm-0.20.x<br>aaa-maven-clm-0.21.x<br>aaa-maven-clm-0.22.x<br>aaa-maven-clm-master<br>aaa-maven-merge-0.20.x<br>aaa-maven-merge-0.21.x<br>aaa-maven-merge-0.22.x<br>aaa-maven-merge-master<br>aaa-maven-mri-stage-0.20.x<br>aaa-maven-mri-stage-0.21.x<br>aaa-maven-mri-stage-0.22.x<br>aaa-maven-mri-stage-master<br>aaa-maven-stage-0.20.x<br>aaa-maven-stage-0.21.x<br>aaa-maven-stage-0.22.x<br>aaa-maven-stage-master<br>aaa-maven-verify-0.20.x-mvn39-openjdk21<br>aaa-maven-verify-0.21.x-mvn39-openjdk21<br>aaa-maven-verify-0.22.x-mvn39-openjdk21<br>aaa-maven-verify-deps-0.20.x-mvn39-openjdk21<br>aaa-maven-verify-deps-0.21.x-mvn39-openjdk21<br>aaa-maven-verify-deps-0.22.x-mvn39-openjdk21<br>aaa-maven-verify-deps-master-mvn39-openjdk21<br>aaa-maven-verify-master-mvn39-openjdk21<br>aaa-release-merge-master<br>aaa-sonar | 31 |
| bgpcep | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | bgpcep-csit-1node-bgp-ingest-all-titanium<br>bgpcep-csit-1node-bgp-ingest-all-vanadium<br>bgpcep-csit-1node-bgp-ingest-mixed-all-titanium<br>bgpcep-csit-1node-bgp-ingest-mixed-all-vanadium<br>bgpcep-csit-1node-gate-bgp-ingest-mixed-all-titanium<br>bgpcep-csit-1node-gate-bgp-ingest-mixed-all-vanadium<br>bgpcep-csit-1node-gate-throughpcep-all-titanium<br>bgpcep-csit-1node-gate-throughpcep-all-vanadium<br>bgpcep-csit-1node-gate-userfeatures-all-titanium<br>bgpcep-csit-1node-gate-userfeatures-all-vanadium<br>bgpcep-csit-1node-throughpcep-all-titanium<br>bgpcep-csit-1node-throughpcep-all-vanadium<br>bgpcep-csit-1node-userfeatures-all-titanium<br>bgpcep-csit-1node-userfeatures-all-vanadium<br>bgpcep-csit-3node-bgpclustering-all-titanium<br>bgpcep-csit-3node-bgpclustering-all-vanadium<br>bgpcep-csit-3node-bgpclustering-ha-only-titanium<br>bgpcep-csit-3node-bgpclustering-ha-only-vanadium<br>bgpcep-csit-3node-bgpclustering-longevity-only-titanium<br>bgpcep-csit-3node-bgpclustering-longevity-only-vanadium<br>bgpcep-info-yaml-verify<br>bgpcep-maven-clm-0.23.x<br>bgpcep-maven-clm-master<br>bgpcep-maven-javadoc-publish-0.23.x-openjdk21<br>bgpcep-maven-javadoc-publish-master-openjdk21<br>bgpcep-maven-javadoc-verify-0.23.x-openjdk21<br>bgpcep-maven-javadoc-verify-master-openjdk21<br>bgpcep-maven-merge-0.23.x<br>bgpcep-maven-merge-master<br>bgpcep-maven-mri-stage-0.23.x<br>bgpcep-maven-mri-stage-master<br>bgpcep-maven-stage-0.23.x<br>bgpcep-maven-stage-master<br>bgpcep-maven-verify-0.23.x-mvn39-openjdk21<br>bgpcep-maven-verify-deps-0.23.x-mvn39-openjdk21<br>bgpcep-maven-verify-deps-master-mvn39-openjdk21<br>bgpcep-maven-verify-master-mvn39-openjdk21<br>bgpcep-release-merge-master<br>bgpcep-sonar<br>bgpcep-tox-verify-0.23.x<br>bgpcep-tox-verify-master | 41 |
| controller | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | controller-csit-1node-akka1-all-chromium<br>controller-csit-1node-akka1-all-titanium<br>controller-csit-1node-akka1-all-vanadium<br>controller-csit-1node-benchmark-all-chromium<br>controller-csit-1node-benchmark-all-titanium<br>controller-csit-1node-benchmark-all-vanadium<br>controller-csit-1node-notifications-longevity-only-chromium<br>controller-csit-1node-notifications-longevity-only-titanium<br>controller-csit-1node-notifications-longevity-only-vanadium<br>controller-csit-1node-rest-cars-perf-all-chromium<br>controller-csit-1node-rest-cars-perf-all-titanium<br>controller-csit-1node-rest-cars-perf-all-vanadium<br>controller-csit-3node-benchmark-all-chromium<br>controller-csit-3node-benchmark-all-titanium<br>controller-csit-3node-benchmark-all-vanadium<br>controller-csit-3node-clustering-ask-all-chromium<br>controller-csit-3node-clustering-ask-all-titanium<br>controller-csit-3node-clustering-ask-all-vanadium<br>controller-csit-3node-clustering-tell-all-chromium<br>controller-csit-3node-clustering-tell-all-titanium<br>controller-csit-3node-clustering-tell-all-vanadium<br>controller-csit-3node-cs-chasing-leader-longevity-only-chromium<br>controller-csit-3node-cs-chasing-leader-longevity-only-titanium<br>controller-csit-3node-cs-chasing-leader-longevity-only-vanadium<br>controller-csit-3node-cs-partnheal-longevity-only-chromium<br>controller-csit-3node-cs-partnheal-longevity-only-titanium<br>controller-csit-3node-cs-partnheal-longevity-only-vanadium<br>controller-csit-3node-ddb-expl-lead-movement-longevity-only-chromium<br>controller-csit-3node-ddb-expl-lead-movement-longevity-only-titanium<br>controller-csit-3node-ddb-expl-lead-movement-longevity-only-vanadium<br>controller-csit-3node-drb-partnheal-longevity-only-chromium<br>controller-csit-3node-drb-partnheal-longevity-only-titanium<br>controller-csit-3node-drb-partnheal-longevity-only-vanadium<br>controller-csit-3node-drb-precedence-longevity-only-chromium<br>controller-csit-3node-drb-precedence-longevity-only-titanium<br>controller-csit-3node-drb-precedence-longevity-only-vanadium<br>controller-csit-3node-rest-clust-cars-perf-ask-only-chromium<br>controller-csit-3node-rest-clust-cars-perf-ask-only-titanium<br>controller-csit-3node-rest-clust-cars-perf-ask-only-vanadium<br>controller-csit-3node-rest-clust-cars-perf-tell-only-chromium<br>controller-csit-3node-rest-clust-cars-perf-tell-only-titanium<br>controller-csit-3node-rest-clust-cars-perf-tell-only-vanadium<br>controller-info-yaml-verify<br>controller-maven-clm-11.0.x<br>controller-maven-clm-12.0.x<br>controller-maven-clm-master<br>controller-maven-merge-11.0.x<br>controller-maven-merge-12.0.x<br>controller-maven-merge-master<br>controller-maven-mri-stage-11.0.x<br>controller-maven-mri-stage-12.0.x<br>controller-maven-mri-stage-master<br>controller-maven-stage-11.0.x<br>controller-maven-stage-12.0.x<br>controller-maven-stage-master<br>controller-maven-verify-11.0.x-mvn39-openjdk21<br>controller-maven-verify-12.0.x-mvn39-openjdk21<br>controller-maven-verify-deps-11.0.x-mvn39-openjdk21<br>controller-maven-verify-deps-12.0.x-mvn39-openjdk21<br>controller-maven-verify-deps-master-mvn39-openjdk21<br>controller-maven-verify-master-mvn39-openjdk21<br>controller-release-merge-master<br>controller-sonar | 63 |
| daexim | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | daexim-csit-1node-basic-only-chromium<br>daexim-csit-1node-basic-only-titanium<br>daexim-csit-1node-basic-only-vanadium<br>daexim-csit-3node-clustering-basic-only-chromium<br>daexim-csit-3node-clustering-basic-only-titanium<br>daexim-csit-3node-clustering-basic-only-vanadium<br>daexim-distribution-check-chromium<br>daexim-distribution-check-titanium<br>daexim-distribution-check-vanadium<br>daexim-info-yaml-verify<br>daexim-maven-clm-chromium<br>daexim-maven-clm-titanium<br>daexim-maven-clm-vanadium<br>daexim-maven-merge-chromium<br>daexim-maven-merge-titanium<br>daexim-maven-merge-vanadium<br>daexim-maven-mri-stage-chromium<br>daexim-maven-mri-stage-titanium<br>daexim-maven-mri-stage-vanadium<br>daexim-maven-stage-chromium<br>daexim-maven-stage-titanium<br>daexim-maven-stage-vanadium<br>daexim-maven-verify-chromium-mvn39-openjdk21<br>daexim-maven-verify-deps-chromium-mvn39-openjdk21<br>daexim-maven-verify-deps-titanium-mvn39-openjdk21<br>daexim-maven-verify-deps-vanadium-mvn39-openjdk21<br>daexim-maven-verify-titanium-mvn39-openjdk21<br>daexim-maven-verify-vanadium-mvn39-openjdk21<br>daexim-sonar<br>daexim-validate-autorelease-chromium<br>daexim-validate-autorelease-titanium<br>daexim-validate-autorelease-vanadium | 32 |
| docs | call-github2gerrit.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 4 | docs-info-yaml-verify<br>docs-tox-verify-chromium<br>docs-tox-verify-titanium<br>docs-tox-verify-vanadium<br>docs-update-master | 5 |
| gnmi | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | gnmi-info-yaml-verify<br>gnmi-maven-clm-1.0.x<br>gnmi-maven-clm-master<br>gnmi-maven-merge-1.0.x<br>gnmi-maven-merge-master<br>gnmi-maven-mri-stage-1.0.x<br>gnmi-maven-mri-stage-master<br>gnmi-maven-stage-1.0.x<br>gnmi-maven-stage-master<br>gnmi-maven-verify-1.0.x-mvn39-openjdk21<br>gnmi-maven-verify-deps-1.0.x-mvn39-openjdk21<br>gnmi-maven-verify-deps-master-mvn39-openjdk21<br>gnmi-maven-verify-master-mvn39-openjdk21<br>gnmi-release-merge-master<br>gnmi-sonar | 15 |
| ietf | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | ietf-info-yaml-verify<br>ietf-maven-clm-master<br>ietf-maven-clm-vanadium<br>ietf-maven-merge-master<br>ietf-maven-merge-vanadium<br>ietf-maven-mri-stage-master<br>ietf-maven-mri-stage-vanadium<br>ietf-maven-stage-master<br>ietf-maven-stage-vanadium<br>ietf-maven-verify-deps-master-mvn39-openjdk21<br>ietf-maven-verify-deps-vanadium-mvn39-openjdk21<br>ietf-maven-verify-master-mvn39-openjdk21<br>ietf-maven-verify-vanadium-mvn39-openjdk21<br>ietf-release-merge-master<br>ietf-sonar | 15 |
| infrautils | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-maven-merge.yaml<br>gerrit-verify.yaml | 6 | infrautils-info-yaml-verify<br>infrautils-maven-clm-master<br>infrautils-maven-merge-master<br>infrautils-maven-mri-stage-master<br>infrautils-maven-stage-master<br>infrautils-maven-verify-deps-master-mvn39-openjdk21<br>infrautils-maven-verify-master-mvn39-openjdk21<br>infrautils-release-merge-master<br>infrautils-sonar | 9 |
| integration/distribution | call-github2gerrit.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 4 | distribution-docker-merge-titanium<br>distribution-docker-merge-vanadium<br>distribution-docker-verify-titanium<br>distribution-docker-verify-vanadium<br>distribution-maven-clm-chromium<br>distribution-maven-clm-titanium<br>distribution-maven-clm-vanadium<br>distribution-maven-verify-deps-chromium-mvn39-openjdk21<br>distribution-maven-verify-deps-titanium-mvn39-openjdk21<br>distribution-maven-verify-deps-vanadium-mvn39-openjdk21<br>distribution-tox-verify-chromium<br>distribution-tox-verify-titanium<br>distribution-tox-verify-vanadium<br>integration-distribution-mri-test-chromium<br>integration-distribution-mri-test-titanium<br>integration-distribution-mri-test-vanadium<br>integration-distribution-test-chromium<br>integration-distribution-test-titanium<br>integration-distribution-test-vanadium<br>integration-distribution-validate-autorelease-chromium<br>integration-distribution-validate-autorelease-titanium<br>integration-distribution-validate-autorelease-vanadium<br>integration-distribution-weekly-test-trigger-chromium<br>integration-distribution-weekly-test-trigger-titanium<br>integration-distribution-weekly-test-trigger-vanadium | 25 |
| integration/packaging |  | 0 | packaging-docker-merge-phosphorus<br>packaging-docker-verify-phosphorus | 2 |
| integration/test |  | 0 | integration-test-tox-verify-master | 1 |
| jsonrpc | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | jsonrpc-csit-1node-basic-only-chromium<br>jsonrpc-csit-1node-basic-only-titanium<br>jsonrpc-csit-1node-basic-only-vanadium<br>jsonrpc-distribution-check-chromium<br>jsonrpc-distribution-check-titanium<br>jsonrpc-distribution-check-vanadium<br>jsonrpc-info-yaml-verify<br>jsonrpc-maven-clm-chromium<br>jsonrpc-maven-clm-titanium<br>jsonrpc-maven-clm-vanadium<br>jsonrpc-maven-merge-chromium<br>jsonrpc-maven-merge-titanium<br>jsonrpc-maven-merge-vanadium<br>jsonrpc-maven-mri-stage-chromium<br>jsonrpc-maven-mri-stage-titanium<br>jsonrpc-maven-mri-stage-vanadium<br>jsonrpc-maven-stage-chromium<br>jsonrpc-maven-stage-titanium<br>jsonrpc-maven-stage-vanadium<br>jsonrpc-maven-verify-chromium-mvn39-openjdk21<br>jsonrpc-maven-verify-deps-chromium-mvn39-openjdk21<br>jsonrpc-maven-verify-deps-titanium-mvn39-openjdk21<br>jsonrpc-maven-verify-deps-vanadium-mvn39-openjdk21<br>jsonrpc-maven-verify-titanium-mvn39-openjdk21<br>jsonrpc-maven-verify-vanadium-mvn39-openjdk21<br>jsonrpc-release-merge-master<br>jsonrpc-sonar<br>jsonrpc-validate-autorelease-chromium<br>jsonrpc-validate-autorelease-titanium<br>jsonrpc-validate-autorelease-vanadium | 30 |
| l2switch | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | l2switch-csit-1node-host-scalability-daily-only-chromium<br>l2switch-csit-1node-host-scalability-daily-only-titanium<br>l2switch-csit-1node-host-scalability-daily-only-vanadium<br>l2switch-csit-1node-scalability-all-chromium<br>l2switch-csit-1node-scalability-all-titanium<br>l2switch-csit-1node-scalability-all-vanadium<br>l2switch-csit-1node-switch-all-chromium<br>l2switch-csit-1node-switch-all-titanium<br>l2switch-csit-1node-switch-all-vanadium<br>l2switch-csit-verify-1node-switch<br>l2switch-info-yaml-verify<br>l2switch-maven-clm-1.0.x<br>l2switch-maven-clm-2.0.x<br>l2switch-maven-clm-master<br>l2switch-maven-merge-1.0.x<br>l2switch-maven-merge-2.0.x<br>l2switch-maven-merge-master<br>l2switch-maven-mri-stage-1.0.x<br>l2switch-maven-mri-stage-2.0.x<br>l2switch-maven-mri-stage-master<br>l2switch-maven-stage-1.0.x<br>l2switch-maven-stage-2.0.x<br>l2switch-maven-stage-master<br>l2switch-maven-verify-1.0.x-mvn39-openjdk21<br>l2switch-maven-verify-2.0.x-mvn39-openjdk21<br>l2switch-maven-verify-deps-1.0.x-mvn39-openjdk21<br>l2switch-maven-verify-deps-2.0.x-mvn39-openjdk21<br>l2switch-maven-verify-deps-master-mvn39-openjdk21<br>l2switch-maven-verify-master-mvn39-openjdk21<br>l2switch-release-merge-master<br>l2switch-sonar | 31 |
| lispflowmapping | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | lispflowmapping-csit-1node-msmr-all-chromium<br>lispflowmapping-csit-1node-msmr-all-titanium<br>lispflowmapping-csit-1node-msmr-all-vanadium<br>lispflowmapping-csit-3node-msmr-all-chromium<br>lispflowmapping-csit-3node-msmr-all-titanium<br>lispflowmapping-csit-3node-msmr-all-vanadium<br>lispflowmapping-csit-verify-1node-msmr<br>lispflowmapping-distribution-check-chromium<br>lispflowmapping-distribution-check-titanium<br>lispflowmapping-distribution-check-vanadium<br>lispflowmapping-info-yaml-verify<br>lispflowmapping-maven-clm-chromium<br>lispflowmapping-maven-clm-titanium<br>lispflowmapping-maven-clm-vanadium<br>lispflowmapping-maven-javadoc-publish-chromium-openjdk21<br>lispflowmapping-maven-javadoc-publish-titanium-openjdk21<br>lispflowmapping-maven-javadoc-publish-vanadium-openjdk21<br>lispflowmapping-maven-javadoc-verify-chromium-openjdk21<br>lispflowmapping-maven-javadoc-verify-titanium-openjdk21<br>lispflowmapping-maven-javadoc-verify-vanadium-openjdk21<br>lispflowmapping-maven-merge-chromium<br>lispflowmapping-maven-merge-titanium<br>lispflowmapping-maven-merge-vanadium<br>lispflowmapping-maven-mri-stage-chromium<br>lispflowmapping-maven-mri-stage-titanium<br>lispflowmapping-maven-mri-stage-vanadium<br>lispflowmapping-maven-stage-chromium<br>lispflowmapping-maven-stage-titanium<br>lispflowmapping-maven-stage-vanadium<br>lispflowmapping-maven-verify-chromium-mvn39-openjdk21<br>lispflowmapping-maven-verify-deps-chromium-mvn39-openjdk21<br>lispflowmapping-maven-verify-deps-titanium-mvn39-openjdk21<br>lispflowmapping-maven-verify-deps-vanadium-mvn39-openjdk21<br>lispflowmapping-maven-verify-titanium-mvn39-openjdk21<br>lispflowmapping-maven-verify-vanadium-mvn39-openjdk21<br>lispflowmapping-sonar<br>lispflowmapping-validate-autorelease-chromium<br>lispflowmapping-validate-autorelease-titanium<br>lispflowmapping-validate-autorelease-vanadium | 39 |
| mdsal | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | mdsal-csit-1node-bindingv1-only-titanium<br>mdsal-csit-1node-bindingv1-only-vanadium<br>mdsal-csit-3node-netty-replicate-only-titanium<br>mdsal-csit-3node-netty-replicate-only-vanadium<br>mdsal-info-yaml-verify<br>mdsal-maven-clm-14.0.x<br>mdsal-maven-clm-master<br>mdsal-maven-clm-vanadium<br>mdsal-maven-merge-14.0.x<br>mdsal-maven-merge-master<br>mdsal-maven-merge-vanadium<br>mdsal-maven-mri-stage-14.0.x<br>mdsal-maven-mri-stage-master<br>mdsal-maven-mri-stage-vanadium<br>mdsal-maven-stage-14.0.x<br>mdsal-maven-stage-master<br>mdsal-maven-stage-vanadium<br>mdsal-maven-verify-14.0.x-mvn39-openjdk21<br>mdsal-maven-verify-deps-14.0.x-mvn39-openjdk21<br>mdsal-maven-verify-deps-master-mvn39-openjdk21<br>mdsal-maven-verify-deps-vanadium-mvn39-openjdk21<br>mdsal-maven-verify-master-mvn39-openjdk21<br>mdsal-maven-verify-vanadium-mvn39-openjdk21<br>mdsal-release-merge-master<br>mdsal-sonar | 25 |
| netconf | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | netconf-csit-1node-callhome-only-titanium<br>netconf-csit-1node-callhome-only-vanadium<br>netconf-csit-1node-gate-callhome-only-titanium<br>netconf-csit-1node-gate-callhome-only-vanadium<br>netconf-csit-1node-gate-userfeatures-all-titanium<br>netconf-csit-1node-gate-userfeatures-all-vanadium<br>netconf-csit-1node-gate-userfeatures-netty-all-titanium<br>netconf-csit-1node-gate-userfeatures-netty-all-vanadium<br>netconf-csit-1node-scale-max-devices-only-titanium<br>netconf-csit-1node-scale-max-devices-only-vanadium<br>netconf-csit-1node-scale-only-titanium<br>netconf-csit-1node-scale-only-vanadium<br>netconf-csit-1node-userfeatures-all-titanium<br>netconf-csit-1node-userfeatures-all-vanadium<br>netconf-csit-1node-userfeatures-netty-all-titanium<br>netconf-csit-1node-userfeatures-netty-all-vanadium<br>netconf-csit-3node-clustering-only-titanium<br>netconf-csit-3node-clustering-only-vanadium<br>netconf-csit-3node-clustering-scale-only-titanium<br>netconf-csit-3node-clustering-scale-only-vanadium<br>netconf-distribution-mri-test-titanium<br>netconf-distribution-mri-test-vanadium<br>netconf-info-yaml-verify<br>netconf-maven-clm-9.0.x<br>netconf-maven-clm-master<br>netconf-maven-merge-9.0.x<br>netconf-maven-merge-master<br>netconf-maven-mri-stage-9.0.x<br>netconf-maven-mri-stage-master<br>netconf-maven-stage-9.0.x<br>netconf-maven-stage-master<br>netconf-maven-verify-9.0.x-mvn39-openjdk21<br>netconf-maven-verify-deps-9.0.x-mvn39-openjdk21<br>netconf-maven-verify-deps-master-mvn39-openjdk21<br>netconf-maven-verify-master-mvn39-openjdk21<br>netconf-mri-patch-test-core-titanium<br>netconf-mri-patch-test-core-vanadium<br>netconf-release-merge-master<br>netconf-sonar<br>netconf-tox-verify-9.0.x<br>netconf-tox-verify-master | 41 |
| odlparent | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | odlparent-info-yaml-verify<br>odlparent-maven-clm-master<br>odlparent-maven-merge-master<br>odlparent-maven-mri-stage-master<br>odlparent-maven-stage-master<br>odlparent-maven-verify-deps-master-mvn39-openjdk21<br>odlparent-maven-verify-master-mvn39-openjdk21<br>odlparent-release-merge-master<br>odlparent-sonar<br>odlparent-tox-verify-master | 10 |
| openflowplugin | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | openflowplugin-csit-1node-cbench-only-chromium<br>openflowplugin-csit-1node-cbench-only-titanium<br>openflowplugin-csit-1node-cbench-only-vanadium<br>openflowplugin-csit-1node-flow-services-all-chromium<br>openflowplugin-csit-1node-flow-services-all-titanium<br>openflowplugin-csit-1node-flow-services-all-vanadium<br>openflowplugin-csit-1node-gate-flow-services-all-chromium<br>openflowplugin-csit-1node-gate-flow-services-all-titanium<br>openflowplugin-csit-1node-gate-flow-services-all-vanadium<br>openflowplugin-csit-1node-gate-perf-bulkomatic-only-chromium<br>openflowplugin-csit-1node-gate-perf-bulkomatic-only-titanium<br>openflowplugin-csit-1node-gate-perf-bulkomatic-only-vanadium<br>openflowplugin-csit-1node-gate-perf-stats-collection-only-chromium<br>openflowplugin-csit-1node-gate-perf-stats-collection-only-titanium<br>openflowplugin-csit-1node-gate-perf-stats-collection-only-vanadium<br>openflowplugin-csit-1node-gate-scale-only-chromium<br>openflowplugin-csit-1node-gate-scale-only-titanium<br>openflowplugin-csit-1node-gate-scale-only-vanadium<br>openflowplugin-csit-1node-longevity-only-chromium<br>openflowplugin-csit-1node-longevity-only-titanium<br>openflowplugin-csit-1node-longevity-only-vanadium<br>openflowplugin-csit-1node-perf-bulkomatic-only-chromium<br>openflowplugin-csit-1node-perf-bulkomatic-only-titanium<br>openflowplugin-csit-1node-perf-bulkomatic-only-vanadium<br>openflowplugin-csit-1node-perf-stats-collection-only-chromium<br>openflowplugin-csit-1node-perf-stats-collection-only-titanium<br>openflowplugin-csit-1node-perf-stats-collection-only-vanadium<br>openflowplugin-csit-1node-sanity-only-chromium<br>openflowplugin-csit-1node-sanity-only-titanium<br>openflowplugin-csit-1node-sanity-only-vanadium<br>openflowplugin-csit-1node-scale-link-only-chromium<br>openflowplugin-csit-1node-scale-link-only-titanium<br>openflowplugin-csit-1node-scale-link-only-vanadium<br>openflowplugin-csit-1node-scale-only-chromium<br>openflowplugin-csit-1node-scale-only-titanium<br>openflowplugin-csit-1node-scale-only-vanadium<br>openflowplugin-csit-1node-scale-switch-only-chromium<br>openflowplugin-csit-1node-scale-switch-only-titanium<br>openflowplugin-csit-1node-scale-switch-only-vanadium<br>openflowplugin-csit-3node-clustering-bulkomatic-only-chromium<br>openflowplugin-csit-3node-clustering-bulkomatic-only-titanium<br>openflowplugin-csit-3node-clustering-bulkomatic-only-vanadium<br>openflowplugin-csit-3node-clustering-only-chromium<br>openflowplugin-csit-3node-clustering-only-titanium<br>openflowplugin-csit-3node-clustering-only-vanadium<br>openflowplugin-csit-3node-clustering-perf-bulkomatic-only-chromium<br>openflowplugin-csit-3node-clustering-perf-bulkomatic-only-titanium<br>openflowplugin-csit-3node-clustering-perf-bulkomatic-only-vanadium<br>openflowplugin-csit-3node-gate-clustering-bulkomatic-only-chromium<br>openflowplugin-csit-3node-gate-clustering-bulkomatic-only-titanium<br>openflowplugin-csit-3node-gate-clustering-bulkomatic-only-vanadium<br>openflowplugin-csit-3node-gate-clustering-only-chromium<br>openflowplugin-csit-3node-gate-clustering-only-titanium<br>openflowplugin-csit-3node-gate-clustering-only-vanadium<br>openflowplugin-csit-3node-gate-clustering-perf-bulkomatic-only-chromium<br>openflowplugin-csit-3node-gate-clustering-perf-bulkomatic-only-titanium<br>openflowplugin-csit-3node-gate-clustering-perf-bulkomatic-only-vanadium<br>openflowplugin-csit-verify-1node-sanity<br>openflowplugin-info-yaml-verify<br>openflowplugin-maven-clm-chromium<br>openflowplugin-maven-clm-titanium<br>openflowplugin-maven-clm-vanadium<br>openflowplugin-maven-javadoc-publish-chromium-openjdk21<br>openflowplugin-maven-javadoc-publish-titanium-openjdk21<br>openflowplugin-maven-javadoc-publish-vanadium-openjdk21<br>openflowplugin-maven-javadoc-verify-chromium-openjdk21<br>openflowplugin-maven-javadoc-verify-titanium-openjdk21<br>openflowplugin-maven-javadoc-verify-vanadium-openjdk21<br>openflowplugin-maven-merge-chromium<br>openflowplugin-maven-merge-titanium<br>openflowplugin-maven-merge-vanadium<br>openflowplugin-maven-mri-stage-chromium<br>openflowplugin-maven-mri-stage-titanium<br>openflowplugin-maven-mri-stage-vanadium<br>openflowplugin-maven-stage-chromium<br>openflowplugin-maven-stage-titanium<br>openflowplugin-maven-stage-vanadium<br>openflowplugin-maven-verify-chromium-mvn39-openjdk21<br>openflowplugin-maven-verify-deps-chromium-mvn39-openjdk21<br>openflowplugin-maven-verify-deps-titanium-mvn39-openjdk21<br>openflowplugin-maven-verify-deps-vanadium-mvn39-openjdk21<br>openflowplugin-maven-verify-titanium-mvn39-openjdk21<br>openflowplugin-maven-verify-vanadium-mvn39-openjdk21<br>openflowplugin-patch-test-cbench-chromium<br>openflowplugin-patch-test-cbench-titanium<br>openflowplugin-patch-test-cbench-vanadium<br>openflowplugin-patch-test-core-chromium<br>openflowplugin-patch-test-core-titanium<br>openflowplugin-patch-test-core-vanadium<br>openflowplugin-release-merge-master<br>openflowplugin-sonar | 91 |
| ovsdb | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | ovsdb-csit-1node-gate-southbound-all-chromium<br>ovsdb-csit-1node-gate-southbound-all-titanium<br>ovsdb-csit-1node-gate-southbound-all-vanadium<br>ovsdb-csit-1node-upstream-southbound-all-chromium<br>ovsdb-csit-1node-upstream-southbound-all-titanium<br>ovsdb-csit-1node-upstream-southbound-all-vanadium<br>ovsdb-csit-3node-gate-clustering-only-chromium<br>ovsdb-csit-3node-gate-clustering-only-titanium<br>ovsdb-csit-3node-gate-clustering-only-vanadium<br>ovsdb-csit-3node-upstream-clustering-only-chromium<br>ovsdb-csit-3node-upstream-clustering-only-titanium<br>ovsdb-csit-3node-upstream-clustering-only-vanadium<br>ovsdb-daily-full-integration-chromium<br>ovsdb-daily-full-integration-titanium<br>ovsdb-daily-full-integration-vanadium<br>ovsdb-distribution-check-chromium<br>ovsdb-distribution-check-titanium<br>ovsdb-distribution-check-vanadium<br>ovsdb-info-yaml-verify<br>ovsdb-maven-clm-chromium<br>ovsdb-maven-clm-titanium<br>ovsdb-maven-clm-vanadium<br>ovsdb-maven-javadoc-publish-chromium-openjdk21<br>ovsdb-maven-javadoc-publish-titanium-openjdk21<br>ovsdb-maven-javadoc-publish-vanadium-openjdk21<br>ovsdb-maven-javadoc-verify-chromium-openjdk21<br>ovsdb-maven-javadoc-verify-titanium-openjdk21<br>ovsdb-maven-javadoc-verify-vanadium-openjdk21<br>ovsdb-maven-merge-chromium<br>ovsdb-maven-merge-titanium<br>ovsdb-maven-merge-vanadium<br>ovsdb-maven-mri-stage-chromium<br>ovsdb-maven-mri-stage-titanium<br>ovsdb-maven-mri-stage-vanadium<br>ovsdb-maven-stage-chromium<br>ovsdb-maven-stage-titanium<br>ovsdb-maven-stage-vanadium<br>ovsdb-maven-verify-chromium-mvn39-openjdk21<br>ovsdb-maven-verify-deps-chromium-mvn39-openjdk21<br>ovsdb-maven-verify-deps-titanium-mvn39-openjdk21<br>ovsdb-maven-verify-deps-vanadium-mvn39-openjdk21<br>ovsdb-maven-verify-titanium-mvn39-openjdk21<br>ovsdb-maven-verify-vanadium-mvn39-openjdk21<br>ovsdb-patch-test-core-chromium<br>ovsdb-patch-test-core-titanium<br>ovsdb-patch-test-core-vanadium<br>ovsdb-sonar<br>ovsdb-validate-autorelease-chromium<br>ovsdb-validate-autorelease-titanium<br>ovsdb-validate-autorelease-vanadium | 50 |
| releng/autorelease | call-github2gerrit.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 4 | autorelease-info-yaml-verify<br>autorelease-tox-verify-chromium<br>autorelease-tox-verify-titanium<br>autorelease-tox-verify-vanadium | 4 |
| releng/builder | call-composed-github2gerrit.yaml<br>codeql<br>dependabot-updates<br>gerrit-ci-management-merge.yaml<br>gerrit-ci-management-novote-verify.yaml<br>gerrit-packer-merge-builder.yaml<br>gerrit-packer-merge-docker.yaml<br>gerrit-packer-merge-helm.yaml<br>gerrit-packer-merge-mininet.yaml<br>gerrit-packer-merge-robot.yaml<br>gerrit-packer-verify.yaml<br>gerrit-verify.yaml<br>openstack-cron-cleanup.yaml | 13 | builder-info-yaml-verify<br>builder-jenkins-cfg-verify<br>builder-jenkins-sandbox-cleanup<br>builder-jjb-deploy-job<br>builder-openstack-cron | 5 |
| serviceutils | codeql<br>gerrit-verify.yaml<br>github2gerrit.yaml | 3 |  | 0 |
| transportpce | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | transportpce-info-yaml-verify<br>transportpce-maven-clm-titanium<br>transportpce-maven-clm-transportpce-master<br>transportpce-maven-clm-vanadium<br>transportpce-maven-merge-titanium<br>transportpce-maven-merge-transportpce-master<br>transportpce-maven-merge-vanadium<br>transportpce-maven-mri-stage-titanium<br>transportpce-maven-mri-stage-transportpce-master<br>transportpce-maven-mri-stage-vanadium<br>transportpce-maven-stage-titanium<br>transportpce-maven-stage-transportpce-master<br>transportpce-maven-stage-vanadium<br>transportpce-maven-verify-deps-titanium-mvn39-openjdk21<br>transportpce-maven-verify-deps-transportpce-master-mvn39-openjdk21<br>transportpce-maven-verify-deps-vanadium-mvn39-openjdk21<br>transportpce-maven-verify-titanium-mvn39-openjdk21<br>transportpce-maven-verify-transportpce-master-mvn39-openjdk21<br>transportpce-maven-verify-vanadium-mvn39-openjdk21<br>transportpce-release-merge-master<br>transportpce-sonar<br>transportpce-tox-verify-titanium<br>transportpce-tox-verify-transportpce-master<br>transportpce-tox-verify-vanadium | 24 |
| transportpce/models |  | 0 | transportpce-models-maven-clm-master<br>transportpce-models-maven-clm-titanium<br>transportpce-models-maven-clm-vanadium<br>transportpce-models-maven-merge-master<br>transportpce-models-maven-merge-titanium<br>transportpce-models-maven-merge-vanadium<br>transportpce-models-maven-mri-stage-master<br>transportpce-models-maven-mri-stage-titanium<br>transportpce-models-maven-mri-stage-vanadium<br>transportpce-models-maven-stage-master<br>transportpce-models-maven-stage-titanium<br>transportpce-models-maven-stage-vanadium<br>transportpce-models-maven-verify-deps-master-mvn39-openjdk21<br>transportpce-models-maven-verify-deps-titanium-mvn39-openjdk21<br>transportpce-models-maven-verify-deps-vanadium-mvn39-openjdk21<br>transportpce-models-maven-verify-master-mvn39-openjdk21<br>transportpce-models-maven-verify-titanium-mvn39-openjdk21<br>transportpce-models-maven-verify-vanadium-mvn39-openjdk21 | 18 |
| yangtools | call-github2gerrit.yaml<br>clm-scan.yaml<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml | 5 | yangtools-csit-1node-system-only-titanium<br>yangtools-csit-1node-system-only-vanadium<br>yangtools-info-yaml-verify<br>yangtools-maven-clm-master<br>yangtools-maven-clm-titanium<br>yangtools-maven-merge-master<br>yangtools-maven-merge-titanium<br>yangtools-maven-mri-stage-master<br>yangtools-maven-mri-stage-titanium<br>yangtools-maven-stage-master<br>yangtools-maven-stage-titanium<br>yangtools-maven-verify-deps-master-mvn39-openjdk21<br>yangtools-maven-verify-deps-titanium-mvn39-openjdk21<br>yangtools-maven-verify-master-mvn39-openjdk21<br>yangtools-maven-verify-titanium-mvn39-openjdk21<br>yangtools-release-merge-master<br>yangtools-sonar | 17 |
| zzz-test-release |  | 0 | zzz-test-release-maven-stage-master | 1 |

**Total:** 27 repositories with CI/CD jobs

---
## Orphaned Jenkins Jobs

These Jenkins jobs are matched to archived or read-only Gerrit projects:

### By State

- **READ_ONLY:** 14 jobs

### Job Details

| Job Name | Matched Project | State | Match Score |
|----------|----------------|-------|-------------|
| integration-update-csit-tests-titanium | integration | READ_ONLY | 550% |
| integration-multipatch-test-chromium | integration | READ_ONLY | 550% |
| integration-sanity-test-chromium | integration | READ_ONLY | 550% |
| integration-patch-test-chromium | integration | READ_ONLY | 550% |
| integration-patch-test-titanium | integration | READ_ONLY | 550% |
| integration-multipatch-test-titanium | integration | READ_ONLY | 550% |
| integration-multipatch-test-vanadium | integration | READ_ONLY | 550% |
| integration-merge-dashboard | integration | READ_ONLY | 550% |
| integration-sanity-test-titanium | integration | READ_ONLY | 550% |
| integration-update-csit-tests-chromium | integration | READ_ONLY | 550% |
| integration-info-yaml-verify | integration | READ_ONLY | 550% |
| integration-sanity-test-vanadium | integration | READ_ONLY | 550% |
| integration-patch-test-vanadium | integration | READ_ONLY | 550% |
| integration-update-csit-tests-vanadium | integration | READ_ONLY | 550% |

**Total Orphaned Jobs:** 14

---
## Unattributed Jenkins Jobs


These jobs could not be matched to any active or archived repository. They may be infrastructure jobs, release jobs, build pipelines, or jobs that use naming conventions different from the repository names. Consider reviewing the job names and repository naming patterns to improve attribution.


**Total:** 105 unattributed jobs

### Job Details

| Job Name | Status | URL |
|----------|--------|-----|
| autorelease-branch-cut | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-branch-cut/) |
| autorelease-generate-release-notes-chromium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-generate-release-notes-chromium/) |
| autorelease-generate-release-notes-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-generate-release-notes-titanium/) |
| autorelease-generate-release-notes-vanadium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-generate-release-notes-vanadium/) |
| autorelease-gerrit-branch-lock-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-gerrit-branch-lock-chromium/) |
| autorelease-gerrit-branch-lock-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-gerrit-branch-lock-titanium/) |
| autorelease-gerrit-branch-lock-vanadium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-gerrit-branch-lock-vanadium/) |
| autorelease-release-chromium-mvn39-openjdk21 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-release-chromium-mvn39-openjdk21/) |
| autorelease-release-titanium-mvn39-openjdk21 | Failed | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-release-titanium-mvn39-openjdk21/) |
| autorelease-release-vanadium-mvn39-openjdk21 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-release-vanadium-mvn39-openjdk21/) |
| autorelease-update-submodules-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-submodules-chromium/) |
| autorelease-update-submodules-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-submodules-titanium/) |
| autorelease-update-submodules-vanadium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-submodules-vanadium/) |
| autorelease-update-validate-jobs-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-validate-jobs-chromium/) |
| autorelease-update-validate-jobs-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-validate-jobs-titanium/) |
| autorelease-update-validate-jobs-vanadium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-update-validate-jobs-vanadium/) |
| autorelease-validate-autorelease-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-validate-autorelease-chromium/) |
| autorelease-validate-autorelease-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-validate-autorelease-titanium/) |
| autorelease-validate-autorelease-vanadium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-validate-autorelease-vanadium/) |
| autorelease-version-bump-chromium-mvn39-openjdk21 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-version-bump-chromium-mvn39-openjdk21/) |
| autorelease-version-bump-titanium-mvn39-openjdk21 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-version-bump-titanium-mvn39-openjdk21/) |
| autorelease-version-bump-vanadium-mvn39-openjdk21 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-version-bump-vanadium-mvn39-openjdk21/) |
| autorelease-version-management-tox-verify-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-version-management-tox-verify-chromium/) |
| autorelease-version-management-tox-verify-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-version-management-tox-verify-titanium/) |
| autorelease-version-management-tox-verify-vanadium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/autorelease-version-management-tox-verify-vanadium/) |
| builder-check-poms | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-check-poms/) |
| builder-copy-sandbox-logs | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-copy-sandbox-logs/) |
| builder-openstack-update-cloud-image | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-openstack-update-cloud-image/) |
| builder-packer-merge-centos-7-builder | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-7-builder/) |
| builder-packer-merge-centos-7-docker | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-7-docker/) |
| builder-packer-merge-centos-7-helm | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-7-helm/) |
| builder-packer-merge-centos-7-robot | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-7-robot/) |
| builder-packer-merge-centos-cs-8-builder | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-cs-8-builder/) |
| builder-packer-merge-centos-cs-8-robot | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-cs-8-robot/) |
| builder-packer-merge-centos-cs-9-builder | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-cs-9-builder/) |
| builder-packer-merge-centos-cs-9-robot | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-centos-cs-9-robot/) |
| builder-packer-merge-ubuntu-18.04-docker | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-18.04-docker/) |
| builder-packer-merge-ubuntu-18.04-helm | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-18.04-helm/) |
| builder-packer-merge-ubuntu-20.04-builder | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-20.04-builder/) |
| builder-packer-merge-ubuntu-20.04-docker | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-20.04-docker/) |
| builder-packer-merge-ubuntu-22.04-builder | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-22.04-builder/) |
| builder-packer-merge-ubuntu-22.04-docker | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-22.04-docker/) |
| builder-packer-merge-ubuntu-22.04-mininet-ovs-217 | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-22.04-mininet-ovs-217/) |
| builder-packer-merge-ubuntu-22.04-robot | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-22.04-robot/) |
| builder-packer-merge-ubuntu-24.04-builder | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-24.04-builder/) |
| builder-packer-merge-ubuntu-24.04-mininet-ovs-217 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-24.04-mininet-ovs-217/) |
| builder-packer-merge-ubuntu-24.04-robot | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-merge-ubuntu-24.04-robot/) |
| builder-packer-verify | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-verify/) |
| builder-packer-verify-build-centos-7-helm | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-verify-build-centos-7-helm/) |
| builder-packer-verify-build-ubuntu-18.04-helm | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/builder-packer-verify-build-ubuntu-18.04-helm/) |
| builder-tox-verify-master | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-tox-verify-master/) |
| builder-update-image-list | Success | [View Job](https://jenkins.opendaylight.org/releng/job/builder-update-image-list/) |
| distribution-check-managed-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-check-managed-titanium/) |
| distribution-check-managed-vanadium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-check-managed-vanadium/) |
| distribution-csit-1node-userfeatures-all-silicon | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-csit-1node-userfeatures-all-silicon/) |
| distribution-csit-managed-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-csit-managed-titanium/) |
| distribution-csit-managed-vanadium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-csit-managed-vanadium/) |
| distribution-docker-release-merge-master | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-docker-release-merge-master/) |
| distribution-docker-release-verify-master | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-docker-release-verify-master/) |
| distribution-merge-managed-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-merge-managed-titanium/) |
| distribution-merge-managed-vanadium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-merge-managed-vanadium/) |
| distribution-sanity-chromium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-sanity-chromium/) |
| distribution-sanity-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-sanity-titanium/) |
| distribution-sanity-vanadium | Failed | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-sanity-vanadium/) |
| distribution-sonar | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-sonar/) |
| distribution-verify-managed-titanium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-verify-managed-titanium/) |
| distribution-verify-managed-vanadium | Success | [View Job](https://jenkins.opendaylight.org/releng/job/distribution-verify-managed-vanadium/) |
| integration-info-yaml-verify | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-info-yaml-verify/) |
| integration-merge-dashboard | Success | [View Job](https://jenkins.opendaylight.org/releng/job/integration-merge-dashboard/) |
| integration-multipatch-test-chromium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-multipatch-test-chromium/) |
| integration-multipatch-test-titanium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-multipatch-test-titanium/) |
| integration-multipatch-test-vanadium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-multipatch-test-vanadium/) |
| integration-patch-test-chromium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-patch-test-chromium/) |
| integration-patch-test-titanium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-patch-test-titanium/) |
| integration-patch-test-vanadium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-patch-test-vanadium/) |
| integration-sanity-test-chromium | Unstable | [View Job](https://jenkins.opendaylight.org/releng/job/integration-sanity-test-chromium/) |
| integration-sanity-test-titanium | Unstable | [View Job](https://jenkins.opendaylight.org/releng/job/integration-sanity-test-titanium/) |
| integration-sanity-test-vanadium | Failed | [View Job](https://jenkins.opendaylight.org/releng/job/integration-sanity-test-vanadium/) |
| integration-update-csit-tests-chromium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-update-csit-tests-chromium/) |
| integration-update-csit-tests-titanium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-update-csit-tests-titanium/) |
| integration-update-csit-tests-vanadium | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/integration-update-csit-tests-vanadium/) |
| lf-infra-ci-workshop-tox-verify-any | Success | [View Job](https://jenkins.opendaylight.org/releng/job/lf-infra-ci-workshop-tox-verify-any/) |
| lf-infra-license-checker-tox-verify-any | Success | [View Job](https://jenkins.opendaylight.org/releng/job/lf-infra-license-checker-tox-verify-any/) |
| lf-odl-release-docker-hub | Success | [View Job](https://jenkins.opendaylight.org/releng/job/lf-odl-release-docker-hub/) |
| lf-pipelines-verify | Aborted | [View Job](https://jenkins.opendaylight.org/releng/job/lf-pipelines-verify/) |
| lf-test-release-tox-verify-tox-verify-any | Success | [View Job](https://jenkins.opendaylight.org/releng/job/lf-test-release-tox-verify-tox-verify-any/) |
| ODL-pipelines | Unknown | [View Job](https://jenkins.opendaylight.org/releng/job/ODL-pipelines/) |
| packaging-chromium-merge-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-chromium-merge-helm/) |
| packaging-chromium-release-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-chromium-release-helm/) |
| packaging-chromium-update-helm-weekly | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-chromium-update-helm-weekly/) |
| packaging-chromium-verify-helm3.5 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-chromium-verify-helm3.5/) |
| packaging-chromium-verify-helm3.7 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-chromium-verify-helm3.7/) |
| packaging-k8s-odl-deploy-test | Failed | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-k8s-odl-deploy-test/) |
| packaging-release-merge-master | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-release-merge-master/) |
| packaging-release-verify-master | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-release-verify-master/) |
| packaging-titanium-merge-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-titanium-merge-helm/) |
| packaging-titanium-release-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-titanium-release-helm/) |
| packaging-titanium-update-helm-weekly | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-titanium-update-helm-weekly/) |
| packaging-titanium-verify-helm3.5 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-titanium-verify-helm3.5/) |
| packaging-titanium-verify-helm3.7 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-titanium-verify-helm3.7/) |
| packaging-vanadium-merge-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-vanadium-merge-helm/) |
| packaging-vanadium-release-helm | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-vanadium-release-helm/) |
| packaging-vanadium-update-helm-weekly | Disabled | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-vanadium-update-helm-weekly/) |
| packaging-vanadium-verify-helm3.5 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-vanadium-verify-helm3.5/) |
| packaging-vanadium-verify-helm3.7 | Not Built | [View Job](https://jenkins.opendaylight.org/releng/job/packaging-vanadium-verify-helm3.7/) |

---
## 📋 Committer INFO.yaml Report

## 📋 Committer INFO.yaml Report

This report shows project information from INFO.yaml files, including lifecycle state, project leads, and committer activity status.

| Project | Creation Date | Lifecycle State | Project Lead | Committers |
|---------|---------------|-----------------|--------------|------------|
| <a href="https://jira.opendaylight.org/projects/" target="_blank">.github</a> | 2023-11-7 | Incubation | <span style="color: gray;" title="Unknown activity status">Anil Belur</span> | <span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Andrew Grimberg</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Guillaume Lambert</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Jamo Luhrsen</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Luis Gomez</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Robert Varga</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Sangwook Ha</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Thanh Ha</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Venkatrangan Govindarajan</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">aaa</a> | 2014-05-15 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Mohamed ElSerngawy</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">alt_datastores</a> | 2019-04-04 | Incubation | <span style="color: gray;" title="Unknown activity status">Michael Vorburger</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Anil Belur</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Jie Han</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Quan Xiong</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">li jiansong</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Guobiao Mo</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Zhang Min</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Kaiwen Jin</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">archetypes</a> | 2018-02-27 | Incubation | <span style="color: gray;" title="Unknown activity status">Michael Vorburger</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Stephen Kitt</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Tom Pantelis</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Sam Hague</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">bgpcep</a> | 2013-07-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Claudio David Gasparini</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Dana Kutenicsova</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ajay Lele</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Olivier Dugeon</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">bier</a> | 22-06-2017 | Incubation | <span style="color: gray;" title="Unknown activity status">Quan Xiong</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">coe</a> | 2017-01-05 | Incubation | <span style="color: gray;" title="Unknown activity status">Faseela K</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Sam Hague</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Isaku Yamahata</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Yi Yang</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Shai Amir</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Mohamed ElSerngawy</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Andre Fredette</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Frederick Kautz</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Prem Sankar G</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">controller</a> | 2015-01-08 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Stephen Kitt</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ed Warnicke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Michael Vorburger</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Vishnoi</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">daexim</a> | 2016-10-13 | Incubation | <span style="color: gray;" title="Unknown activity status">Shaleen Saxena</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Anton Ivanov</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Michael Vorburger</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">sreekalyan devaraj</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Balaji Varadaraju</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ajay Lele</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Richard Kosegi</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">detnet</a> | 2018-12-13 | Incubation | <span style="color: gray;" title="Unknown activity status">Quan Xiong</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Anil Belur</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">dluxapps</a> | 2016-10-27 | Incubation | <span style="color: gray;" title="Unknown activity status">Daniel Malachovsky</span> | <span style="color: gray;" title="Unknown activity status">Stanislav Jamrich</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">docs</a> | 2014-03-26 | Incubation | <span style="color: gray;" title="Unknown activity status">Ivan Hraško</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Guillaume Lambert</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha (zxiiro)</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Daniel Farrell</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">genius</a> | 2016-03-24 | Incubation | <span style="color: gray;" title="Unknown activity status">Hema Gopalakrishnan</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Faseela K</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Chetan Arakere Gowdru</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">gnmi</a> | 2025-10-25 | Incubation | <span style="color: gray;" title="Unknown activity status">Ivan Hraško</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">groupbasedpolicy</a> | 2014-03-23 | Incubation | <span style="color: gray;" title="Unknown activity status">Michal Cmarada</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Keith Burns</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Rob Adams</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Tomas Cechvala</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Martin Sunal</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">honeycomb_vbd</a> | 2016-03-17 | Incubation | <span style="color: gray;" title="Unknown activity status">Michal Cmarada</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Ed Warnicke</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Daniel Malachovsky</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Marek Gradzki</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Robert Varga</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">ietf</a> | 2025-09-01 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jie Han</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">infrautils</a> | 2016-03-17 | Incubation | <span style="color: gray;" title="Unknown activity status">Faseela K</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Robert Varga</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Michael Vorburger</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">integration</a> | 2015-08-20 | Incubation | <span style="color: gray;" title="Unknown activity status">Luis Gomez</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha (zxiiro)</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Belur</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">integration_packaging</a> | 2015-08-20 | Incubation | <span style="color: gray;" title="Unknown activity status">Anil Belur</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Jamo Luhrsen</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Thanh Ha (zxiiro)</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Tim Rozet</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Daniel Farrell</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">integration_test</a> | 2015-08-20 | Incubation | <span style="color: gray;" title="Unknown activity status">Venkatrangan Govindarajan (Rangan)</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Sangwook Ha</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tomas Cere</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">jsonrpc</a> | 2016-04-21 | Incubation | <span style="color: gray;" title="Unknown activity status">Anton Ivanov</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">David Spence</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Shaleen Saxena</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Richard Kosegi</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">l2switch</a> | 2014-05-15 | Incubation | <span style="color: gray;" title="Unknown activity status">Hema Gopalakrishnan</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Sai MarapaReddy</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Evan Zeller</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Belur</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Robert Varga</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Abhijit Kumbhare</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Faseela K</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Venkatrangan Govindarajan</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tejas Nevrekar</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Balaji Varadaraju</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Arunprakash D</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">lispflowmapping</a> | 2013-07-13 | Incubation | <span style="color: gray;" title="Unknown activity status">Lori Jakab</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Florin Coras</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vina Ermagan</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">mdsal</a> | 2014-04-17 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Tom Pantelis</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jie Han</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">nemo</a> | 2015-05-08 | Incubation | <span style="color: gray;" title="Unknown activity status">A H</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">netconf</a> | 2020-06-25 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Tomáš Cére</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ivan Hraško</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">netvirt</a> | 2020-06-25 | Incubation | <span style="color: gray;" title="Unknown activity status">Karthikeyan Krishnan</span> | <span style="color: gray;" title="Unknown activity status">Stephen Kitt</span><br><span style="color: gray;" title="Unknown activity status">Chetan Arakere Gowdru</span><br><span style="color: gray;" title="Unknown activity status">Shashidhar Raja</span><br><span style="color: gray;" title="Unknown activity status">Manu B</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">neutron</a> | 2015-02-12 | Incubation | <span style="color: gray;" title="Unknown activity status">Achuth Maniyedath</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Karthikeyan Krishnan</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">odlguice</a> | 2020-03-19 | Incubation | <span style="color: gray;" title="Unknown activity status">Tejas Nevrekar</span> | <span style="color: gray;" title="Unknown activity status">Jamo Luhrsen</span><br><span style="color: gray;" title="Unknown activity status">Ravi Sankar</span><br><span style="color: gray;" title="Unknown activity status">Nikhil Soni</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">odlmicro</a> | 2020-03-19 | Incubation | <span style="color: gray;" title="Unknown activity status">Tejas Nevrekar</span> | <span style="color: gray;" title="Unknown activity status">Jamo Luhrsen</span><br><span style="color: gray;" title="Unknown activity status">Dhiman Ghosh</span><br><span style="color: gray;" title="Unknown activity status">Ravi Sankar</span><br><span style="color: gray;" title="Unknown activity status">Nikhil Soni</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">odlparent</a> | 2014-04-24 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Stephen Kitt</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Michael Vorburger</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">odlsaf</a> | 2020-20-04 | Incubation | <span style="color: gray;" title="Unknown activity status">Prem Sankar Gopannan</span> | <span style="color: gray;" title="Unknown activity status">Richard Kosegi</span><br><span style="color: gray;" title="Unknown activity status">Kanagasundaram  K</span><br><span style="color: gray;" title="Unknown activity status">Pravin Kumar Damodaran</span><br><span style="color: gray;" title="Unknown activity status">Mahesh Lokhande</span><br><span style="color: gray;" title="Unknown activity status">Jeff Hartley</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">odltools</a> | 2020-06-25 | Incubation | <span style="color: gray;" title="Unknown activity status">Tim Rozet</span> | <span style="color: gray;" title="Unknown activity status">Sam Hague</span><br><span style="color: gray;" title="Unknown activity status">Jamo Luhrsen</span><br><span style="color: gray;" title="Unknown activity status">Hema Gopalakrishnan</span><br><span style="color: gray;" title="Unknown activity status">Vishal Thapar</span><br><span style="color: gray;" title="Unknown activity status">Faseela K</span><br><span style="color: gray;" title="Unknown activity status">Deepthi V V</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">of_config</a> | 2015-08-27 | Incubation | <span style="color: gray;" title="Unknown activity status">WEI MENG</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">ANANTHA RAMAIAH</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">openflowplugin</a> | 2013-07-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Sangwook Ha</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Gobinath Suganthan</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Robert Varga</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">opflex</a> | 2014-05-02 | Incubation | <span style="color: gray;" title="Unknown activity status">Tom Flynn</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Rob Adams</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Amit Bose</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">ovsdb</a> | 2013-07-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Chetan Arakere Gowdru</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Sam Hague</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Stephen Kitt</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Vishnoi</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vishal Thapar</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">p4plugin</a> | 2017-06-22 | Incubation | <span style="color: gray;" title="Unknown activity status">Ding Rui</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">plastic</a> | 2019-11-01 | Incubation | <span style="color: gray;" title="Unknown activity status">Allan Clarke</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">releng_autorelease</a> | 2015-01-08 | Incubation | <span style="color: gray;" title="Unknown activity status">Anil Belur</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">A H</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha (zxiiro)</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Kit Lou</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Sam Hague</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">releng_builder</a> | 2014-10-22 | Incubation | <span style="color: gray;" title="Unknown activity status">Anil Belur</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Andrew Grimberg</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Guillaume Lambert</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jamo Luhrsen</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Luis Gomez</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Robert Varga</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Sangwook Ha</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Thanh Ha</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Venkatrangan Govindarajan</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">serviceutils</a> | 2018-06-14 | Incubation | <span style="color: gray;" title="Unknown activity status">Faseela K</span> | <span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Sam Hague</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Michael Vorburger</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Vishal Thapar</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">David Suárez Fuentes</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">sfc</a> |  | Incubation | <span style="color: gray;" title="Unknown activity status">Brady Johnson</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Yi Yang</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Reinaldo Penno</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Vinayak Joshi</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Jaime Caamaño Ruiz</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">David Suárez Fuentes</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">snmp4sdn</a> | 2013-08-15 | Incubation | <span style="color: gray;" title="Unknown activity status">Christine Hsieh</span> | None |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">sxp</a> | 2014-09-12 | Incubation | <span style="color: gray;" title="Unknown activity status">Ivan Hrasko</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Martin Dindoffer</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">telemetry</a> | 2018-03-14 | Incubation | <span style="color: gray;" title="Unknown activity status">wang senxiao</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Ding Rui</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Wang Senxiao</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">huan linying</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">li jiansong</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">transportpce</a> | 2016-05-26 | Incubation | <span style="color: gray;" title="Unknown activity status">Gilles Thouenon</span> | <span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Christophe Betoule</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Balagangadhar Bathula</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Guillaume Lambert</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Shweta Vachhani</span><br><span style="color: orange;" title="☑️ Active - commits between 365-1095 days">Cédric Ollivier</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">transportpce_models</a> | 2022-08-12 | Incubation | <span style="color: gray;" title="Unknown activity status">Gilles Thouenon</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Christophe Betoule</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Balagangadhar Bathula</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Guillaume Lambert</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Shweta Vachhani</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Cedric Ollivier</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">tsdr</a> | 2014-12-11 | Incubation | <span style="color: gray;" title="Unknown activity status">Scott Melton</span> | <span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Syed B.  Ahmed</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">Tom Pantelis</span><br><span style="color: red;" title="🛑 Inactive - no commits in 1095+ days">YuLing Chen</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">unimgr</a> | 2015-08-13 | Incubation | <span style="color: gray;" title="Unknown activity status">Donald Hunter</span> | <span style="color: gray;" title="Unknown activity status">Bartosz Michalik</span><br><span style="color: gray;" title="Unknown activity status">Mohamed ElSerngawy</span><br><span style="color: gray;" title="Unknown activity status">Gabriel Robitaille-Montpetit</span><br><span style="color: gray;" title="Unknown activity status">Mahesh Jethanandani</span><br><span style="color: gray;" title="Unknown activity status">Santanu De</span> |
| <a href="https://jira.opendaylight.org/projects/" target="_blank">yangtools</a> | 2013-07-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Robert Varga</span> | None |


---

## 📊 INFO.yaml Lifecycle State Summary

### Lifecycle State Summary

| Lifecycle State | Gerrit Project Count | Percentage |
|----------------|---------------------|------------|
| Incubation | 52 | 100.0% |

**Total Projects:** 52
---

---*Generated with ❤️ by Release Engineering*