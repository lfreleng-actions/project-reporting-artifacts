# 📊 Gerrit Project Analysis Report: LF Broadband

**Generated:** 2026-07-18 07:32:14 UTC
**Schema Version:** 1.5.0

---## Table of Contents

- [Global Summary](#summary)
- [Gerrit Projects](#repositories)
- [Top Contributors](#contributors)
- [Top Organizations](#organizations)
- [Repository Feature Matrix](#features)
- [Deployed CI/CD Jobs](#workflows)
- [Orphaned Jenkins Jobs](#orphaned-jobs)
- [Unattributed Jenkins Jobs](#unattributed-jobs)

---

## 📈 Global Summary

**✅ Current** commits within last 365 days

**☑️ Active** commits between 365-1095 days

**🛑 Inactive** no commits in 1095+ days

| Metric | Count | Percentage |
| --- | --- | --- |
| Total Gerrit Projects | 255 | 100% |
| Current Gerrit Projects | 20 | 7.8% |
| Active Gerrit Projects | 30 | 11.8% |
| Inactive Gerrit Projects | 203 | 79.6% |
| No Apparent Commits | 2 | 0.8% |
| Total Commits | 35.3K | - |
| Total Lines of Code | 2.9M | - |

---
## 🏢 Top Organizations

The data presented in the table below covers the past 365 days.

**Organizations Found:** 269

| Rank | Organization | Contributors | Commits | LOC | Δ LOC | Avg LOC/Commit | Unique Repositories |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | radisys.com | 50 | 155 | +1919915 | 2646477 | +7699 | 32 |
| 2 | linuxfoundation.org | 3 | 81 | +7581 | 9922 | +64 | 38 |
| 3 | opennetworking.org | 56 | 12 | +1435 | 1447 | +118 | 233 |
| 4 | netsia.com | 15 | 11 | +621 | 1230 | +1 | 32 |
| 5 | github.com | 6 | 7 | +8 | 16 | 0 | 6 |
| 6 | 10ur.org | 1 | 0 | 0 | 0 | 0 | 1 |
| 7 | 14v.de | 1 | 0 | 0 | 0 | 0 | 1 |
| 8 | 163.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 9 | 6wind.com | 4 | 0 | 0 | 0 | 0 | 1 |
| 10 | 99cloud.net | 1 | 0 | 0 | 0 | 0 | 1 |
| 11 | ac.jp | 1 | 0 | 0 | 0 | 0 | 1 |
| 12 | ac.uk | 1 | 0 | 0 | 0 | 0 | 1 |
| 13 | accton.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 14 | ad.jp | 2 | 0 | 0 | 0 | 0 | 1 |
| 15 | adtran.com | 7 | 0 | 0 | 0 | 0 | 16 |
| 16 | akamai.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 17 | alt.net | 1 | 0 | 0 | 0 | 0 | 1 |
| 18 | altencalsoftlabs.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 19 | altlinux.ru | 1 | 0 | 0 | 0 | 0 | 1 |
| 20 | amazon.com | 5 | 0 | 0 | 0 | 0 | 1 |
| 21 | android.com | 9 | 0 | 0 | 0 | 0 | 1 |
| 22 | angband.pl | 1 | 0 | 0 | 0 | 0 | 1 |
| 23 | arcor.de | 1 | 0 | 0 | 0 | 0 | 1 |
| 24 | argon.org | 1 | 0 | 0 | 0 | 0 | 1 |
| 25 | aristanetworks.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 26 | arizona.edu | 2 | 0 | 0 | 0 | 0 | 28 |
| 27 | arm.com | 2 | 0 | 0 | 0 | 0 | 2 |
| 28 | artisancomputer.com | 1 | 0 | 0 | 0 | 0 | 12 |
| 29 | atcorp.com | 2 | 0 | 0 | 0 | 0 | 1 |
| 30 | ate-mahoroba.jp | 1 | 0 | 0 | 0 | 0 | 1 |

---
## 👥 Top Contributors

The data presented in the table below covers the past 365 days.

**Contributors Found:** 820

| Rank | Contributor | Commits | LOC | Δ LOC | Avg LOC/Commit | Repositories | Organization |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Eric Ball | 81 | +7581 | 9922 | +64 | 31 | linuxfoundation.org |
| 2 | akashreddyk | 35 | +3861 | 6233 | +42 | 11 | radisys.com |
| 3 | bseeniva | 33 | +162346 | 309726 | +453 | 6 | radisys.com |
| 4 | balaji.nagarajan | 27 | +144745 | 231041 | +2164 | 7 | radisys.com |
| 5 | Abhay Kumar | 22 | +1600527 | 2087387 | +50621 | 9 | radisys.com |
| 6 | madhumatigouda | 21 | +3619 | 5369 | +89 | 8 | radisys.com |
| 7 | Jenkins | 12 | +1435 | 1447 | +118 | 12 | opennetworking.org |
| 8 | Serkant Uluderya | 11 | +621 | 1230 | +1 | 13 | netsia.com |
| 9 | Sridhar Ravindra | 8 | +1160 | 1561 | +94 | 8 | radisys.com |
| 10 | dependabot[bot] | 7 | +8 | 16 | 0 | 1 | github.com |
| 11 | praneeth.nalmas | 6 | +1577 | 2342 | +135 | 11 | radisys.com |
| 12 | Abhilash Laxmeshwar | 2 | +718 | 1220 | +108 | 11 | radisys.com |
| 13 | Amit Ghosh | 1 | +1362 | 1598 | +1126 | 13 | radisys.com |
| 14 | A R Karthick | 0 | 0 | 0 | 0 | 7 | ciena.com |
| 15 | A R Karthick | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 16 | A R. Karthick | 0 | 0 | 0 | 0 | 1 | cyaninc.com |
| 17 | Aaron Kruglikov | 0 | 0 | 0 | 0 | 1 | fujitsu.com |
| 18 | Abhilash Endurthi | 0 | 0 | 0 | 0 | 1 | opennetworking.org |
| 19 | Adam Borowski | 0 | 0 | 0 | 0 | 1 | angband.pl |
| 20 | Aharoni, Pavel (pa0916) | 0 | 0 | 0 | 0 | 1 | att.com |
| 21 | Ajay Lotan Thakur | 0 | 0 | 0 | 0 | 3 | gmail.com |
| 22 | Ajay Lotan Thakur | 0 | 0 | 0 | 0 | 4 | intel.com |
| 23 | Akash Soni | 0 | 0 | 0 | 0 | 8 | radisys.com |
| 24 | Akshay Verma | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 25 | Alex Yashchuk | 0 | 0 | 0 | 0 | 1 | cavium.com |
| 26 | Alexander Bird | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 27 | Alexandre Boeglin | 0 | 0 | 0 | 0 | 1 | parrot.com |
| 28 | Alexandre Chappuis | 0 | 0 | 0 | 0 | 1 | open.ch |
| 29 | Alexandre Garnier | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 30 | Alexis Fasquel | 0 | 0 | 0 | 0 | 1 | pch.net |

---
## 📊 Gerrit Projects

| Gerrit Project | Commits | LOC | Contributors | Days Inactive | Last Commit Date | Status |
| --- | --- | --- | --- | --- | --- | --- |
| [xos](https://gerrit.lfbroadband.org/admin/repos/xos,general) | 6878 | 0 | 0 | 2193 | 2020-07-15 | 🛑 |
| [ci-management](https://gerrit.lfbroadband.org/admin/repos/ci-management,general) | 3965 | +436 | 4 | 15 | 2026-07-02 | ✅ |
| [quagga](https://gerrit.lfbroadband.org/admin/repos/quagga,general) | 3955 | 0 | 0 | 3235 | 2017-09-07 | 🛑 |
| [pod-configs](https://gerrit.lfbroadband.org/admin/repos/pod-configs,general) | 1434 | +14 | 1 | 213 | 2025-12-16 | ✅ |
| [cord-tester](https://gerrit.lfbroadband.org/admin/repos/cord-tester,general) | 1312 | 0 | 0 | 462 | 2025-04-11 | ☑️ |
| [fabric-oftest](https://gerrit.lfbroadband.org/admin/repos/fabric-oftest,general) | 1221 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [voltha-system-tests](https://gerrit.lfbroadband.org/admin/repos/voltha-system-tests,general) | 1117 | +291 | 2 | 106 | 2026-04-02 | ✅ |
| [repo](https://gerrit.lfbroadband.org/admin/repos/repo,general) | 988 | 0 | 0 | 2741 | 2019-01-14 | 🛑 |
| [platform-install](https://gerrit.lfbroadband.org/admin/repos/platform-install,general) | 841 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [helm-charts](https://gerrit.lfbroadband.org/admin/repos/helm-charts,general) | 733 | 0 | 0 | 1412 | 2022-09-04 | 🛑 |
| [cord-charts-repo](https://gerrit.lfbroadband.org/admin/repos/cord-charts-repo,general) | 682 | +1435 | 1 | 129 | 2026-03-11 | ✅ |
| [voltha-go](https://gerrit.lfbroadband.org/admin/repos/voltha-go,general) | 678 | +311049 | 6 | 2 | 2026-07-16 | ✅ |
| [cord](https://gerrit.lfbroadband.org/admin/repos/cord,general) | 600 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [voltha-openolt-adapter](https://gerrit.lfbroadband.org/admin/repos/voltha-openolt-adapter,general) | 544 | +482737 | 6 | 30 | 2026-06-17 | ✅ |
| [voltha-openonu-adapter-go](https://gerrit.lfbroadband.org/admin/repos/voltha-openonu-adapter-go,general) | 444 | +208466 | 7 | 152 | 2026-02-16 | ✅ |
| [bbsim](https://gerrit.lfbroadband.org/admin/repos/bbsim,general) | 416 | 0 | 0 | 569 | 2024-12-26 | ☑️ |
| [docs](https://gerrit.lfbroadband.org/admin/repos/docs,general) | 396 | 0 | 0 | 1886 | 2021-05-18 | 🛑 |
| [olt](https://gerrit.lfbroadband.org/admin/repos/olt,general) | 339 | 0 | 0 | 546 | 2025-01-17 | ☑️ |
| [voltha-helm-charts](https://gerrit.lfbroadband.org/admin/repos/voltha-helm-charts,general) | 300 | +649 | 4 | 4 | 2026-07-13 | ✅ |
| [maas](https://gerrit.lfbroadband.org/admin/repos/maas,general) | 294 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [xos-gui](https://gerrit.lfbroadband.org/admin/repos/xos-gui,general) | 291 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [vtn](https://gerrit.lfbroadband.org/admin/repos/vtn,general) | 277 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [service-profile](https://gerrit.lfbroadband.org/admin/repos/service-profile,general) | 266 | 0 | 0 | 3361 | 2017-05-04 | 🛑 |
| [openolt](https://gerrit.lfbroadband.org/admin/repos/openolt,general) | 263 | +23 | 1 | 163 | 2026-02-05 | ✅ |
| [voltha-lib-go](https://gerrit.lfbroadband.org/admin/repos/voltha-lib-go,general) | 243 | +411212 | 7 | 72 | 2026-05-06 | ✅ |
| [aaa](https://gerrit.lfbroadband.org/admin/repos/aaa,general) | 239 | +122 | 1 | 164 | 2026-02-03 | ✅ |
| [voltha-docs](https://gerrit.lfbroadband.org/admin/repos/voltha-docs,general) | 228 | +1487 | 2 | 18 | 2026-06-29 | ✅ |
| [roc-helm-charts](https://gerrit.lfbroadband.org/admin/repos/roc-helm-charts,general) | 224 | 0 | 0 | 1151 | 2023-05-23 | 🛑 |
| [automation-tools](https://gerrit.lfbroadband.org/admin/repos/automation-tools,general) | 216 | 0 | 0 | 2124 | 2020-09-22 | 🛑 |
| [voltctl](https://gerrit.lfbroadband.org/admin/repos/voltctl,general) | 196 | +145783 | 2 | 2 | 2026-07-15 | ✅ |
| [voltha-protos](https://gerrit.lfbroadband.org/admin/repos/voltha-protos,general) | 179 | +121396 | 6 | 23 | 2026-06-24 | ✅ |
| [sdcore-helm-charts](https://gerrit.lfbroadband.org/admin/repos/sdcore-helm-charts,general) | 172 | 0 | 0 | 1149 | 2023-05-25 | 🛑 |
| [olt-service](https://gerrit.lfbroadband.org/admin/repos/olt-service,general) | 148 | 0 | 0 | 2299 | 2020-03-31 | 🛑 |
| [voltha-onos](https://gerrit.lfbroadband.org/admin/repos/voltha-onos,general) | 148 | 0 | 0 | 807 | 2024-05-01 | ☑️ |
| [dhcpl2relay](https://gerrit.lfbroadband.org/admin/repos/dhcpl2relay,general) | 144 | 0 | 0 | 546 | 2025-01-17 | ☑️ |
| [rcord](https://gerrit.lfbroadband.org/admin/repos/rcord,general) | 140 | 0 | 0 | 2235 | 2020-06-03 | 🛑 |
| [cord-onos-publisher](https://gerrit.lfbroadband.org/admin/repos/cord-onos-publisher,general) | 139 | 0 | 0 | 2375 | 2020-01-15 | 🛑 |
| [mcast](https://gerrit.lfbroadband.org/admin/repos/mcast,general) | 132 | 0 | 0 | 546 | 2025-01-17 | ☑️ |
| [sadis](https://gerrit.lfbroadband.org/admin/repos/sadis,general) | 131 | 0 | 0 | 547 | 2025-01-16 | ☑️ |
| [kafka-onos](https://gerrit.lfbroadband.org/admin/repos/kafka-onos,general) | 124 | 0 | 0 | 546 | 2025-01-17 | ☑️ |
| [manifest](https://gerrit.lfbroadband.org/admin/repos/manifest,general) | 121 | 0 | 0 | 2376 | 2020-01-14 | 🛑 |
| [fabric](https://gerrit.lfbroadband.org/admin/repos/fabric,general) | 113 | 0 | 0 | 2212 | 2020-06-26 | 🛑 |
| [ofagent-go](https://gerrit.lfbroadband.org/admin/repos/ofagent-go,general) | 111 | 0 | 0 | 547 | 2025-01-16 | ☑️ |
| [igmpproxy](https://gerrit.lfbroadband.org/admin/repos/igmpproxy,general) | 101 | 0 | 0 | 547 | 2025-01-17 | ☑️ |
| [onos-service](https://gerrit.lfbroadband.org/admin/repos/onos-service,general) | 94 | 0 | 0 | 2299 | 2020-03-31 | 🛑 |
| [igmp](https://gerrit.lfbroadband.org/admin/repos/igmp,general) | 88 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [voltha-go-controller](https://gerrit.lfbroadband.org/admin/repos/voltha-go-controller,general) | 87 | +237549 | 7 | 20 | 2026-06-27 | ✅ |
| [openstack](https://gerrit.lfbroadband.org/admin/repos/openstack,general) | 87 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [sdcore-docs](https://gerrit.lfbroadband.org/admin/repos/sdcore-docs,general) | 87 | 0 | 0 | 1022 | 2023-09-29 | ☑️ |
| [device-management-interface](https://gerrit.lfbroadband.org/admin/repos/device-management-interface,general) | 83 | +1643 | 4 | 23 | 2026-06-24 | ✅ |
| [mcord](https://gerrit.lfbroadband.org/admin/repos/mcord,general) | 78 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [fpcagent](https://gerrit.lfbroadband.org/admin/repos/fpcagent,general) | 75 | 0 | 0 | 3038 | 2018-03-23 | 🛑 |
| [sdfabric-docs](https://gerrit.lfbroadband.org/admin/repos/sdfabric-docs,general) | 74 | 0 | 0 | 1432 | 2022-08-15 | 🛑 |
| [asfvolt16-driver](https://gerrit.lfbroadband.org/admin/repos/asfvolt16-driver,general) | 73 | 0 | 0 | 2851 | 2018-09-26 | 🛑 |
| [vsg](https://gerrit.lfbroadband.org/admin/repos/vsg,general) | 71 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [exampleservice](https://gerrit.lfbroadband.org/admin/repos/exampleservice,general) | 67 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [att-workflow-driver](https://gerrit.lfbroadband.org/admin/repos/att-workflow-driver,general) | 65 | 0 | 0 | 2242 | 2020-05-27 | 🛑 |
| [xos-tosca](https://gerrit.lfbroadband.org/admin/repos/xos-tosca,general) | 65 | 0 | 0 | 2339 | 2020-02-20 | 🛑 |
| [vrouter](https://gerrit.lfbroadband.org/admin/repos/vrouter,general) | 64 | 0 | 0 | 2299 | 2020-03-31 | 🛑 |
| [vtr](https://gerrit.lfbroadband.org/admin/repos/vtr,general) | 63 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [onf-make](https://gerrit.lfbroadband.org/admin/repos/onf-make,general) | 60 | 0 | 0 | 634 | 2024-10-21 | ☑️ |
| [plyxproto](https://gerrit.lfbroadband.org/admin/repos/plyxproto,general) | 58 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [composer](https://gerrit.lfbroadband.org/admin/repos/composer,general) | 55 | 0 | 0 | 3459 | 2017-01-26 | 🛑 |
| [kubernetes-service](https://gerrit.lfbroadband.org/admin/repos/kubernetes-service,general) | 55 | 0 | 0 | 2299 | 2020-03-31 | 🛑 |
| [sdfabric-helm-charts](https://gerrit.lfbroadband.org/admin/repos/sdfabric-helm-charts,general) | 55 | 0 | 0 | 1325 | 2022-11-30 | 🛑 |
| [bng](https://gerrit.lfbroadband.org/admin/repos/bng,general) | 53 | 0 | 0 | 546 | 2025-01-17 | ☑️ |
| [person-detection-app](https://gerrit.lfbroadband.org/admin/repos/person-detection-app,general) | 53 | 0 | 0 | 1499 | 2022-06-09 | 🛑 |
| [config](https://gerrit.lfbroadband.org/admin/repos/config,general) | 50 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [chameleon](https://gerrit.lfbroadband.org/admin/repos/chameleon,general) | 48 | 0 | 0 | 2339 | 2020-02-20 | 🛑 |
| [ecord](https://gerrit.lfbroadband.org/admin/repos/ecord,general) | 47 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [monitoring](https://gerrit.lfbroadband.org/admin/repos/monitoring,general) | 46 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [progran](https://gerrit.lfbroadband.org/admin/repos/progran,general) | 44 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [simpleexampleservice](https://gerrit.lfbroadband.org/admin/repos/simpleexampleservice,general) | 44 | 0 | 0 | 2237 | 2020-06-01 | 🛑 |
| [vspgwc](https://gerrit.lfbroadband.org/admin/repos/vspgwc,general) | 43 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [fabric-crossconnect](https://gerrit.lfbroadband.org/admin/repos/fabric-crossconnect,general) | 42 | 0 | 0 | 2215 | 2020-06-24 | 🛑 |
| [ansible/onf-ansible](https://gerrit.lfbroadband.org/admin/repos/ansible/onf-ansible,general) | 41 | 0 | 0 | 1558 | 2022-04-11 | 🛑 |
| [omci-lib-go](https://gerrit.lfbroadband.org/admin/repos/omci-lib-go,general) | 38 | +83 | 1 | 333 | 2025-08-19 | ✅ |
| [cordctl](https://gerrit.lfbroadband.org/admin/repos/cordctl,general) | 38 | 0 | 0 | 2272 | 2020-04-27 | 🛑 |
| [vMME](https://gerrit.lfbroadband.org/admin/repos/vMME,general) | 38 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [epc-service](https://gerrit.lfbroadband.org/admin/repos/epc-service,general) | 36 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [carrierethernet](https://gerrit.lfbroadband.org/admin/repos/carrierethernet,general) | 35 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [mac-learning](https://gerrit.lfbroadband.org/admin/repos/mac-learning,general) | 35 | 0 | 0 | 546 | 2025-01-17 | ☑️ |
| [helm-repo-tools](https://gerrit.lfbroadband.org/admin/repos/helm-repo-tools,general) | 34 | 0 | 0 | 542 | 2025-01-21 | ☑️ |
| [voltha-api-server](https://gerrit.lfbroadband.org/admin/repos/voltha-api-server,general) | 34 | 0 | 0 | 988 | 2023-11-02 | ☑️ |
| [vspgwu](https://gerrit.lfbroadband.org/admin/repos/vspgwu,general) | 34 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [device-management](https://gerrit.lfbroadband.org/admin/repos/device-management,general) | 33 | 0 | 0 | 1915 | 2021-04-19 | 🛑 |
| [kafka-topic-exporter](https://gerrit.lfbroadband.org/admin/repos/kafka-topic-exporter,general) | 32 | 0 | 0 | 1576 | 2022-03-25 | 🛑 |
| [pppoeagent](https://gerrit.lfbroadband.org/admin/repos/pppoeagent,general) | 31 | 0 | 0 | 546 | 2025-01-17 | ☑️ |
| [xos-external-app-examples](https://gerrit.lfbroadband.org/admin/repos/xos-external-app-examples,general) | 31 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [xos-rest-gw](https://gerrit.lfbroadband.org/admin/repos/xos-rest-gw,general) | 31 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [comac-helm-charts](https://gerrit.lfbroadband.org/admin/repos/comac-helm-charts,general) | 30 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [voltha-docker-tools](https://gerrit.lfbroadband.org/admin/repos/voltha-docker-tools,general) | 29 | +210 | 3 | 21 | 2026-06-26 | ✅ |
| [network-diag-app](https://gerrit.lfbroadband.org/admin/repos/network-diag-app,general) | 29 | 0 | 0 | 1271 | 2023-01-24 | 🛑 |
| [vnaas](https://gerrit.lfbroadband.org/admin/repos/vnaas,general) | 28 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [hippie-oss](https://gerrit.lfbroadband.org/admin/repos/hippie-oss,general) | 27 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [venb](https://gerrit.lfbroadband.org/admin/repos/venb,general) | 27 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [xran-controller](https://gerrit.lfbroadband.org/admin/repos/xran-controller,general) | 27 | 0 | 0 | 3145 | 2017-12-06 | 🛑 |
| [VOLTHA-Projects](https://gerrit.lfbroadband.org/admin/repos/VOLTHA-Projects,general) | 26 | 0 | 0 | 602 | 2024-11-22 | ☑️ |
| [vEG](https://gerrit.lfbroadband.org/admin/repos/vEG,general) | 26 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [addressmanager](https://gerrit.lfbroadband.org/admin/repos/addressmanager,general) | 25 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [vEE](https://gerrit.lfbroadband.org/admin/repos/vEE,general) | 23 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [vtn-service](https://gerrit.lfbroadband.org/admin/repos/vtn-service,general) | 23 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [infra-manifest](https://gerrit.lfbroadband.org/admin/repos/infra-manifest,general) | 22 | 0 | 0 | 1458 | 2022-07-20 | 🛑 |
| [olttopology](https://gerrit.lfbroadband.org/admin/repos/olttopology,general) | 22 | 0 | 0 | 901 | 2024-01-28 | ☑️ |
| [seba](https://gerrit.lfbroadband.org/admin/repos/seba,general) | 22 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [vHSS](https://gerrit.lfbroadband.org/admin/repos/vHSS,general) | 22 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [vsg-hw](https://gerrit.lfbroadband.org/admin/repos/vsg-hw,general) | 22 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [fabric-tofino](https://gerrit.lfbroadband.org/admin/repos/fabric-tofino,general) | 21 | 0 | 0 | 1703 | 2021-11-17 | 🛑 |
| [metro-net](https://gerrit.lfbroadband.org/admin/repos/metro-net,general) | 21 | 0 | 0 | 3235 | 2017-09-07 | 🛑 |
| [shared-workflows](https://gerrit.lfbroadband.org/admin/repos/shared-workflows,general) | 20 | +4822 | 1 | 4 | 2026-07-13 | ✅ |
| [bbsim-sadis-server](https://gerrit.lfbroadband.org/admin/repos/bbsim-sadis-server,general) | 19 | 0 | 0 | 546 | 2025-01-17 | ☑️ |
| [onf-scripts](https://gerrit.lfbroadband.org/admin/repos/onf-scripts,general) | 19 | 0 | 0 | 688 | 2024-08-28 | ☑️ |
| [vPGWC](https://gerrit.lfbroadband.org/admin/repos/vPGWC,general) | 19 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [sadis-server](https://gerrit.lfbroadband.org/admin/repos/sadis-server,general) | 18 | 0 | 0 | 2325 | 2020-03-05 | 🛑 |
| [vBBU](https://gerrit.lfbroadband.org/admin/repos/vBBU,general) | 18 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [cord-workflow-controller](https://gerrit.lfbroadband.org/admin/repos/cord-workflow-controller,general) | 17 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [internetemulator](https://gerrit.lfbroadband.org/admin/repos/internetemulator,general) | 17 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [ng-xos-lib](https://gerrit.lfbroadband.org/admin/repos/ng-xos-lib,general) | 17 | 0 | 0 | 3265 | 2017-08-08 | 🛑 |
| [cord-platform](https://gerrit.lfbroadband.org/admin/repos/cord-platform,general) | 16 | 0 | 0 | 2384 | 2020-01-06 | 🛑 |
| [omec-cni](https://gerrit.lfbroadband.org/admin/repos/omec-cni,general) | 15 | 0 | 0 | 1442 | 2022-08-05 | 🛑 |
| [openolt-scale-tester](https://gerrit.lfbroadband.org/admin/repos/openolt-scale-tester,general) | 15 | 0 | 0 | 1842 | 2021-07-01 | 🛑 |
| [hypercache](https://gerrit.lfbroadband.org/admin/repos/hypercache,general) | 14 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [metronet-local](https://gerrit.lfbroadband.org/admin/repos/metronet-local,general) | 14 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [multistructlog](https://gerrit.lfbroadband.org/admin/repos/multistructlog,general) | 14 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [sdn-controller](https://gerrit.lfbroadband.org/admin/repos/sdn-controller,general) | 13 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [xos-sample-gui-extension](https://gerrit.lfbroadband.org/admin/repos/xos-sample-gui-extension,general) | 13 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [foo-app](https://gerrit.lfbroadband.org/admin/repos/foo-app,general) | 12 | 0 | 0 | 2970 | 2018-05-30 | 🛑 |
| [hss_db](https://gerrit.lfbroadband.org/admin/repos/hss_db,general) | 12 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [sjsg](https://gerrit.lfbroadband.org/admin/repos/sjsg,general) | 12 | 0 | 0 | 1581 | 2022-03-19 | 🛑 |
| [tt-workflow-driver](https://gerrit.lfbroadband.org/admin/repos/tt-workflow-driver,general) | 12 | 0 | 0 | 2311 | 2020-03-19 | 🛑 |
| [vSGW](https://gerrit.lfbroadband.org/admin/repos/vSGW,general) | 12 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [voltha-northbound-bbf-adapter](https://gerrit.lfbroadband.org/admin/repos/voltha-northbound-bbf-adapter,general) | 12 | 0 | 0 | 1430 | 2022-08-17 | 🛑 |
| [voltha-test-manifest](https://gerrit.lfbroadband.org/admin/repos/voltha-test-manifest,general) | 11 | 0 | 0 | 2270 | 2020-04-29 | 🛑 |
| [ansible/role/pxeboot](https://gerrit.lfbroadband.org/admin/repos/ansible/role/pxeboot,general) | 10 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [cord-workflow-airflow](https://gerrit.lfbroadband.org/admin/repos/cord-workflow-airflow,general) | 10 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [enodebd](https://gerrit.lfbroadband.org/admin/repos/enodebd,general) | 10 | 0 | 0 | 1481 | 2022-06-27 | 🛑 |
| [openolt-api](https://gerrit.lfbroadband.org/admin/repos/openolt-api,general) | 10 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [ves-agent](https://gerrit.lfbroadband.org/admin/repos/ves-agent,general) | 10 | 0 | 0 | 2837 | 2018-10-10 | 🛑 |
| [ansible/role/nginx](https://gerrit.lfbroadband.org/admin/repos/ansible/role/nginx,general) | 9 | 0 | 0 | 1524 | 2022-05-15 | 🛑 |
| [ansible/role/strongswan](https://gerrit.lfbroadband.org/admin/repos/ansible/role/strongswan,general) | 9 | 0 | 0 | 1467 | 2022-07-11 | 🛑 |
| [ansible/role/unbound](https://gerrit.lfbroadband.org/admin/repos/ansible/role/unbound,general) | 9 | 0 | 0 | 1312 | 2022-12-13 | 🛑 |
| [cord-workflow-controller-client](https://gerrit.lfbroadband.org/admin/repos/cord-workflow-controller-client,general) | 9 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [globalxos](https://gerrit.lfbroadband.org/admin/repos/globalxos,general) | 9 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [go-manifest](https://gerrit.lfbroadband.org/admin/repos/go-manifest,general) | 9 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [templateservice](https://gerrit.lfbroadband.org/admin/repos/templateservice,general) | 9 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [ansible/role/dhcpd](https://gerrit.lfbroadband.org/admin/repos/ansible/role/dhcpd,general) | 8 | 0 | 0 | 1326 | 2022-11-29 | 🛑 |
| [ansible/role/timesheets](https://gerrit.lfbroadband.org/admin/repos/ansible/role/timesheets,general) | 8 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [dt-workflow-driver](https://gerrit.lfbroadband.org/admin/repos/dt-workflow-driver,general) | 8 | 0 | 0 | 2242 | 2020-05-28 | 🛑 |
| [osam](https://gerrit.lfbroadband.org/admin/repos/osam,general) | 8 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [ONOS-App-projects](https://gerrit.lfbroadband.org/admin/repos/ONOS-App-projects,general) | 7 | 0 | 0 | 666 | 2024-09-19 | ☑️ |
| [PublicTest](https://gerrit.lfbroadband.org/admin/repos/PublicTest,general) | 7 | 0 | 0 | 1465 | 2022-07-13 | 🛑 |
| [ansible/role/netprep](https://gerrit.lfbroadband.org/admin/repos/ansible/role/netprep,general) | 7 | 0 | 0 | 1754 | 2021-09-28 | 🛑 |
| [ansible/role/sriov](https://gerrit.lfbroadband.org/admin/repos/ansible/role/sriov,general) | 7 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [goloxi](https://gerrit.lfbroadband.org/admin/repos/goloxi,general) | 7 | 0 | 0 | 2277 | 2020-04-22 | 🛑 |
| [opencloud](https://gerrit.lfbroadband.org/admin/repos/opencloud,general) | 7 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [openolt-test](https://gerrit.lfbroadband.org/admin/repos/openolt-test,general) | 7 | 0 | 0 | 1996 | 2021-01-28 | 🛑 |
| [xos-manifest](https://gerrit.lfbroadband.org/admin/repos/xos-manifest,general) | 7 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [ansible/role/keycloak](https://gerrit.lfbroadband.org/admin/repos/ansible/role/keycloak,general) | 6 | 0 | 0 | 1413 | 2022-09-03 | 🛑 |
| [ansible/role/users](https://gerrit.lfbroadband.org/admin/repos/ansible/role/users,general) | 6 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [cbrstools](https://gerrit.lfbroadband.org/admin/repos/cbrstools,general) | 6 | 0 | 0 | 1645 | 2022-01-14 | 🛑 |
| [certification](https://gerrit.lfbroadband.org/admin/repos/certification,general) | 6 | 0 | 0 | 2538 | 2019-08-05 | 🛑 |
| [voltha-omci](https://gerrit.lfbroadband.org/admin/repos/voltha-omci,general) | 6 | 0 | 0 | 3137 | 2017-12-15 | 🛑 |
| [grpc-robot](https://gerrit.lfbroadband.org/admin/repos/grpc-robot,general) | 5 | +153 | 1 | 4 | 2026-07-13 | ✅ |
| [CORD-Projects](https://gerrit.lfbroadband.org/admin/repos/CORD-Projects,general) | 5 | 0 | 0 | 666 | 2024-09-19 | ☑️ |
| [SDFabric-Projects](https://gerrit.lfbroadband.org/admin/repos/SDFabric-Projects,general) | 5 | 0 | 0 | 666 | 2024-09-19 | ☑️ |
| [ansible/role/onieboot](https://gerrit.lfbroadband.org/admin/repos/ansible/role/onieboot,general) | 5 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [asfvolt16-onl](https://gerrit.lfbroadband.org/admin/repos/asfvolt16-onl,general) | 5 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [freeDiameter-old](https://gerrit.lfbroadband.org/admin/repos/freeDiameter-old,general) | 5 | 0 | 0 | 2930 | 2018-07-09 | 🛑 |
| [ipxe-build](https://gerrit.lfbroadband.org/admin/repos/ipxe-build,general) | 5 | 0 | 0 | 1521 | 2022-05-18 | 🛑 |
| [openairinterface](https://gerrit.lfbroadband.org/admin/repos/openairinterface,general) | 5 | 0 | 0 | 2089 | 2020-10-28 | 🛑 |
| [qa-manifest](https://gerrit.lfbroadband.org/admin/repos/qa-manifest,general) | 5 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [swarm](https://gerrit.lfbroadband.org/admin/repos/swarm,general) | 5 | 0 | 0 | 3196 | 2017-10-16 | 🛑 |
| [voltha-adtran-adapter](https://gerrit.lfbroadband.org/admin/repos/voltha-adtran-adapter,general) | 5 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [Aether-Projects](https://gerrit.lfbroadband.org/admin/repos/Aether-Projects,general) | 4 | 0 | 0 | 666 | 2024-09-19 | ☑️ |
| [alpine-grpc-base](https://gerrit.lfbroadband.org/admin/repos/alpine-grpc-base,general) | 4 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [ansible/role/devtools](https://gerrit.lfbroadband.org/admin/repos/ansible/role/devtools,general) | 4 | 0 | 0 | 1483 | 2022-06-25 | 🛑 |
| [ansible/role/docker](https://gerrit.lfbroadband.org/admin/repos/ansible/role/docker,general) | 4 | 0 | 0 | 1526 | 2022-05-13 | 🛑 |
| [ansible/role/ds389](https://gerrit.lfbroadband.org/admin/repos/ansible/role/ds389,general) | 4 | 0 | 0 | 1413 | 2022-09-03 | 🛑 |
| [ansible/role/netbox](https://gerrit.lfbroadband.org/admin/repos/ansible/role/netbox,general) | 4 | 0 | 0 | 1413 | 2022-09-03 | 🛑 |
| [ansible/role/nsd](https://gerrit.lfbroadband.org/admin/repos/ansible/role/nsd,general) | 4 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [ansible/role/php](https://gerrit.lfbroadband.org/admin/repos/ansible/role/php,general) | 4 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [ansible/role/usrp](https://gerrit.lfbroadband.org/admin/repos/ansible/role/usrp,general) | 4 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [kafkaloghandler](https://gerrit.lfbroadband.org/admin/repos/kafkaloghandler,general) | 4 | 0 | 0 | 2811 | 2018-11-05 | 🛑 |
| [omec-pod-init](https://gerrit.lfbroadband.org/admin/repos/omec-pod-init,general) | 4 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [onfca](https://gerrit.lfbroadband.org/admin/repos/onfca,general) | 4 | 0 | 0 | 1361 | 2022-10-25 | 🛑 |
| [.github](https://gerrit.lfbroadband.org/admin/repos/.github,general) | 3 | 0 | 0 | 672 | 2024-09-13 | ☑️ |
| [ActiveTest](https://gerrit.lfbroadband.org/admin/repos/ActiveTest,general) | 3 | 0 | 0 | 3270 | 2017-08-03 | 🛑 |
| [Infra-Projects](https://gerrit.lfbroadband.org/admin/repos/Infra-Projects,general) | 3 | 0 | 0 | 666 | 2024-09-19 | ☑️ |
| [PassiveTest](https://gerrit.lfbroadband.org/admin/repos/PassiveTest,general) | 3 | 0 | 0 | 3270 | 2017-08-03 | 🛑 |
| [SDCore-Projects](https://gerrit.lfbroadband.org/admin/repos/SDCore-Projects,general) | 3 | 0 | 0 | 666 | 2024-09-19 | ☑️ |
| [ansible/role/acme](https://gerrit.lfbroadband.org/admin/repos/ansible/role/acme,general) | 3 | 0 | 0 | 1458 | 2022-07-20 | 🛑 |
| [ansible/role/bird](https://gerrit.lfbroadband.org/admin/repos/ansible/role/bird,general) | 3 | 0 | 0 | 1572 | 2022-03-28 | 🛑 |
| [ansible/role/chrony](https://gerrit.lfbroadband.org/admin/repos/ansible/role/chrony,general) | 3 | 0 | 0 | 1451 | 2022-07-27 | 🛑 |
| [ansible/role/enodebd](https://gerrit.lfbroadband.org/admin/repos/ansible/role/enodebd,general) | 3 | 0 | 0 | 1413 | 2022-09-03 | 🛑 |
| [ansible/role/jenkins](https://gerrit.lfbroadband.org/admin/repos/ansible/role/jenkins,general) | 3 | 0 | 0 | 2079 | 2020-11-06 | 🛑 |
| [ansible/role/mariadb](https://gerrit.lfbroadband.org/admin/repos/ansible/role/mariadb,general) | 3 | 0 | 0 | 1413 | 2022-09-03 | 🛑 |
| [ansible/role/node_exporter](https://gerrit.lfbroadband.org/admin/repos/ansible/role/node_exporter,general) | 3 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [ansible/role/nodejs](https://gerrit.lfbroadband.org/admin/repos/ansible/role/nodejs,general) | 3 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [ansible/role/postgresql](https://gerrit.lfbroadband.org/admin/repos/ansible/role/postgresql,general) | 3 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [ansible/role/redis](https://gerrit.lfbroadband.org/admin/repos/ansible/role/redis,general) | 3 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [ansible/role/unifi](https://gerrit.lfbroadband.org/admin/repos/ansible/role/unifi,general) | 3 | 0 | 0 | 1411 | 2022-09-05 | 🛑 |
| [cggs](https://gerrit.lfbroadband.org/admin/repos/cggs,general) | 3 | 0 | 0 | 963 | 2023-11-27 | ☑️ |
| [cord-workflow-probe](https://gerrit.lfbroadband.org/admin/repos/cord-workflow-probe,general) | 3 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [k8sepcservice](https://gerrit.lfbroadband.org/admin/repos/k8sepcservice,general) | 3 | 0 | 0 | 2877 | 2018-08-31 | 🛑 |
| [nem-ondemand-proxy](https://gerrit.lfbroadband.org/admin/repos/nem-ondemand-proxy,general) | 3 | 0 | 0 | 2310 | 2020-03-20 | 🛑 |
| [ntt-workflow-driver](https://gerrit.lfbroadband.org/admin/repos/ntt-workflow-driver,general) | 3 | 0 | 0 | 1949 | 2021-03-17 | 🛑 |
| [opendevice-manager](https://gerrit.lfbroadband.org/admin/repos/opendevice-manager,general) | 3 | 0 | 0 | 1878 | 2021-05-27 | 🛑 |
| [seba-manifest](https://gerrit.lfbroadband.org/admin/repos/seba-manifest,general) | 3 | 0 | 0 | 2930 | 2018-07-09 | 🛑 |
| [vMM](https://gerrit.lfbroadband.org/admin/repos/vMM,general) | 3 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [vPGWU](https://gerrit.lfbroadband.org/admin/repos/vPGWU,general) | 3 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [vSM](https://gerrit.lfbroadband.org/admin/repos/vSM,general) | 3 | 0 | 0 | 2429 | 2019-11-22 | 🛑 |
| [voltha-eponolt-adapter](https://gerrit.lfbroadband.org/admin/repos/voltha-eponolt-adapter,general) | 3 | 0 | 0 | 2035 | 2020-12-21 | 🛑 |
| [voltha-epononu-adapter](https://gerrit.lfbroadband.org/admin/repos/voltha-epononu-adapter,general) | 3 | 0 | 0 | 2035 | 2020-12-21 | 🛑 |
| [ansible/role/dkms](https://gerrit.lfbroadband.org/admin/repos/ansible/role/dkms,general) | 2 | 0 | 0 | 1627 | 2022-02-01 | 🛑 |
| [ansible/role/gerrit](https://gerrit.lfbroadband.org/admin/repos/ansible/role/gerrit,general) | 2 | 0 | 0 | 1413 | 2022-09-03 | 🛑 |
| [ansible/role/rke2](https://gerrit.lfbroadband.org/admin/repos/ansible/role/rke2,general) | 2 | 0 | 0 | 1598 | 2022-03-02 | 🛑 |
| [cord-service-boilerplate](https://gerrit.lfbroadband.org/admin/repos/cord-service-boilerplate,general) | 2 | 0 | 0 | 3395 | 2017-03-31 | 🛑 |
| [igmpca](https://gerrit.lfbroadband.org/admin/repos/igmpca,general) | 2 | 0 | 0 | 1192 | 2023-04-12 | 🛑 |
| [kafka-robot](https://gerrit.lfbroadband.org/admin/repos/kafka-robot,general) | 2 | 0 | 0 | 1752 | 2021-09-29 | 🛑 |
| [lbaas](https://gerrit.lfbroadband.org/admin/repos/lbaas,general) | 2 | 0 | 0 | 3193 | 2017-10-20 | 🛑 |
| [mn-stratum-siab](https://gerrit.lfbroadband.org/admin/repos/mn-stratum-siab,general) | 2 | 0 | 0 | 2433 | 2019-11-18 | 🛑 |
| [onos-classic-helm-utils](https://gerrit.lfbroadband.org/admin/repos/onos-classic-helm-utils,general) | 2 | 0 | 0 | 1821 | 2021-07-22 | 🛑 |
| [opendm-agent](https://gerrit.lfbroadband.org/admin/repos/opendm-agent,general) | 2 | 0 | 0 | 1914 | 2021-04-20 | 🛑 |
| [voltha-bal](https://gerrit.lfbroadband.org/admin/repos/voltha-bal,general) | 2 | 0 | 0 | 3327 | 2017-06-07 | 🛑 |
| [Ignite](https://gerrit.lfbroadband.org/admin/repos/Ignite,general) | 1 | 0 | 0 | 2326 | 2020-03-05 | 🛑 |
| [MME2](https://gerrit.lfbroadband.org/admin/repos/MME2,general) | 1 | 0 | 0 | 2427 | 2019-11-24 | 🛑 |
| [acordion](https://gerrit.lfbroadband.org/admin/repos/acordion,general) | 1 | 0 | 0 | 2985 | 2018-05-15 | 🛑 |
| [ansible/role/389ds](https://gerrit.lfbroadband.org/admin/repos/ansible/role/389ds,general) | 1 | 0 | 0 | 1774 | 2021-09-07 | 🛑 |
| [ansible/role/apt_source](https://gerrit.lfbroadband.org/admin/repos/ansible/role/apt_source,general) | 1 | 0 | 0 | 1677 | 2021-12-13 | 🛑 |
| [ansible/role/edgemonagent](https://gerrit.lfbroadband.org/admin/repos/ansible/role/edgemonagent,general) | 1 | 0 | 0 | 1935 | 2021-03-30 | 🛑 |
| [ansible/role/golang](https://gerrit.lfbroadband.org/admin/repos/ansible/role/golang,general) | 1 | 0 | 0 | 1493 | 2022-06-15 | 🛑 |
| [ansible/role/lbackup](https://gerrit.lfbroadband.org/admin/repos/ansible/role/lbackup,general) | 1 | 0 | 0 | 2069 | 2020-11-16 | 🛑 |
| [ansible/role/lua](https://gerrit.lfbroadband.org/admin/repos/ansible/role/lua,general) | 1 | 0 | 0 | 1709 | 2021-11-12 | 🛑 |
| [ansible/role/openvpn](https://gerrit.lfbroadband.org/admin/repos/ansible/role/openvpn,general) | 1 | 0 | 0 | 1574 | 2022-03-26 | 🛑 |
| [ansible/role/proxmox](https://gerrit.lfbroadband.org/admin/repos/ansible/role/proxmox,general) | 1 | 0 | 0 | 1641 | 2022-01-18 | 🛑 |
| [ansible/role/qat](https://gerrit.lfbroadband.org/admin/repos/ansible/role/qat,general) | 1 | 0 | 0 | 1586 | 2022-03-14 | 🛑 |
| [ansible/role/rbackup](https://gerrit.lfbroadband.org/admin/repos/ansible/role/rbackup,general) | 1 | 0 | 0 | 2069 | 2020-11-16 | 🛑 |
| [cord-omec](https://gerrit.lfbroadband.org/admin/repos/cord-omec,general) | 1 | 0 | 0 | 2566 | 2019-07-08 | 🛑 |
| [fwaas](https://gerrit.lfbroadband.org/admin/repos/fwaas,general) | 1 | 0 | 0 | 3087 | 2018-02-02 | 🛑 |
| [infra-containers](https://gerrit.lfbroadband.org/admin/repos/infra-containers,general) | 1 | 0 | 0 | 1773 | 2021-09-08 | 🛑 |
| [kolla](https://gerrit.lfbroadband.org/admin/repos/kolla,general) | 1 | 0 | 0 | 3167 | 2017-11-14 | 🛑 |
| [kolla-ansible](https://gerrit.lfbroadband.org/admin/repos/kolla-ansible,general) | 1 | 0 | 0 | 3110 | 2018-01-11 | 🛑 |
| [mcord-configs](https://gerrit.lfbroadband.org/admin/repos/mcord-configs,general) | 1 | 0 | 0 | 3087 | 2018-02-02 | 🛑 |
| [mgmt-gateway-vm](https://gerrit.lfbroadband.org/admin/repos/mgmt-gateway-vm,general) | 1 | 0 | 0 | 2898 | 2018-08-10 | 🛑 |
| [multifabric](https://gerrit.lfbroadband.org/admin/repos/multifabric,general) | 1 | 0 | 0 | 2359 | 2020-01-31 | 🛑 |
| [onf-docs](https://gerrit.lfbroadband.org/admin/repos/onf-docs,general) | 1 | 0 | 0 | 1596 | 2022-03-04 | 🛑 |
| [openomci](https://gerrit.lfbroadband.org/admin/repos/openomci,general) | 1 | 0 | 0 | 3138 | 2017-12-13 | 🛑 |
| [pppoel2relay](https://gerrit.lfbroadband.org/admin/repos/pppoel2relay,general) | 1 | 0 | 0 | 2485 | 2019-09-27 | 🛑 |
| [pubsafe](https://gerrit.lfbroadband.org/admin/repos/pubsafe,general) | 1 | 0 | 0 | 3447 | 2017-02-07 | 🛑 |
| [redfish-agent](https://gerrit.lfbroadband.org/admin/repos/redfish-agent,general) | 1 | 0 | 0 | 2846 | 2018-10-01 | 🛑 |
| [vSGWU](https://gerrit.lfbroadband.org/admin/repos/vSGWU,general) | 1 | 0 | 0 | 3259 | 2017-08-14 | 🛑 |
| [voltha-release](https://gerrit.lfbroadband.org/admin/repos/voltha-release,general) | 1 | 0 | 0 | 895 | 2024-02-03 | ☑️ |
| [xRAN](https://gerrit.lfbroadband.org/admin/repos/xRAN,general) | 1 | 0 | 0 | 3314 | 2017-06-20 | 🛑 |

**Total:** 253 repositories

---
## 🔧 Gerrit Project Feature Matrix

| Gerrit Project | Primary Type | Other Types | Dependabot | Pre-commit | ReadTheDocs | .gitreview | G2G | Status |
|----------------|--------------|-------------|------------|------------|-------------|------------|-----|--------|
| ansible/role/apt_source | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/389ds | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/devtools | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/chrony | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/acme | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/dkms | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/dhcpd | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/bird | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/docker | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/ds389 | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/golang | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/gerrit | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/edgemonagent | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/enodebd | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/jenkins | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/keycloak | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/lbackup | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/lua | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/node_exporter | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/netbox | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/netprep | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/mariadb | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/nginx | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/nodejs | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/onieboot | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/nsd | Python |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/qat | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/rbackup | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/openvpn | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/php | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/proxmox | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/postgresql | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/pxeboot | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/redis | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/rke2 | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/sriov | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/strongswan | Shell |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/timesheets | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/unifi | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/unbound | Python |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/users | Python |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/usrp | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| Aether-Projects | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| CORD-Projects | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| Infra-Projects | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| .github | N/A |  | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| Ignite | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| MME2 | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ONOS-App-projects | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| PublicTest | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| SDCore-Projects | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| SDFabric-Projects | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| VOLTHA-Projects | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| ansible/onf-ansible | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ActiveTest | Python | Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| acordion | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| PassiveTest | Python | Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| alpine-grpc-base | Python | Dockerfile | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| addressmanager | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| asfvolt16-onl | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| asfvolt16-driver | C | Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| bogus-project | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| att-workflow-driver | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| aaa | Java/Maven |  | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| cbrstools | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| bng | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| cggs | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| certification | Python | Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ci-management | jjb |  | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| comac-helm-charts | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| chameleon | JavaScript | Python, Dockerfile, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| automation-tools | Shell | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| composer | JavaScript | Node | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| config | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-omec | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| cord-onos-publisher | Shell | Java/Maven, Groovy | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-platform | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-service-boilerplate | Python | Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| carrierethernet | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-workflow-airflow | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord | Python | Shell, Ruby, Groovy | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-workflow-controller | JavaScript | Node, Dockerfile | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-workflow-controller-client | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-charts-repo | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| cord-workflow-probe | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-tester | Robot Framework | Python, Shell | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| device-management-interface | Python | Shell, Go, C++, C | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| dt-workflow-driver | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| dhcpl2relay | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| docs | Ruby | JavaScript, Node, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| epc-service | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ecord | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| enodebd | Python | Dockerfile | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| exampleservice | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| fabric-crossconnect | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| fabric | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| foo-app | Java/Maven |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| fabric-oftest | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| fpcagent | Java | Python, Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| cordctl | Go | JavaScript, Shell, C | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| fwaas | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| go-manifest | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| globalxos | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| goloxi | Go |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| fabric-tofino | Java/Maven | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| helm-repo-tools | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| grpc-robot | Python | Robot Framework, HTML | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| hippie-oss | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| hss_db | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| igmp | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| igmpca | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| hypercache | Python | Shell, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| infra-manifest | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| infra-containers | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| freeDiameter-old | C | Shell, C++, PHP, PLpgSQL | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ipxe-build | Dockerfile |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| igmpproxy | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| internetemulator | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| k8sepcservice | Python |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| bbsim | Go | Python, Shell, C, Groovy | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| kafka-robot | Python | Robot Framework, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| kafkaloghandler | Python |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| kafka-onos | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| kolla | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| kolla-ansible | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| bbsim-sadis-server | Go | Shell, C | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| lbaas | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| kubernetes-service | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| manifest | Shell | Groovy | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| mcord-configs | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| mcord | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| mac-learning | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| helm-charts | Smarty | Python, Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| mcast | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| mgmt-gateway-vm | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| mn-stratum-siab | Dockerfile |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| metronet-local | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| metro-net | Python | Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| multifabric | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| multistructlog | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| network-diag-app | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ntt-workflow-driver | Python |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ng-xos-lib | JavaScript | Node, SCSS, HTML, CSS | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| monitoring | Python | Shell, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| olt-service | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| olttopology | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| olt | Java/Maven | Python | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| omec-pod-init | Dockerfile |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| omec-cni | Dockerfile |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| device-management | Go | Dockerfile, Shell, C, Robot Framework | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| onf-docs | Python | CSS | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| omci-lib-go | Go | Python, Shell | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| onfca | Shell |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| onos-classic-helm-utils | Dockerfile | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| onf-scripts | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| onos-robot | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| openairinterface | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| maas | Go | Python, Shell, Smarty | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| onos-service | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| opencloud | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| onf-make | Python | Shell | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| kafka-topic-exporter | Go | Dockerfile, Shell, C | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| opendm-agent | C++ | Shell, C | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| openolt-api | Go |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| nem-ondemand-proxy | Go | Shell, C | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| openolt-test | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| openomci | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| openstack | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| person-detection-app | Python | Shell, HTML | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| plyxproto | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| openolt | C | Python, Shell, Go, C++, Groovy, D | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| pod-configs | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| pppoel2relay | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| pppoeagent | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| pubsafe | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| progran | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| qa-manifest | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| redfish-agent | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| rcord | Python | JavaScript, TypeScript, SCSS, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ofagent-go | Go | Shell, C | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| repo | Python |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| sadis | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| quagga | C | Python, Dockerfile, Shell, CSS | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| roc-helm-charts | Smarty | Go | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sdcore-docs | Python | HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| sadis-server | Go | Dockerfile, Shell, C | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sdcore-helm-charts | Smarty |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| platform-install | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sdn-controller | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| openolt-scale-tester | Go | Shell, C | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| sdfabric-docs | Python | HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sdfabric-helm-charts | Smarty |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| seba-manifest | Shell |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| seba | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| osam | Java/Maven | PLpgSQL | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| simpleexampleservice | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| shared-workflows | N/A |  | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ |
| sjsg | Python | JavaScript, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| swarm | Python |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| templateservice | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| tt-workflow-driver | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| opendevice-manager | Go | Shell, C | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| vBBU | Python | Shell, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vMM | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vHSS | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vEE | JavaScript | TypeScript, Python, Shell, SCSS, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vEG | Python | Shell, D | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vMME | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vPGWU | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vPGWC | Python | Shell, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vSM | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vSGWU | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| vSGW | Python | Shell, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| service-profile | Shell | JavaScript, Python, Groovy, PLpgSQL | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| venb | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vnaas | JavaScript | TypeScript, Python, Shell, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ves-agent | Java/Maven | Python, Dockerfile, Shell, Smarty | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| voltha-docker-tools | N/A |  | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| voltha-adtran-adapter | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| voltha-docs | Python | Shell, Ruby, HTML, CSS | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| voltha-helm-charts | Smarty |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| voltha-bal | C | Python, Shell, HTML | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| voltha-eponolt-adapter | Go | Python, Shell, C, Smarty | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| voltha-omci | Python |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| voltha-epononu-adapter | Go | Python, Shell, C, Smarty | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| voltha-onos | Shell | Python | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| voltha-api-server | Go | Python, Shell, C, Smarty | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| voltha-go-controller | Go | Python, Shell, C | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| voltha-release | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| voltha-northbound-bbf-adapter | Go | Shell, C | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| voltha-system-tests | Robot Framework | Python, Shell | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| voltha-test-manifest | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vrouter | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vsg-hw | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vsg | Shell | JavaScript, Python, D, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| voltctl | Go | Python, Shell, C | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| voltha-protos | Go | Python, Shell, C | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| vspgwc | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vspgwu | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vtn-service | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xRAN | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| vtr | JavaScript | TypeScript, Python, Shell, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vtn | Java/Maven |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-manifest | Shell | Groovy | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-rest-gw | JavaScript | Node, Dockerfile, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-external-app-examples | JavaScript | Python, Shell, SCSS, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-sample-gui-extension | JavaScript | TypeScript, Node, Dockerfile, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-tosca | Python | Dockerfile, Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-gui | TypeScript | JavaScript, Node, Dockerfile, Groovy, SCSS, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xran-controller | Java |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| xos | Python | JavaScript, Shell, Ruby, Smarty, HTML, CSS | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| voltha-go | Go | Python, Shell, C | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| voltha-lib-go | Go | Python, Shell, C | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| voltha-openonu-adapter-go | Go | Python, Shell, C | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| voltha-openolt-adapter | Go | Python, Shell, C | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |

---
## 🏁 Deployed CI/CD Jobs

**Total GitHub workflows:** 31

**Total Jenkins jobs:** 130

| Gerrit Project | GitHub Workflows | Workflow Count | Jenkins Jobs | Job Count |
|----------------|-------------------|----------------|--------------|-----------|
| aaa | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 | maven-publish_aaa<br>verify_aaa_licensed<br>verify_aaa_maven-test | 3 |
| bbsim |  | 0 | bbsim_scale_test<br>docker-publish_bbsim<br>github-release_bbsim<br>onf-make-unit-test-bbsim<br>onf-make-voltha-dt-fttb-test-bbsim-master<br>patchset-voltha-2.14-multiple-olts-openonu-go-test-bbsim<br>patchset-voltha-2.14-openonu-go-test-bbsim<br>patchset-voltha-multiple-olts-openonu-go-test-bbsim<br>patchset-voltha-multiple-olts-pm-data-test-bbsim<br>patchset-voltha-openonu-go-test-bbsim<br>patchset-voltha-pm-data-test-bbsim<br>periodic-software-upgrade-test-bbsim<br>periodic-software-upgrade-test-bbsim-2.11<br>periodic-software-upgrade-test-bbsim-2.14<br>periodic-voltha-dt-fttb-test-bbsim-2.14<br>periodic-voltha-dt-fttb-test-bbsim-master<br>periodic-voltha-dt-test-bbsim-2.14<br>periodic-voltha-dt-test-bbsim-master<br>periodic-voltha-memory-leak-test-bbsim<br>periodic-voltha-memory-leak-test-bbsim-2.14<br>periodic-voltha-multi-uni-multiple-olts-test-bbsim<br>periodic-voltha-multi-uni-multiple-olts-test-bbsim-2.14<br>periodic-voltha-multi-uni-test-bbsim<br>periodic-voltha-multi-uni-test-bbsim-2.14<br>periodic-voltha-multiple-olts-openonu-go-test-bbsim<br>periodic-voltha-multiple-olts-openonu-go-test-bbsim-2.14<br>periodic-voltha-multiple-olts-pm-data-test-bbsim<br>periodic-voltha-multiple-olts-pm-data-test-bbsim-2.14<br>periodic-voltha-multiple-olts-test-bbsim<br>periodic-voltha-multiple-olts-test-bbsim-2.14<br>periodic-voltha-openonu-go-test-bbsim<br>periodic-voltha-openonu-go-test-bbsim-2.14<br>periodic-voltha-pm-data-test-bbsim<br>periodic-voltha-pm-data-test-bbsim-2.14<br>periodic-voltha-test-bbsim<br>periodic-voltha-test-bbsim-2.14<br>periodic-voltha-tim-multiple-olts-test-bbsim<br>periodic-voltha-tt-maclearner-sanity-test-bbsim<br>periodic-voltha-unitag-subscriber-tt-test-bbsim<br>periodic-voltha-unitag-subscriber-tt-test-bbsim-2.14<br>verify_bbsim_licensed<br>verify_bbsim_sanity-test<br>verify_bbsim_sanity-test-voltha-2.14<br>verify_bbsim_unit-test | 44 |
| bbsim-sadis-server |  | 0 | docker-publish_bbsim-sadis-server<br>verify_bbsim-sadis-server_licensed<br>verify_bbsim-sadis-server_sanity-test<br>verify_bbsim-sadis-server_sanity-test-voltha-2.14<br>verify_bbsim-sadis-server_unit-test | 5 |
| bng |  | 0 | maven-publish_bng<br>verify_bng_licensed<br>verify_bng_maven-test | 3 |
| ci-management | call-github2gerrit.yaml<br>gerrit-merge.yaml<br>gerrit-verify.yaml | 3 | ci-management-ami-packer-merge-ubuntu-18.04-basebuild_1804<br>ci-management-ami-packer-verify<br>ci-management-ami-packer-verify-build-ubuntu-18.04-basebuild_1804 | 3 |
| device-management-interface | call-github2gerrit.yaml<br>gerrit-verify.yaml<br>release.yaml | 3 |  | 0 |
| dhcpl2relay |  | 0 | maven-publish_dhcpl2relay<br>verify_dhcpl2relay_licensed<br>verify_dhcpl2relay_maven-test | 3 |
| grpc-robot | call-github2gerrit.yaml<br>gerrit-verify.yaml<br>release.yaml | 3 |  | 0 |
| helm-repo-tools |  | 0 | verify_helm-repo-tools_licensed<br>verify_helm-repo-tools_shellcheck | 2 |
| igmpproxy |  | 0 | maven-publish_igmpproxy<br>verify_igmpproxy_licensed<br>verify_igmpproxy_maven-test | 3 |
| kafka-onos |  | 0 | maven-publish_kafka-onos<br>verify_kafka-onos_licensed<br>verify_kafka-onos_maven-test | 3 |
| mac-learning |  | 0 | maven-publish_mac-learning<br>verify_mac-learning_licensed<br>verify_mac-learning_maven-test | 3 |
| mcast |  | 0 | maven-publish_mcast<br>verify_mcast_licensed<br>verify_mcast_maven-test | 3 |
| ofagent-go |  | 0 | docker-publish_ofagent-go<br>verify_ofagent-go_licensed<br>verify_ofagent-go_sanity-test<br>verify_ofagent-go_sanity-test-voltha-2.14<br>verify_ofagent-go_unit-test | 5 |
| olt |  | 0 | maven-publish_olt<br>periodic-voltha-combined-vgc-multi-olt<br>verify_olt_licensed<br>verify_olt_maven-test | 4 |
| omci-lib-go |  | 0 | verify_omci-lib-go_licensed<br>verify_omci-lib-go_unit-test | 2 |
| onf-make |  | 0 | onf-make-voltha-sanity-test-multi-runs | 1 |
| openolt |  | 0 | docker-publish_voltha-openolt-adapter<br>verify_openolt_licensed<br>verify_openolt_unit-test<br>verify_voltha-openolt-adapter_licensed<br>verify_voltha-openolt-adapter_sanity-test<br>verify_voltha-openolt-adapter_sanity-test-voltha-2.14<br>verify_voltha-openolt-adapter_unit-test-lint<br>verify_voltha-openolt-adapter_unit-test-tests | 8 |
| pppoeagent |  | 0 | maven-publish_pppoeagent<br>verify_pppoeagent_licensed<br>verify_pppoeagent_maven-test | 3 |
| sadis |  | 0 | maven-publish_sadis<br>verify_sadis_licensed<br>verify_sadis_maven-test | 3 |
| shared-workflows | gerrit-verify.yaml<br>sanity-test.yaml<br>verify-maven.yaml<br>verify-onos-component.yaml<br>verify-unit-tests-tag.yaml<br>verify-unit-tests.yaml | 6 |  | 0 |
| voltctl |  | 0 | github-release_voltctl<br>verify_voltctl_licensed<br>verify_voltctl_sanity-test<br>verify_voltctl_unit-test | 4 |
| voltha-docker-tools | call-github2gerrit.yaml<br>gerrit-verify.yaml<br>release.yaml | 3 | docker-publish_voltha-docker-tools<br>verify_voltha-docker-tools_licensed<br>verify_voltha-docker-tools_unit-test | 3 |
| voltha-docs | gerrit-verify.yaml<br>release.yaml | 2 |  | 0 |
| voltha-go |  | 0 | docker-publish_voltha-go<br>verify_voltha-go_licensed<br>verify_voltha-go_sanity-test<br>verify_voltha-go_sanity-test-voltha-2.14<br>verify_voltha-go_unit-test-lint<br>verify_voltha-go_unit-test-tests | 6 |
| voltha-go-controller | call-github2gerrit.yaml<br>gerrit-verify.yaml<br>release.yaml | 3 |  | 0 |
| voltha-helm-charts | gerrit-verify.yaml<br>release.yaml | 2 |  | 0 |
| voltha-lib-go | gerrit-verify.yaml | 1 |  | 0 |
| voltha-onos |  | 0 | docker-publish_voltha-onos<br>verify_voltha-onos_licensed<br>verify_voltha-onos_sanity-test<br>verify_voltha-onos_sanity-test-voltha-2.14<br>verify_voltha-onos_unit-test | 5 |
| voltha-openonu-adapter-go |  | 0 | docker-publish_voltha-openonu-adapter-go<br>verify_voltha-openonu-adapter-go_licensed<br>verify_voltha-openonu-adapter-go_sanity-test<br>verify_voltha-openonu-adapter-go_sanity-test-voltha-2.14<br>verify_voltha-openonu-adapter-go_unit-test-lint<br>verify_voltha-openonu-adapter-go_unit-test-tests | 6 |
| voltha-protos | call-github2gerrit.yaml<br>gerrit-verify.yaml<br>release.yaml | 3 |  | 0 |
| voltha-system-tests |  | 0 | verify_voltha-system-tests_licensed<br>verify_voltha-system-tests_sanity-test<br>verify_voltha-system-tests_sanity-test-py312<br>verify_voltha-system-tests_sanity-test-voltha-2.14<br>verify_voltha-system-tests_unit-test | 5 |

**Total:** 32 repositories with CI/CD jobs

---
## Orphaned Jenkins Jobs

These Jenkins jobs are matched to archived or read-only Gerrit projects:

### By State

- **READ_ONLY:** 43 jobs

### Job Details

| Job Name | Matched Project | State | Match Score |
|----------|----------------|-------|-------------|
| voltha-scale-measurements-master-onu-upgrade-2-16-32-att-onus | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-2-16-32-tt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-2-64-32-dt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-voltha-2.14-2-16-32-dt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-2-16-32-dt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-1-64-63-tt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-lwc-dt-256 | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-2.14-10-stacks-2-16-32-dt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-2-16-32-tt-subscribers-maclearner | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-patchset-1-16-32-att-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-voltha-2.14-2-16-32-tt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-10-stacks-2-16-32-att-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-patchset-1-16-32-dt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-lwc-dt-512 | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-experimental-multi-stack | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-1-64-63-dt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-2.14-10-stacks-2-16-32-tt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-10-stacks-2-16-32-dt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-experimental | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-patchset-1-16-32-tt-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-2-16-32-att-subscribers | voltha | READ_ONLY | 550% |
| voltha-scale-measurements-master-10-stacks-2-16-32-tt-subscribers | voltha | READ_ONLY | 550% |
| periodic-voltha-test-DMI | voltha | READ_ONLY | 430% |
| periodic-voltha-combined-vgc | voltha | READ_ONLY | 430% |
| periodic-voltha-etcd-test-2.14 | voltha | READ_ONLY | 430% |
| periodic-voltha-test-DMI-2.14 | voltha | READ_ONLY | 430% |
| periodic-voltha-etcd-test | voltha | READ_ONLY | 430% |
| periodic-voltha-sanity-test-multi-runs | voltha | READ_ONLY | 430% |
| build_berlin-community-pod-1-gpon_TP_voltha_TT_master_test | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-2-xgspon-zyxel_TP_voltha_TT_master_test | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-2-xgspon-zyxel_1T8GEM_DT_voltha_master | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-1-gpon-adtran_1T8GEM_DT_voltha_master | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-2-xgspon-zyxel_1T8GEM_voltha_DT_master_test | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-1-gpon_1T8GEM_voltha_DT_master_test | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-2-gpon-zyxel_1T8GEM_DT_voltha_master | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-1-gpon_TP_TT_voltha_master | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-1-gpon-adtran_1T8GEM_voltha_DT_master_test | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-1-multi-olt_1T8GEM_DT_voltha_master | voltha | READ_ONLY | 400% |
| verify_berlin-community-pod-1-gpon-adtran_Default_DT_voltha_master_dmi | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-1-gpon_1T8GEM_DT_voltha_master | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-1-multi-olt_1T8GEM_voltha_DT_master_test | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-2-xgspon-zyxel_TP_TT_voltha_master | voltha | READ_ONLY | 400% |
| build_berlin-community-pod-2-gpon-zyxel_1T8GEM_voltha_DT_master_test | voltha | READ_ONLY | 400% |

**Total Orphaned Jobs:** 43

---
## Unattributed Jenkins Jobs


These jobs could not be matched to any active or archived repository. They may be infrastructure jobs, release jobs, build pipelines, or jobs that use naming conventions different from the repository names. Consider reviewing the job names and repository naming patterns to improve attribution.


**Total:** 46 unattributed jobs

### Job Details

| Job Name | Status | URL |
|----------|--------|-----|
| build_berlin-community-pod-1-gpon-adtran_1T8GEM_DT_voltha_master | Success | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-1-gpon-adtran_1T8GEM_DT_voltha_master/) |
| build_berlin-community-pod-1-gpon-adtran_1T8GEM_voltha_DT_master_test | Unstable | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-1-gpon-adtran_1T8GEM_voltha_DT_master_test/) |
| build_berlin-community-pod-1-gpon_1T8GEM_DT_voltha_master | Success | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-1-gpon_1T8GEM_DT_voltha_master/) |
| build_berlin-community-pod-1-gpon_1T8GEM_voltha_DT_master_test | Unstable | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-1-gpon_1T8GEM_voltha_DT_master_test/) |
| build_berlin-community-pod-1-gpon_TP_TT_voltha_master | Success | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-1-gpon_TP_TT_voltha_master/) |
| build_berlin-community-pod-1-gpon_TP_voltha_TT_master_test | Unstable | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-1-gpon_TP_voltha_TT_master_test/) |
| build_berlin-community-pod-1-multi-olt_1T8GEM_DT_voltha_master | Success | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-1-multi-olt_1T8GEM_DT_voltha_master/) |
| build_berlin-community-pod-1-multi-olt_1T8GEM_voltha_DT_master_test | Unstable | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-1-multi-olt_1T8GEM_voltha_DT_master_test/) |
| build_berlin-community-pod-2-gpon-zyxel_1T8GEM_DT_voltha_master | Success | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-2-gpon-zyxel_1T8GEM_DT_voltha_master/) |
| build_berlin-community-pod-2-gpon-zyxel_1T8GEM_voltha_DT_master_test | Unstable | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-2-gpon-zyxel_1T8GEM_voltha_DT_master_test/) |
| build_berlin-community-pod-2-xgspon-zyxel_1T8GEM_DT_voltha_master | Success | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-2-xgspon-zyxel_1T8GEM_DT_voltha_master/) |
| build_berlin-community-pod-2-xgspon-zyxel_1T8GEM_voltha_DT_master_test | Unstable | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-2-xgspon-zyxel_1T8GEM_voltha_DT_master_test/) |
| build_berlin-community-pod-2-xgspon-zyxel_TP_TT_voltha_master | Success | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-2-xgspon-zyxel_TP_TT_voltha_master/) |
| build_berlin-community-pod-2-xgspon-zyxel_TP_voltha_TT_master_test | Unstable | [View Job](https://jenkins.lfbroadband.org/job/build_berlin-community-pod-2-xgspon-zyxel_TP_voltha_TT_master_test/) |
| check_infrastructure | Success | [View Job](https://jenkins.lfbroadband.org/job/check_infrastructure/) |
| onos-app-release | Success | [View Job](https://jenkins.lfbroadband.org/job/onos-app-release/) |
| periodic-voltha-combined-vgc | Failed | [View Job](https://jenkins.lfbroadband.org/job/periodic-voltha-combined-vgc/) |
| periodic-voltha-etcd-test | Failed | [View Job](https://jenkins.lfbroadband.org/job/periodic-voltha-etcd-test/) |
| periodic-voltha-etcd-test-2.14 | Failed | [View Job](https://jenkins.lfbroadband.org/job/periodic-voltha-etcd-test-2.14/) |
| periodic-voltha-sanity-test-multi-runs | Success | [View Job](https://jenkins.lfbroadband.org/job/periodic-voltha-sanity-test-multi-runs/) |
| periodic-voltha-test-DMI | Failed | [View Job](https://jenkins.lfbroadband.org/job/periodic-voltha-test-DMI/) |
| periodic-voltha-test-DMI-2.14 | Failed | [View Job](https://jenkins.lfbroadband.org/job/periodic-voltha-test-DMI-2.14/) |
| verify_berlin-community-pod-1-gpon-adtran_Default_DT_voltha_master_dmi | Disabled | [View Job](https://jenkins.lfbroadband.org/job/verify_berlin-community-pod-1-gpon-adtran_Default_DT_voltha_master_dmi/) |
| version-tag_wildcard | Success | [View Job](https://jenkins.lfbroadband.org/job/version-tag_wildcard/) |
| voltha-scale-measurements-2.14-10-stacks-2-16-32-dt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-2.14-10-stacks-2-16-32-dt-subscribers/) |
| voltha-scale-measurements-2.14-10-stacks-2-16-32-tt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-2.14-10-stacks-2-16-32-tt-subscribers/) |
| voltha-scale-measurements-lwc-dt-256 | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-lwc-dt-256/) |
| voltha-scale-measurements-lwc-dt-512 | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-lwc-dt-512/) |
| voltha-scale-measurements-master-1-64-63-dt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-1-64-63-dt-subscribers/) |
| voltha-scale-measurements-master-1-64-63-tt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-1-64-63-tt-subscribers/) |
| voltha-scale-measurements-master-10-stacks-2-16-32-att-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-10-stacks-2-16-32-att-subscribers/) |
| voltha-scale-measurements-master-10-stacks-2-16-32-dt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-10-stacks-2-16-32-dt-subscribers/) |
| voltha-scale-measurements-master-10-stacks-2-16-32-tt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-10-stacks-2-16-32-tt-subscribers/) |
| voltha-scale-measurements-master-2-16-32-att-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-2-16-32-att-subscribers/) |
| voltha-scale-measurements-master-2-16-32-dt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-2-16-32-dt-subscribers/) |
| voltha-scale-measurements-master-2-16-32-tt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-2-16-32-tt-subscribers/) |
| voltha-scale-measurements-master-2-16-32-tt-subscribers-maclearner | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-2-16-32-tt-subscribers-maclearner/) |
| voltha-scale-measurements-master-2-64-32-dt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-2-64-32-dt-subscribers/) |
| voltha-scale-measurements-master-experimental | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-experimental/) |
| voltha-scale-measurements-master-experimental-multi-stack | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-experimental-multi-stack/) |
| voltha-scale-measurements-master-onu-upgrade-2-16-32-att-onus | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-master-onu-upgrade-2-16-32-att-onus/) |
| voltha-scale-measurements-patchset-1-16-32-att-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-patchset-1-16-32-att-subscribers/) |
| voltha-scale-measurements-patchset-1-16-32-dt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-patchset-1-16-32-dt-subscribers/) |
| voltha-scale-measurements-patchset-1-16-32-tt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-patchset-1-16-32-tt-subscribers/) |
| voltha-scale-measurements-voltha-2.14-2-16-32-dt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-voltha-2.14-2-16-32-dt-subscribers/) |
| voltha-scale-measurements-voltha-2.14-2-16-32-tt-subscribers | Disabled | [View Job](https://jenkins.lfbroadband.org/job/voltha-scale-measurements-voltha-2.14-2-16-32-tt-subscribers/) |

---


---*Generated with ❤️ by Release Engineering*