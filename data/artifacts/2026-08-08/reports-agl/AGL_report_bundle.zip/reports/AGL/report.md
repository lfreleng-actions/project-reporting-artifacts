# 📊 GitHub Project Analysis Report: AGL

**Generated:** 2026-08-08 07:20:32 UTC
**Schema Version:** 1.5.0

---## Table of Contents

- [Global Summary](#summary)
- [Gerrit Projects](#repositories)
- [Top Contributors](#contributors)
- [Top Organizations](#organizations)
- [Repository Feature Matrix](#features)
- [Deployed CI/CD Jobs](#workflows)
- [Unattributed Jenkins Jobs](#unattributed-jobs)

---

## 📈 Global Summary

**✅ Current** commits within last 365 days

**☑️ Active** commits between 365-1095 days

**🛑 Inactive** no commits in 1095+ days

| Metric | Count | Percentage |
| --- | --- | --- |
| Total Repositories | 73 | 100% |
| Current Repositories | 29 | 39.7% |
| Active Repositories | 33 | 45.2% |
| Inactive Repositories | 8 | 11.0% |
| No Apparent Commits | 3 | 4.1% |
| Total Commits | 9.5K | - |
| Total Lines of Code | 17.4M | - |

---
## 🏢 Top Organizations

The data presented in the table below covers the past 365 days.

**Organizations Found:** 71

| Rank | Organization | Contributors | Commits | LOC | Δ LOC | Avg LOC/Commit | Unique Repositories |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | konsulko.com | 11 | 158 | +9536 | 36375 | -109 | 32 |
| 2 | co.jp | 16 | 100 | +9711 | 11390 | +80 | 15 |
| 3 | linuxfoundation.org | 8 | 68 | +2970 | 8437 | -36 | 69 |
| 4 | gmail.com | 36 | 15 | +5027 | 5058 | +333 | 20 |
| 5 | collabora.com | 7 | 10 | +316 | 438 | +19 | 18 |
| 6 | panasonic.com | 5 | 9 | +607 | 1442 | -25 | 10 |
| 7 | example.com | 1 | 1 | +2 | 4 | 0 | 1 |
| 8 | protonmail.com | 1 | 1 | +51 | 102 | 0 | 1 |
| 9 | renesas.com | 7 | 1 | 0 | 0 | 0 | 6 |
| 10 | 6b3797ab1e90 | 1 | 0 | 0 | 0 | 0 | 1 |
| 11 | adit-jv.com | 10 | 0 | 0 | 0 | 0 | 6 |
| 12 | advancedtelematic.com | 2 | 0 | 0 | 0 | 0 | 4 |
| 13 | alps.com | 2 | 0 | 0 | 0 | 0 | 1 |
| 14 | amazon.com | 3 | 0 | 0 | 0 | 0 | 3 |
| 15 | automotivelinux.org | 2 | 0 | 0 | 0 | 0 | 8 |
| 16 | baylibre.com | 7 | 0 | 0 | 0 | 0 | 7 |
| 17 | co.uk | 3 | 0 | 0 | 0 | 0 | 3 |
| 18 | com.au | 1 | 0 | 0 | 0 | 0 | 2 |
| 19 | d-fine.com | 1 | 0 | 0 | 0 | 0 | 3 |
| 20 | daimler.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 21 | denso-ten.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 22 | denx.de | 1 | 0 | 0 | 0 | 0 | 1 |
| 23 | drimaes.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 24 | fridu.net | 2 | 0 | 0 | 0 | 0 | 2 |
| 25 | fujitsu.com | 15 | 0 | 0 | 0 | 0 | 18 |
| 26 | github.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 27 | gmx.de | 1 | 0 | 0 | 0 | 0 | 2 |
| 28 | googlemail.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 29 | grammer.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 30 | here.com | 1 | 0 | 0 | 0 | 0 | 1 |

---
## 👥 Top Contributors

The data presented in the table below covers the past 365 days.

**Contributors Found:** 231

| Rank | Contributor | Commits | LOC | Δ LOC | Avg LOC/Commit | Repositories | Organization |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Scott Murray | 158 | +9536 | 36375 | -109 | 30 | konsulko.com |
| 2 | Naoto Yamaguchi | 100 | +9711 | 11390 | +80 | 13 | co.jp |
| 3 | Jan-Simon Moeller | 68 | +2970 | 8437 | -36 | 69 | linuxfoundation.org |
| 4 | Marius Vlad | 10 | +316 | 438 | +19 | 15 | collabora.com |
| 5 | Kenta Murakami | 9 | +607 | 1442 | -25 | 3 | panasonic.com |
| 6 | Saalim Quadri | 8 | +4821 | 4822 | +602 | 4 | gmail.com |
| 7 | AGL CI Local | 1 | +2 | 4 | 0 | 1 | example.com |
| 8 | Ahmed Adel Wafdy | 1 | +31 | 32 | +30 | 1 | gmail.com |
| 9 | Amr Elkenawy | 1 | +97 | 99 | +95 | 1 | gmail.com |
| 10 | Anh Nguyen | 1 | 0 | 0 | 0 | 1 | renesas.com |
| 11 | Anuj Solanki | 1 | +59 | 81 | +37 | 7 | gmail.com |
| 12 | JianDe | 1 | +51 | 102 | 0 | 1 | protonmail.com |
| 13 | Minjae Kim | 1 | +14 | 14 | +14 | 1 | gmail.com |
| 14 | Nayanjyoti Das | 1 | +1 | 2 | 0 | 1 | gmail.com |
| 15 | Prachi Jha | 1 | +1 | 2 | 0 | 1 | gmail.com |
| 16 | Ruben Garcia | 1 | +3 | 6 | 0 | 1 | gmail.com |
| 17 | 8000ff | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 18 | Alice Ferrazzi | 0 | 0 | 0 | 0 | 1 | miraclelinux.com |
| 19 | Alice Ferrazzi | 0 | 0 | 0 | 0 | 1 | co.jp |
| 20 | Alistair Francis | 0 | 0 | 0 | 0 | 1 | wdc.com |
| 21 | Andre Moreira Magalhaes (andrunko) | 0 | 0 | 0 | 0 | 2 | co.uk |
| 22 | Andreas Müller | 0 | 0 | 0 | 0 | 1 | googlemail.com |
| 23 | Andrew Grimberg | 0 | 0 | 0 | 0 | 1 | linuxfoundation.org |
| 24 | Andrey Shamanin | 0 | 0 | 0 | 0 | 3 | orioninc.com |
| 25 | Andriy Tryshnivskyy | 0 | 0 | 0 | 0 | 2 | opensynergy.com |
| 26 | AndyZhou | 0 | 0 | 0 | 0 | 2 | fujitsu.com |
| 27 | Angelos Mouzakitis | 0 | 0 | 0 | 0 | 4 | virtualopensystems.com |
| 28 | Anil Belur | 0 | 0 | 0 | 0 | 1 | linuxfoundation.org |
| 29 | Anmol Anmol | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 30 | Antia Puentes | 0 | 0 | 0 | 0 | 3 | igalia.com |

---
## 📊 Repositories

| Repository | Commits | LOC | Contributors | Days Inactive | Last Commit Date | Status |
| --- | --- | --- | --- | --- | --- | --- |
| [AGL/meta-agl](https://github.com/gerrit.automotivelinux.org/AGL/meta-agl) | 2775 | +5796 | 6 | 11 | 2026-07-27 | ✅ |
| [AGL/meta-agl-demo](https://github.com/gerrit.automotivelinux.org/AGL/meta-agl-demo) | 1336 | +2217 | 5 | 46 | 2026-06-22 | ✅ |
| [AGL/meta-agl-devel](https://github.com/gerrit.automotivelinux.org/AGL/meta-agl-devel) | 920 | +4940 | 6 | 45 | 2026-06-23 | ✅ |
| [ci-management](https://github.com/gerrit.automotivelinux.org/ci-management) | 914 | +981 | 1 | 44 | 2026-06-24 | ✅ |
| [AGL/AGL-repo](https://github.com/gerrit.automotivelinux.org/AGL/AGL-repo) | 463 | +499 | 5 | 22 | 2026-07-16 | ✅ |
| [src/agl-compositor](https://github.com/gerrit.automotivelinux.org/src/agl-compositor) | 374 | +160 | 2 | 35 | 2026-07-03 | ✅ |
| [AGL/lava-docker](https://github.com/gerrit.automotivelinux.org/AGL/lava-docker) | 370 | 0 | 0 | 1991 | 2021-02-23 | 🛑 |
| [AGL/releng-scripts](https://github.com/gerrit.automotivelinux.org/AGL/releng-scripts) | 281 | +103 | 1 | 42 | 2026-06-26 | ✅ |
| [src/libappcontroller](https://github.com/gerrit.automotivelinux.org/src/libappcontroller) | 231 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [AGL/documentation](https://github.com/gerrit.automotivelinux.org/AGL/documentation) | 195 | +6184 | 8 | 15 | 2026-07-23 | ✅ |
| [AGL/meta-agl-extra](https://github.com/gerrit.automotivelinux.org/AGL/meta-agl-extra) | 175 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/qa-testdefinitions](https://github.com/gerrit.automotivelinux.org/src/qa-testdefinitions) | 148 | 0 | 1 | 60 | 2026-06-08 | ✅ |
| [src/libqtappfw](https://github.com/gerrit.automotivelinux.org/src/libqtappfw) | 146 | +165 | 1 | 291 | 2025-10-20 | ✅ |
| [apps/homescreen](https://github.com/gerrit.automotivelinux.org/apps/homescreen) | 123 | +12 | 1 | 220 | 2025-12-30 | ✅ |
| [apps/agl-service-bluetooth](https://github.com/gerrit.automotivelinux.org/apps/agl-service-bluetooth) | 113 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [apps/flutter-ics-homescreen](https://github.com/gerrit.automotivelinux.org/apps/flutter-ics-homescreen) | 58 | +957 | 1 | 160 | 2026-02-28 | ✅ |
| [AGL](https://github.com/gerrit.automotivelinux.org/AGL) | 56 | +3 | 1 | 164 | 2026-02-24 | ✅ |
| [apps/ondemandnavi](https://github.com/gerrit.automotivelinux.org/apps/ondemandnavi) | 54 | +118 | 1 | 213 | 2026-01-07 | ✅ |
| [zzz_acl/src_acl](https://github.com/gerrit.automotivelinux.org/zzz_acl/src_acl) | 53 | 0 | 0 | 1014 | 2023-10-28 | ☑️ |
| [src/pipewire-ic-ipc](https://github.com/gerrit.automotivelinux.org/src/pipewire-ic-ipc) | 46 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/agl-demo-control-panel](https://github.com/gerrit.automotivelinux.org/src/agl-demo-control-panel) | 45 | +53 | 1 | 182 | 2026-02-06 | ✅ |
| [apps/agl-service-mediascanner](https://github.com/gerrit.automotivelinux.org/apps/agl-service-mediascanner) | 43 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [apps/agl-service-bluetooth-pbap](https://github.com/gerrit.automotivelinux.org/apps/agl-service-bluetooth-pbap) | 42 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [apps/agl-service-hvac](https://github.com/gerrit.automotivelinux.org/apps/agl-service-hvac) | 39 | +208 | 1 | 291 | 2025-10-20 | ✅ |
| [apps/agl-service-audiomixer](https://github.com/gerrit.automotivelinux.org/apps/agl-service-audiomixer) | 37 | +150 | 1 | 291 | 2025-10-20 | ✅ |
| [apps/agl-service-bluetooth-map](https://github.com/gerrit.automotivelinux.org/apps/agl-service-bluetooth-map) | 36 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [AGL/meta-agl-refhw](https://github.com/gerrit.automotivelinux.org/AGL/meta-agl-refhw) | 35 | +7 | 1 | 36 | 2026-07-02 | ✅ |
| [src/drm-lease-manager](https://github.com/gerrit.automotivelinux.org/src/drm-lease-manager) | 33 | +2 | 1 | 130 | 2026-03-30 | ✅ |
| [apps/camera-gstreamer](https://github.com/gerrit.automotivelinux.org/apps/camera-gstreamer) | 22 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/qtaglextras](https://github.com/gerrit.automotivelinux.org/src/qtaglextras) | 22 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/agl-shell-activator](https://github.com/gerrit.automotivelinux.org/src/agl-shell-activator) | 21 | 0 | 0 | 925 | 2024-01-26 | ☑️ |
| [apps/flutter-instrument-cluster](https://github.com/gerrit.automotivelinux.org/apps/flutter-instrument-cluster) | 18 | +141 | 1 | 182 | 2026-02-06 | ✅ |
| [apps](https://github.com/gerrit.automotivelinux.org/apps) | 18 | 0 | 0 | 1014 | 2023-10-28 | ☑️ |
| [apps/navigation](https://github.com/gerrit.automotivelinux.org/apps/navigation) | 16 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/virtio/virtio-loopback-adapter](https://github.com/gerrit.automotivelinux.org/src/virtio/virtio-loopback-adapter) | 15 | +1 | 1 | 42 | 2026-06-26 | ✅ |
| [staging/rba](https://github.com/gerrit.automotivelinux.org/staging/rba) | 15 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/virtio/virtio-loopback-driver](https://github.com/gerrit.automotivelinux.org/src/virtio/virtio-loopback-driver) | 13 | +4 | 1 | 42 | 2026-06-26 | ✅ |
| [src/applaunchd](https://github.com/gerrit.automotivelinux.org/src/applaunchd) | 13 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/qa-test-misc](https://github.com/gerrit.automotivelinux.org/src/qa-test-misc) | 13 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [apps/mominavi](https://github.com/gerrit.automotivelinux.org/apps/mominavi) | 12 | +209 | 1 | 209 | 2026-01-11 | ✅ |
| [src/window-management-client-grpc](https://github.com/gerrit.automotivelinux.org/src/window-management-client-grpc) | 11 | +38 | 1 | 140 | 2026-03-20 | ✅ |
| [apps/flutter-speechrecognition-demo](https://github.com/gerrit.automotivelinux.org/apps/flutter-speechrecognition-demo) | 8 | 0 | 0 | 667 | 2024-10-09 | ☑️ |
| [apps/momiplayer](https://github.com/gerrit.automotivelinux.org/apps/momiplayer) | 8 | 0 | 0 | 664 | 2024-10-12 | ☑️ |
| [src](https://github.com/gerrit.automotivelinux.org/src) | 8 | 0 | 0 | 2122 | 2020-10-15 | 🛑 |
| [staging](https://github.com/gerrit.automotivelinux.org/staging) | 8 | 0 | 0 | 2145 | 2020-09-22 | 🛑 |
| [staging/rba-tool](https://github.com/gerrit.automotivelinux.org/staging/rba-tool) | 8 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [AGL/workspace-config-agl](https://github.com/gerrit.automotivelinux.org/AGL/workspace-config-agl) | 7 | +511 | 1 | 86 | 2026-05-13 | ✅ |
| [src/native-shell-client](https://github.com/gerrit.automotivelinux.org/src/native-shell-client) | 7 | +82 | 1 | 57 | 2026-06-11 | ✅ |
| [src/bluez-glib](https://github.com/gerrit.automotivelinux.org/src/bluez-glib) | 6 | +2 | 1 | 30 | 2026-07-08 | ✅ |
| [apps/momiscreen](https://github.com/gerrit.automotivelinux.org/apps/momiscreen) | 6 | 0 | 0 | 664 | 2024-10-12 | ☑️ |
| [src/uhmi-agl-wm](https://github.com/gerrit.automotivelinux.org/src/uhmi-agl-wm) | 6 | 0 | 0 | 514 | 2025-03-11 | ☑️ |
| [apps/momiweather](https://github.com/gerrit.automotivelinux.org/apps/momiweather) | 4 | +5 | 1 | 114 | 2026-04-15 | ✅ |
| [apps/flutter-navigation](https://github.com/gerrit.automotivelinux.org/apps/flutter-navigation) | 4 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [apps/homescreen-demo-ci](https://github.com/gerrit.automotivelinux.org/apps/homescreen-demo-ci) | 4 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/agl-dbc](https://github.com/gerrit.automotivelinux.org/src/agl-dbc) | 4 | 0 | 0 | 456 | 2025-05-09 | ☑️ |
| [src/libaglnavigation](https://github.com/gerrit.automotivelinux.org/src/libaglnavigation) | 4 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/libcloudproxy](https://github.com/gerrit.automotivelinux.org/src/libcloudproxy) | 4 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/snips-inference-agl](https://github.com/gerrit.automotivelinux.org/src/snips-inference-agl) | 4 | 0 | 0 | 670 | 2024-10-07 | ☑️ |
| [src/snips-model-agl](https://github.com/gerrit.automotivelinux.org/src/snips-model-agl) | 4 | 0 | 0 | 719 | 2024-08-18 | ☑️ |
| [z_sandbox](https://github.com/gerrit.automotivelinux.org/z_sandbox) | 4 | 0 | 0 | 3979 | 2015-09-15 | 🛑 |
| [apps/flutter-ros-demo](https://github.com/gerrit.automotivelinux.org/apps/flutter-ros-demo) | 3 | +4672 | 2 | 271 | 2025-11-09 | ✅ |
| [src/agl-vss-proxy](https://github.com/gerrit.automotivelinux.org/src/agl-vss-proxy) | 3 | 0 | 0 | 520 | 2025-03-05 | ☑️ |
| [src/rasa-model-agl](https://github.com/gerrit.automotivelinux.org/src/rasa-model-agl) | 3 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [src/virtio/qemu](https://github.com/gerrit.automotivelinux.org/src/virtio/qemu) | 3 | 0 | 0 | 1032 | 2023-10-10 | ☑️ |
| [staging/toyota](https://github.com/gerrit.automotivelinux.org/staging/toyota) | 3 | 0 | 0 | 906 | 2024-02-13 | ☑️ |
| [zzz_acl/staging_acl](https://github.com/gerrit.automotivelinux.org/zzz_acl/staging_acl) | 2 | 0 | 0 | 3791 | 2016-03-21 | 🛑 |
| [apps/voiceagent-demo](https://github.com/gerrit.automotivelinux.org/apps/voiceagent-demo) | 1 | 0 | 0 | 1444 | 2022-08-24 | 🛑 |
| [src/libagl-compositor](https://github.com/gerrit.automotivelinux.org/src/libagl-compositor) | 1 | 0 | 0 | 2216 | 2020-07-13 | 🛑 |
| [src/steering-wheel-microcontroller](https://github.com/gerrit.automotivelinux.org/src/steering-wheel-microcontroller) | 1 | 0 | 0 | 1436 | 2022-09-01 | 🛑 |
| [src/virtio/virtio_driver](https://github.com/gerrit.automotivelinux.org/src/virtio/virtio_driver) | 1 | 0 | 0 | 1052 | 2023-09-20 | ☑️ |

**Total:** 70 repositories

---
## 🔧 Gerrit Project Feature Matrix

| Gerrit Project | Primary Type | Other Types | Dependabot | Pre-commit | ReadTheDocs | .gitreview | G2G | Status |
|----------------|--------------|-------------|------------|------------|-------------|------------|-----|--------|
| src/virtio/virtio_driver | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| AGL/AGL-repo | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/virtio/virtio-loopback-driver | C |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/virtio/virtio-loopback-adapter | C |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| AGL/lava-docker | Shell | Python, D | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| AGL/meta-agl-extra | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| AGL/workspace-config-agl | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| AGL/meta-agl-refhw | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| AGL/releng-scripts | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| apps/agl-service-audiomixer | C | C++ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| apps/agl-service-bluetooth | C | C++, D, Lua | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/agl-service-bluetooth-map | C | C++, D, Lua | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/agl-service-bluetooth-pbap | C | Shell, C++, D, Lua | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/agl-service-hvac | C++ | C | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| apps/agl-service-mediascanner | C | Shell, C++, D, Lua | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/camera-gstreamer | C++ | C | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| AGL/documentation | HTML | JavaScript, TypeScript, Python, CSS | ❌ | ❌ | ✅ | ✅ | ❌ | ✅ |
| apps/flutter-navigation | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/flutter-ros-demo | Python | C++, C | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| apps/flutter-instrument-cluster | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| apps/flutter-speechrecognition-demo | C++ | C | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/homescreen-demo-ci | C++ | C | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/homescreen | C | C++ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| apps/mominavi | C++ |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| apps/momiscreen | C++ |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/momiplayer | C++ |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/momiweather | C++ |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| apps/ondemandnavi | C | C++ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| apps/navigation | JavaScript | C++ | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/voiceagent-demo | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| AGL/meta-agl-demo | Shell | Python, C | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/agl-dbc | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| src/agl-compositor | C | C++ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/agl-shell-activator | C | C++ | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| src/agl-vss-proxy | C++ | C | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| src/applaunchd | C | C++ | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| src/agl-demo-control-panel | Python | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/bluez-glib | C |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/libagl-compositor | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| src/libaglnavigation | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| apps/flutter-ics-homescreen | Swift | Java, C++, C, Kotlin, Groovy, HTML | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/drm-lease-manager | C |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/libappcontroller | C | C++ | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| src/native-shell-client | C |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/pipewire-ic-ipc | C |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| AGL/meta-agl-devel | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/libcloudproxy | C++ | C | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| src/libqtappfw | C | C++ | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/qa-test-misc | Shell | C | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| src/rasa-model-agl | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| src/qa-testdefinitions | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| src/steering-wheel-microcontroller | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| src/qtaglextras | C++ | C | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| src/uhmi-agl-wm | C | C++ | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| src/snips-inference-agl | Python |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| src/window-management-client-grpc | C++ | C | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| zzz_acl/AGL_acl | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| staging/toyota | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| zzz_acl/noreplication | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| src/snips-model-agl | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| zzz_acl/src_acl | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| AGL/meta-agl | Shell | Python, Lua | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| zzz_acl/staging_acl | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| staging/rba | C++ | Python, Shell, .NET | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| z_sandbox | N/A |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ci-management | jjb |  | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| zzz_acl | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| staging/rba-tool | Java | Python, C, Groovy | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| staging | Java | Python, Shell, C++, C, .NET, Groovy | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| apps | C | JavaScript, Python, Shell, Java, C++, Swift, Kotlin, Groovy, D, HTML, Lua | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| AGL | Shell | JavaScript, TypeScript, Python, C, D, HTML, CSS, Lua | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| src/virtio/qemu | C | JavaScript, TypeScript, Python, Shell, Go, Rust, Java, C++, .NET, PHP, Swift, D, HTML, CSS, Lua, PLpgSQL | ❌ | ❌ | ✅ | ❌ | ❌ | ☑️ |
| src | C | JavaScript, TypeScript, Python, Shell, Go, Rust, Java, C++, .NET, PHP, Swift, D, HTML, CSS, Lua, PLpgSQL | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |

---
## 🏁 Deployed CI/CD Jobs

**Total GitHub workflows:** 1

**Total Jenkins jobs:** 5

| Gerrit Project | GitHub Workflows | Workflow Count | Jenkins Jobs | Job Count |
|----------------|-------------------|----------------|--------------|-----------|
| ci-management |  | 0 | ci-management-merge<br>ci-management-merge-packer-ubuntu-16.04-basebuild-agl-test-slave<br>ci-management-merge-packer-ubuntu-16.04-basebuild-control-slave<br>ci-management-verify-jjb<br>ci-management-verify-packer | 5 |
| src/virtio/qemu | lockdown.yml | 1 |  | 0 |

**Total:** 2 repositories with CI/CD jobs

---
## Unattributed Jenkins Jobs


These jobs could not be matched to any repository. They may be infrastructure jobs, release jobs, build pipelines, or jobs that use naming conventions different from the repository names. Consider reviewing the job names and repository naming patterns to improve attribution.


**Total:** 243 unattributed jobs

### Job Details

| Job Name | Status | URL |
|----------|--------|-----|
| build-machines-sstate-mirror | Success | [View Job](https://build.automotivelinux.org/job/build-machines-sstate-mirror/) |
| build-master-community-boards-weekly | Failed | [View Job](https://build.automotivelinux.org/job/build-master-community-boards-weekly/) |
| build-master-iceg-drmlease-weekly | Success | [View Job](https://build.automotivelinux.org/job/build-master-iceg-drmlease-weekly/) |
| ci-documentation-create-preview | Success | [View Job](https://build.automotivelinux.org/job/ci-documentation-create-preview/) |
| ci-documentation-remove-after-merge | Success | [View Job](https://build.automotivelinux.org/job/ci-documentation-remove-after-merge/) |
| ci-platform-AGL-repo-remove-artifacts | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-remove-artifacts/) |
| ci-platform-AGL-repo-verify | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify/) |
| ci-platform-AGL-repo-verify-CIB-bbe | Aborted | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-bbe/) |
| ci-platform-AGL-repo-verify-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-finish-success/) |
| ci-platform-AGL-repo-verify-CIB-flutter-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-flutter-qemux86-64/) |
| ci-platform-AGL-repo-verify-CIB-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-h3ulcb-nogfx/) |
| ci-platform-AGL-repo-verify-CIB-html5-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-html5-qemux86-64/) |
| ci-platform-AGL-repo-verify-CIB-ic-multicontainer-qemux86-64 | Failed | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-ic-multicontainer-qemux86-64/) |
| ci-platform-AGL-repo-verify-CIB-None | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-None/) |
| ci-platform-AGL-repo-verify-CIB-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-qemuarm/) |
| ci-platform-AGL-repo-verify-CIB-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-qemuarm64/) |
| ci-platform-AGL-repo-verify-CIB-qemuriscv | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-qemuriscv/) |
| ci-platform-AGL-repo-verify-CIB-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-qemux86-64/) |
| ci-platform-AGL-repo-verify-CIB-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-raspberrypi4/) |
| ci-platform-AGL-repo-verify-CIB-raspberrypi5 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-raspberrypi5/) |
| ci-platform-AGL-repo-verify-CIB-sparrow-hawk | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIB-sparrow-hawk/) |
| ci-platform-AGL-repo-verify-CIBT-bbe | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-bbe/) |
| ci-platform-AGL-repo-verify-CIBT-complete | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-complete/) |
| ci-platform-AGL-repo-verify-CIBT-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-finish-success/) |
| ci-platform-AGL-repo-verify-CIBT-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-h3ulcb-nogfx/) |
| ci-platform-AGL-repo-verify-CIBT-None | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-None/) |
| ci-platform-AGL-repo-verify-CIBT-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-qemuarm/) |
| ci-platform-AGL-repo-verify-CIBT-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-qemuarm64/) |
| ci-platform-AGL-repo-verify-CIBT-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-qemux86-64/) |
| ci-platform-AGL-repo-verify-CIBT-r8a7795-agl-refhw | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-r8a7795-agl-refhw/) |
| ci-platform-AGL-repo-verify-CIBT-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-raspberrypi4/) |
| ci-platform-AGL-repo-verify-CIBT-raspberrypi5 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-raspberrypi5/) |
| ci-platform-AGL-repo-verify-CIBT-upsquare | Aborted | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-CIBT-upsquare/) |
| ci-platform-AGL-repo-verify-failure | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-failure/) |
| ci-platform-AGL-repo-verify-YCL-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-AGL-repo-verify-YCL-qemux86-64/) |
| ci-platform-meta-agl-demo-remove-artifacts | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-remove-artifacts/) |
| ci-platform-meta-agl-demo-verify | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify/) |
| ci-platform-meta-agl-demo-verify-CIB-bbe | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-bbe/) |
| ci-platform-meta-agl-demo-verify-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-finish-success/) |
| ci-platform-meta-agl-demo-verify-CIB-flutter-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-flutter-qemux86-64/) |
| ci-platform-meta-agl-demo-verify-CIB-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-h3ulcb-nogfx/) |
| ci-platform-meta-agl-demo-verify-CIB-html5-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-html5-qemux86-64/) |
| ci-platform-meta-agl-demo-verify-CIB-ic-multicontainer-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-ic-multicontainer-qemux86-64/) |
| ci-platform-meta-agl-demo-verify-CIB-None | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-None/) |
| ci-platform-meta-agl-demo-verify-CIB-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-qemuarm/) |
| ci-platform-meta-agl-demo-verify-CIB-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-qemuarm64/) |
| ci-platform-meta-agl-demo-verify-CIB-qemuriscv | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-qemuriscv/) |
| ci-platform-meta-agl-demo-verify-CIB-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-qemux86-64/) |
| ci-platform-meta-agl-demo-verify-CIB-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-raspberrypi4/) |
| ci-platform-meta-agl-demo-verify-CIB-raspberrypi5 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-raspberrypi5/) |
| ci-platform-meta-agl-demo-verify-CIB-sparrow-hawk | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIB-sparrow-hawk/) |
| ci-platform-meta-agl-demo-verify-CIBT-bbe | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-bbe/) |
| ci-platform-meta-agl-demo-verify-CIBT-complete | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-complete/) |
| ci-platform-meta-agl-demo-verify-CIBT-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-finish-success/) |
| ci-platform-meta-agl-demo-verify-CIBT-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-h3ulcb-nogfx/) |
| ci-platform-meta-agl-demo-verify-CIBT-None | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-None/) |
| ci-platform-meta-agl-demo-verify-CIBT-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-qemuarm/) |
| ci-platform-meta-agl-demo-verify-CIBT-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-qemuarm64/) |
| ci-platform-meta-agl-demo-verify-CIBT-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-qemux86-64/) |
| ci-platform-meta-agl-demo-verify-CIBT-r8a7795-agl-refhw | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-r8a7795-agl-refhw/) |
| ci-platform-meta-agl-demo-verify-CIBT-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-raspberrypi4/) |
| ci-platform-meta-agl-demo-verify-CIBT-raspberrypi5 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-raspberrypi5/) |
| ci-platform-meta-agl-demo-verify-CIBT-upsquare | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-CIBT-upsquare/) |
| ci-platform-meta-agl-demo-verify-failure | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-failure/) |
| ci-platform-meta-agl-demo-verify-YCL-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-demo-verify-YCL-qemux86-64/) |
| ci-platform-meta-agl-devel-remove-artifacts | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-remove-artifacts/) |
| ci-platform-meta-agl-devel-verify | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify/) |
| ci-platform-meta-agl-devel-verify-CIB-bbe | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-bbe/) |
| ci-platform-meta-agl-devel-verify-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-finish-success/) |
| ci-platform-meta-agl-devel-verify-CIB-flutter-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-flutter-qemux86-64/) |
| ci-platform-meta-agl-devel-verify-CIB-h3ulcb-nogfx | Failed | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-h3ulcb-nogfx/) |
| ci-platform-meta-agl-devel-verify-CIB-html5-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-html5-qemux86-64/) |
| ci-platform-meta-agl-devel-verify-CIB-ic-multicontainer-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-ic-multicontainer-qemux86-64/) |
| ci-platform-meta-agl-devel-verify-CIB-None | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-None/) |
| ci-platform-meta-agl-devel-verify-CIB-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-qemuarm/) |
| ci-platform-meta-agl-devel-verify-CIB-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-qemuarm64/) |
| ci-platform-meta-agl-devel-verify-CIB-qemuriscv | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-qemuriscv/) |
| ci-platform-meta-agl-devel-verify-CIB-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-qemux86-64/) |
| ci-platform-meta-agl-devel-verify-CIB-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-raspberrypi4/) |
| ci-platform-meta-agl-devel-verify-CIB-raspberrypi5 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-raspberrypi5/) |
| ci-platform-meta-agl-devel-verify-CIB-sparrow-hawk | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIB-sparrow-hawk/) |
| ci-platform-meta-agl-devel-verify-CIBT-bbe | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-bbe/) |
| ci-platform-meta-agl-devel-verify-CIBT-complete | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-complete/) |
| ci-platform-meta-agl-devel-verify-CIBT-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-finish-success/) |
| ci-platform-meta-agl-devel-verify-CIBT-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-h3ulcb-nogfx/) |
| ci-platform-meta-agl-devel-verify-CIBT-None | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-None/) |
| ci-platform-meta-agl-devel-verify-CIBT-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-qemuarm/) |
| ci-platform-meta-agl-devel-verify-CIBT-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-qemuarm64/) |
| ci-platform-meta-agl-devel-verify-CIBT-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-qemux86-64/) |
| ci-platform-meta-agl-devel-verify-CIBT-r8a7795-agl-refhw | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-r8a7795-agl-refhw/) |
| ci-platform-meta-agl-devel-verify-CIBT-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-raspberrypi4/) |
| ci-platform-meta-agl-devel-verify-CIBT-raspberrypi5 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-raspberrypi5/) |
| ci-platform-meta-agl-devel-verify-CIBT-upsquare | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-CIBT-upsquare/) |
| ci-platform-meta-agl-devel-verify-failure | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-failure/) |
| ci-platform-meta-agl-devel-verify-YCL-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-devel-verify-YCL-qemux86-64/) |
| ci-platform-meta-agl-extra-remove-artifacts | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-remove-artifacts/) |
| ci-platform-meta-agl-extra-verify | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify/) |
| ci-platform-meta-agl-extra-verify-CIB-bbe | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIB-bbe/) |
| ci-platform-meta-agl-extra-verify-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIB-finish-success/) |
| ci-platform-meta-agl-extra-verify-CIB-flutter-qemux86-64 | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIB-flutter-qemux86-64/) |
| ci-platform-meta-agl-extra-verify-CIB-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIB-h3ulcb-nogfx/) |
| ci-platform-meta-agl-extra-verify-CIB-html5-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIB-html5-qemux86-64/) |
| ci-platform-meta-agl-extra-verify-CIB-ic-multicontainer-qemux86-64 | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIB-ic-multicontainer-qemux86-64/) |
| ci-platform-meta-agl-extra-verify-CIB-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIB-qemuarm/) |
| ci-platform-meta-agl-extra-verify-CIB-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIB-qemuarm64/) |
| ci-platform-meta-agl-extra-verify-CIB-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIB-qemux86-64/) |
| ci-platform-meta-agl-extra-verify-CIB-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIB-raspberrypi4/) |
| ci-platform-meta-agl-extra-verify-CIBT-bbe | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIBT-bbe/) |
| ci-platform-meta-agl-extra-verify-CIBT-complete | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIBT-complete/) |
| ci-platform-meta-agl-extra-verify-CIBT-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIBT-finish-success/) |
| ci-platform-meta-agl-extra-verify-CIBT-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIBT-h3ulcb-nogfx/) |
| ci-platform-meta-agl-extra-verify-CIBT-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIBT-qemuarm/) |
| ci-platform-meta-agl-extra-verify-CIBT-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIBT-qemuarm64/) |
| ci-platform-meta-agl-extra-verify-CIBT-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIBT-qemux86-64/) |
| ci-platform-meta-agl-extra-verify-CIBT-r8a7795-agl-refhw | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIBT-r8a7795-agl-refhw/) |
| ci-platform-meta-agl-extra-verify-CIBT-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIBT-raspberrypi4/) |
| ci-platform-meta-agl-extra-verify-CIBT-upsquare | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-CIBT-upsquare/) |
| ci-platform-meta-agl-extra-verify-failure | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-failure/) |
| ci-platform-meta-agl-extra-verify-YCL-qemux86-64 | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-extra-verify-YCL-qemux86-64/) |
| ci-platform-meta-agl-remove-artifacts | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-remove-artifacts/) |
| ci-platform-meta-agl-verify | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify/) |
| ci-platform-meta-agl-verify-CIB-bbe | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-bbe/) |
| ci-platform-meta-agl-verify-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-finish-success/) |
| ci-platform-meta-agl-verify-CIB-flutter-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-flutter-qemux86-64/) |
| ci-platform-meta-agl-verify-CIB-h3ulcb-nogfx | Failed | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-h3ulcb-nogfx/) |
| ci-platform-meta-agl-verify-CIB-html5-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-html5-qemux86-64/) |
| ci-platform-meta-agl-verify-CIB-ic-multicontainer-qemux86-64 | Failed | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-ic-multicontainer-qemux86-64/) |
| ci-platform-meta-agl-verify-CIB-None | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-None/) |
| ci-platform-meta-agl-verify-CIB-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-qemuarm/) |
| ci-platform-meta-agl-verify-CIB-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-qemuarm64/) |
| ci-platform-meta-agl-verify-CIB-qemuriscv | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-qemuriscv/) |
| ci-platform-meta-agl-verify-CIB-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-qemux86-64/) |
| ci-platform-meta-agl-verify-CIB-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-raspberrypi4/) |
| ci-platform-meta-agl-verify-CIB-raspberrypi5 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-raspberrypi5/) |
| ci-platform-meta-agl-verify-CIB-sparrow-hawk | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIB-sparrow-hawk/) |
| ci-platform-meta-agl-verify-CIBT-bbe | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-bbe/) |
| ci-platform-meta-agl-verify-CIBT-complete | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-complete/) |
| ci-platform-meta-agl-verify-CIBT-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-finish-success/) |
| ci-platform-meta-agl-verify-CIBT-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-h3ulcb-nogfx/) |
| ci-platform-meta-agl-verify-CIBT-None | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-None/) |
| ci-platform-meta-agl-verify-CIBT-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-qemuarm/) |
| ci-platform-meta-agl-verify-CIBT-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-qemuarm64/) |
| ci-platform-meta-agl-verify-CIBT-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-qemux86-64/) |
| ci-platform-meta-agl-verify-CIBT-r8a7795-agl-refhw | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-r8a7795-agl-refhw/) |
| ci-platform-meta-agl-verify-CIBT-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-raspberrypi4/) |
| ci-platform-meta-agl-verify-CIBT-raspberrypi5 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-raspberrypi5/) |
| ci-platform-meta-agl-verify-CIBT-upsquare | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-CIBT-upsquare/) |
| ci-platform-meta-agl-verify-failure | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-failure/) |
| ci-platform-meta-agl-verify-YCL-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-agl-verify-YCL-qemux86-64/) |
| ci-platform-meta-renesas-rcar-gen3-remove-artifacts | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-remove-artifacts/) |
| ci-platform-meta-renesas-rcar-gen3-verify | Failed | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIB-bbe | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIB-bbe/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIB-finish-success/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIB-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIB-h3ulcb-nogfx/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIB-html5-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIB-html5-qemux86-64/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIB-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIB-qemuarm/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIB-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIB-qemuarm64/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIB-qemux86-64 | Failed | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIB-qemux86-64/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIB-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIB-raspberrypi4/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIBT-bbe | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIBT-bbe/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIBT-complete | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIBT-complete/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIBT-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIBT-finish-success/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIBT-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIBT-h3ulcb-nogfx/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIBT-qemuarm | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIBT-qemuarm/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIBT-qemuarm64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIBT-qemuarm64/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIBT-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIBT-qemux86-64/) |
| ci-platform-meta-renesas-rcar-gen3-verify-CIBT-raspberrypi4 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-CIBT-raspberrypi4/) |
| ci-platform-meta-renesas-rcar-gen3-verify-failure | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-rcar-gen3-verify-failure/) |
| ci-platform-meta-renesas-remove-artifacts | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-remove-artifacts/) |
| ci-platform-meta-renesas-verify | Failed | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify/) |
| ci-platform-meta-renesas-verify-CIB-bbe | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIB-bbe/) |
| ci-platform-meta-renesas-verify-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIB-finish-success/) |
| ci-platform-meta-renesas-verify-CIB-h3ulcb-nogfx | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIB-h3ulcb-nogfx/) |
| ci-platform-meta-renesas-verify-CIB-html5-qemux86-64 | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIB-html5-qemux86-64/) |
| ci-platform-meta-renesas-verify-CIB-qemuarm | Failed | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIB-qemuarm/) |
| ci-platform-meta-renesas-verify-CIB-qemuarm64 | Aborted | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIB-qemuarm64/) |
| ci-platform-meta-renesas-verify-CIB-qemux86-64 | Failed | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIB-qemux86-64/) |
| ci-platform-meta-renesas-verify-CIB-raspberrypi4 | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIB-raspberrypi4/) |
| ci-platform-meta-renesas-verify-CIBT-bbe | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIBT-bbe/) |
| ci-platform-meta-renesas-verify-CIBT-complete | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIBT-complete/) |
| ci-platform-meta-renesas-verify-CIBT-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIBT-finish-success/) |
| ci-platform-meta-renesas-verify-CIBT-h3ulcb-nogfx | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIBT-h3ulcb-nogfx/) |
| ci-platform-meta-renesas-verify-CIBT-qemuarm | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIBT-qemuarm/) |
| ci-platform-meta-renesas-verify-CIBT-qemuarm64 | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIBT-qemuarm64/) |
| ci-platform-meta-renesas-verify-CIBT-qemux86-64 | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIBT-qemux86-64/) |
| ci-platform-meta-renesas-verify-CIBT-raspberrypi4 | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-CIBT-raspberrypi4/) |
| ci-platform-meta-renesas-verify-failure | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-meta-renesas-verify-failure/) |
| ci-platform-refhw-meta-agl-refhw-remove-artifacts | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-refhw-meta-agl-refhw-remove-artifacts/) |
| ci-platform-refhw-meta-agl-refhw-verify | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-refhw-meta-agl-refhw-verify/) |
| ci-platform-refhw-meta-agl-refhw-verify-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-refhw-meta-agl-refhw-verify-CIB-finish-success/) |
| ci-platform-refhw-meta-agl-refhw-verify-CIB-h3ulcb-nogfx | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-refhw-meta-agl-refhw-verify-CIB-h3ulcb-nogfx/) |
| ci-platform-refhw-meta-agl-refhw-verify-CIB-None | Not Built | [View Job](https://build.automotivelinux.org/job/ci-platform-refhw-meta-agl-refhw-verify-CIB-None/) |
| ci-platform-refhw-meta-agl-refhw-verify-CIBT-complete | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-refhw-meta-agl-refhw-verify-CIBT-complete/) |
| ci-platform-refhw-meta-agl-refhw-verify-CIBT-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-refhw-meta-agl-refhw-verify-CIBT-finish-success/) |
| ci-platform-refhw-meta-agl-refhw-verify-CIBT-r8a7795-agl-refhw | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-refhw-meta-agl-refhw-verify-CIBT-r8a7795-agl-refhw/) |
| ci-platform-refhw-meta-agl-refhw-verify-failure | Success | [View Job](https://build.automotivelinux.org/job/ci-platform-refhw-meta-agl-refhw-verify-failure/) |
| ci-xds-xds-agent-merge | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-agent-merge/) |
| ci-xds-xds-agent-merge-finish-success | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-agent-merge-finish-success/) |
| ci-xds-xds-agent-remove-artifacts | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-agent-remove-artifacts/) |
| ci-xds-xds-agent-verify-master | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-agent-verify-master/) |
| ci-xds-xds-agent-verify-master-CIB | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-agent-verify-master-CIB/) |
| ci-xds-xds-agent-verify-master-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-agent-verify-master-CIB-finish-success/) |
| ci-xds-xds-cli-merge | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-cli-merge/) |
| ci-xds-xds-cli-merge-finish-success | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-cli-merge-finish-success/) |
| ci-xds-xds-cli-remove-artifacts | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-cli-remove-artifacts/) |
| ci-xds-xds-cli-verify-master | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-cli-verify-master/) |
| ci-xds-xds-cli-verify-master-CIB | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-cli-verify-master-CIB/) |
| ci-xds-xds-cli-verify-master-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-cli-verify-master-CIB-finish-success/) |
| ci-xds-xds-gdb-merge | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-gdb-merge/) |
| ci-xds-xds-gdb-merge-finish-success | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-gdb-merge-finish-success/) |
| ci-xds-xds-gdb-remove-artifacts | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-gdb-remove-artifacts/) |
| ci-xds-xds-gdb-verify-master | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-gdb-verify-master/) |
| ci-xds-xds-gdb-verify-master-CIB | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-gdb-verify-master-CIB/) |
| ci-xds-xds-gdb-verify-master-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-gdb-verify-master-CIB-finish-success/) |
| ci-xds-xds-server-merge | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-server-merge/) |
| ci-xds-xds-server-merge-finish-success | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-server-merge-finish-success/) |
| ci-xds-xds-server-remove-artifacts | Not Built | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-server-remove-artifacts/) |
| ci-xds-xds-server-verify-master | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-server-verify-master/) |
| ci-xds-xds-server-verify-master-CIB | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-server-verify-master-CIB/) |
| ci-xds-xds-server-verify-master-CIB-finish-success | Success | [View Job](https://build.automotivelinux.org/job/ci-xds-xds-server-verify-master-CIB-finish-success/) |
| daily-jjb-doc-update | Failed | [View Job](https://build.automotivelinux.org/job/daily-jjb-doc-update/) |
| pre-fetch-mirror-weekly | Success | [View Job](https://build.automotivelinux.org/job/pre-fetch-mirror-weekly/) |
| release-jjb-quillback-release-from-snapshot | Success | [View Job](https://build.automotivelinux.org/job/release-jjb-quillback-release-from-snapshot/) |
| release-jjb-quillback-snapshot | Success | [View Job](https://build.automotivelinux.org/job/release-jjb-quillback-snapshot/) |
| release-jjb-quillback-sources | Success | [View Job](https://build.automotivelinux.org/job/release-jjb-quillback-sources/) |
| release-jjb-unagi-release-from-snapshot | Success | [View Job](https://build.automotivelinux.org/job/release-jjb-unagi-release-from-snapshot/) |
| release-jjb-unagi-snapshot | Failed | [View Job](https://build.automotivelinux.org/job/release-jjb-unagi-snapshot/) |
| release-jjb-unagi-sources | Success | [View Job](https://build.automotivelinux.org/job/release-jjb-unagi-sources/) |
| release-jjb-vimba-release-from-snapshot | Failed | [View Job](https://build.automotivelinux.org/job/release-jjb-vimba-release-from-snapshot/) |
| release-jjb-vimba-snapshot | Failed | [View Job](https://build.automotivelinux.org/job/release-jjb-vimba-snapshot/) |
| release-jjb-vimba-sources | Failed | [View Job](https://build.automotivelinux.org/job/release-jjb-vimba-sources/) |
| rm-snapshots-master-old | Success | [View Job](https://build.automotivelinux.org/job/rm-snapshots-master-old/) |
| sandbox-df-download | Success | [View Job](https://build.automotivelinux.org/job/sandbox-df-download/) |
| sandbox-find-file-sstate-mirror | Success | [View Job](https://build.automotivelinux.org/job/sandbox-find-file-sstate-mirror/) |
| sandbox-find-file-sstate-mirror-rm | Success | [View Job](https://build.automotivelinux.org/job/sandbox-find-file-sstate-mirror-rm/) |
| sandbox-ls-df-nfs | Success | [View Job](https://build.automotivelinux.org/job/sandbox-ls-df-nfs/) |
| sandbox-rm-nfs-sstate | Success | [View Job](https://build.automotivelinux.org/job/sandbox-rm-nfs-sstate/) |
| sandbox-rm-snapshots | Success | [View Job](https://build.automotivelinux.org/job/sandbox-rm-snapshots/) |
| sandbox-rm-sstate-mirror | Success | [View Job](https://build.automotivelinux.org/job/sandbox-rm-sstate-mirror/) |
| sandbox-rm-upload-ci | Success | [View Job](https://build.automotivelinux.org/job/sandbox-rm-upload-ci/) |
| snapshot-jjb-container-weekly | Failed | [View Job](https://build.automotivelinux.org/job/snapshot-jjb-container-weekly/) |
| test-lava | Not Built | [View Job](https://build.automotivelinux.org/job/test-lava/) |
| test-lxc | Success | [View Job](https://build.automotivelinux.org/job/test-lxc/) |

---


---*Generated with ❤️ by Release Engineering*