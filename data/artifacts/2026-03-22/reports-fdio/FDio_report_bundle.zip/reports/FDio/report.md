# 📊 GitHub Project Analysis Report: FDio

**Generated:** 2026-03-22 07:15:47 UTC
**Schema Version:** 1.5.0

---## Table of Contents

- [Global Summary](#summary)
- [Gerrit Projects](#repositories)
- [Top Contributors](#contributors)
- [Top Organizations](#organizations)
- [Repository Feature Matrix](#features)
- [Deployed CI/CD Jobs](#workflows)
- [Unattributed Jenkins Jobs](#unattributed-jobs)

---

## 📈 Global Summary

**✅ Current** commits within last 365 days

**☑️ Active** commits between 365-1095 days

**🛑 Inactive** no commits in 1095+ days

| Metric | Count | Percentage |
| --- | --- | --- |
| Total Repositories | 7 | 100% |
| Current Repositories | 4 | 57.1% |
| Active Repositories | 0 | 0.0% |
| Inactive Repositories | 3 | 42.9% |
| No Apparent Commits | 0 | 0.0% |
| Total Commits | 25.0K | - |
| Total Lines of Code | 32.1K | - |

---
## 🏢 Top Organizations

The data presented in the table below covers the past 365 days.

**Organizations Found:** 157

| Rank | Organization | Contributors | Commits | LOC | Δ LOC | Avg LOC/Commit | Unique Repositories |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | cisco.com | 158 | 1087 | +145451 | 273133 | +16 | 5 |
| 2 | gmail.com | 115 | 270 | +21257 | 29623 | +47 | 5 |
| 3 | icloud.com | 2 | 170 | +49797 | 125729 | -153 | 4 |
| 4 | hawari.fr | 1 | 20 | +16355 | 17562 | +757 | 1 |
| 5 | marvell.com | 14 | 19 | +1071 | 1230 | +48 | 3 |
| 6 | netgate.com | 14 | 15 | +1070 | 1241 | +59 | 1 |
| 7 | linuxfoundation.org | 15 | 14 | +207 | 465 | -3 | 7 |
| 8 | barachs.net | 2 | 9 | +533 | 588 | +53 | 2 |
| 9 | ipng.nl | 1 | 7 | +1379 | 1425 | +190 | 1 |
| 10 | travelping.com | 4 | 7 | +124 | 175 | +10 | 1 |
| 11 | intel.com | 59 | 6 | +56 | 88 | +4 | 4 |
| 12 | employees.org | 1 | 5 | +14144 | 14227 | +2812 | 1 |
| 13 | github.com | 2 | 4 | +4 | 8 | 0 | 2 |
| 14 | mts.ru | 2 | 4 | +299 | 409 | +47 | 1 |
| 15 | 46labs.com | 2 | 3 | +56 | 57 | +18 | 1 |
| 16 | hotmail.se | 1 | 3 | +1083 | 1431 | +245 | 1 |
| 17 | chinatelecom.cn | 4 | 2 | +18 | 32 | +2 | 1 |
| 18 | googlemail.com | 1 | 2 | +83 | 83 | +41 | 1 |
| 19 | inmon.com | 1 | 2 | +2504 | 3384 | +812 | 1 |
| 20 | ipng.ch | 1 | 2 | +545 | 610 | +240 | 1 |
| 21 | labn.net | 4 | 2 | +60 | 66 | +27 | 1 |
| 22 | sina.com | 1 | 2 | +7 | 18 | -2 | 1 |
| 23 | yandex-team.ru | 4 | 2 | +30 | 35 | +12 | 1 |
| 24 | 163.com | 8 | 1 | +8 | 16 | 0 | 1 |
| 25 | amd.com | 1 | 1 | +2 | 4 | 0 | 1 |
| 26 | andrews-macbook-pro.local | 1 | 1 | +1 | 2 | 0 | 1 |
| 27 | arm.com | 17 | 1 | +43 | 45 | +41 | 2 |
| 28 | baicells.com | 1 | 1 | +5 | 8 | +2 | 1 |
| 29 | graphiant.com | 5 | 1 | +4 | 8 | 0 | 1 |
| 30 | insidepacket.com | 1 | 1 | +5 | 5 | +5 | 1 |

---
## 👥 Top Contributors

The data presented in the table below covers the past 365 days.

**Contributors Found:** 662

| Rank | Contributor | Commits | LOC | Δ LOC | Avg LOC/Commit | Repositories | Organization |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Florin Coras | 232 | +10824 | 15567 | +26 | 3 | cisco.com |
| 2 | Matus Fabian | 223 | +31281 | 40023 | +101 | 2 | cisco.com |
| 3 | Dave Wallace | 219 | +15715 | 21811 | +43 | 5 | gmail.com |
| 4 | Peter Mikus | 169 | +49794 | 125724 | -154 | 4 | icloud.com |
| 5 | Damjan Marion | 142 | +42385 | 115598 | -217 | 2 | cisco.com |
| 6 | Tibor Frank | 119 | +7957 | 17170 | -10 | 3 | cisco.com |
| 7 | Adrian Villin | 100 | +16103 | 25028 | +71 | 1 | cisco.com |
| 8 | Vratko Polak | 68 | +17452 | 34010 | +13 | 4 | cisco.com |
| 9 | Benoît Ganne | 45 | +1916 | 3326 | +11 | 1 | cisco.com |
| 10 | Semir Sionek | 44 | +1949 | 2419 | +33 | 2 | cisco.com |
| 11 | Mohsin KAZMI | 27 | +3207 | 3632 | +103 | 2 | cisco.com |
| 12 | Mohammed Hawari | 20 | +16355 | 17562 | +757 | 1 | hawari.fr |
| 13 | Hadi Rayan Al-Sandid | 17 | +1423 | 1577 | +74 | 1 | cisco.com |
| 14 | Andrew Yourtchenko | 13 | +2118 | 2131 | +161 | 2 | gmail.com |
| 15 | Jerome Tollet | 13 | +4376 | 4524 | +325 | 1 | cisco.com |
| 16 | Naveen Joy | 13 | +1363 | 3308 | -44 | 3 | cisco.com |
| 17 | Steven | 13 | +878 | 1651 | +8 | 3 | cisco.com |
| 18 | Vanessa Rene Valderrama | 13 | +206 | 463 | -3 | 6 | linuxfoundation.org |
| 19 | Ivan Ivanets | 10 | +2513 | 3391 | +163 | 2 | cisco.com |
| 20 | Damjan Marion | 9 | +657 | 948 | +40 | 1 | gmail.com |
| 21 | Dave Barach | 9 | +533 | 588 | +53 | 2 | barachs.net |
| 22 | Matthew Smith | 9 | +384 | 437 | +36 | 1 | netgate.com |
| 23 | Monendra Singh Kushwaha | 8 | +524 | 566 | +60 | 1 | marvell.com |
| 24 | Yoann Desmouceaux | 8 | +131 | 186 | +9 | 1 | cisco.com |
| 25 | Kishor Dhanawade | 7 | +164 | 186 | +20 | 3 | marvell.com |
| 26 | Pim van Pelt | 7 | +1379 | 1425 | +190 | 1 | ipng.nl |
| 27 | Vladimir Zhigulin | 7 | +124 | 175 | +10 | 1 | travelping.com |
| 28 | Aritra Basu | 6 | +1334 | 1354 | +219 | 1 | cisco.com |
| 29 | Ivan Shvedunov | 6 | +686 | 804 | +94 | 1 | netgate.com |
| 30 | Jeff Shaw | 5 | +51 | 79 | +4 | 2 | intel.com |

---
## 📊 Repositories

| Repository | Commits | LOC | Contributors | Days Inactive | Last Commit Date | Status |
| --- | --- | --- | --- | --- | --- | --- |
| [vpp](https://github.com/gerrit.fd.io/vpp) | 15556 | +175790 | 76 | 3 | 2026-03-18 | ✅ |
| [csit](https://github.com/gerrit.fd.io/csit) | 6429 | +74303 | 7 | 1 | 2026-03-20 | ✅ |
| [ci-management](https://github.com/gerrit.fd.io/ci-management) | 2859 | +2259 | 10 | 37 | 2026-02-13 | ✅ |
| [vppsb](https://github.com/gerrit.fd.io/vppsb) | 88 | 0 | 0 | 2493 | 2019-05-24 | 🛑 |
| [.github](https://github.com/gerrit.fd.io/.github) | 25 | +3867 | 2 | 9 | 2026-03-13 | ✅ |
| [main_test](https://github.com/gerrit.fd.io/main_test) | 8 | 0 | 0 | 1968 | 2020-10-30 | 🛑 |
| [test_injector](https://github.com/gerrit.fd.io/test_injector) | 1 | 0 | 0 | 3490 | 2016-08-30 | 🛑 |

**Total:** 7 repositories

---
## 🔧 Gerrit Project Feature Matrix

| Gerrit Project | Primary Type | Other Types | Dependabot | Pre-commit | ReadTheDocs | .gitreview | G2G | Status |
|----------------|--------------|-------------|------------|------------|-------------|------------|-----|--------|
| test_injector | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| main_test | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vppsb | C | JavaScript, Shell, HTML, CSS, Lua | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| .github | Shell | Python | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| ci-management | jjb |  | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| csit | Robot Framework | Python, Shell, SCSS, HTML, HCL | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| vpp | C | Python, Shell, Go, C++, HTML, CSS, Lua | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ |

---
## 🏁 Deployed CI/CD Jobs

**Total GitHub workflows:** 36

**Total Jenkins jobs:** 14

| Gerrit Project | GitHub Workflows | Workflow Count | Jenkins Jobs | Job Count |
|----------------|-------------------|----------------|--------------|-----------|
| .github | gerrit-required-verify-non-voting.yaml<br>gerrit-verify.yaml | 2 |  | 0 |
| ci-management | gerrit-verify.yaml | 1 | ci-management-info-yaml-verify<br>ci-management-jenkins-cfg-merge<br>ci-management-jenkins-cfg-verify<br>ci-management-jenkins-sandbox-cleanup<br>ci-management-jjb-deploy-job<br>ci-management-jjb-merge<br>ci-management-jjb-verify<br>ci-management-packer-merge-centos-7-builder<br>ci-management-packer-merge-centos-8-builder<br>ci-management-packer-verify<br>ci-management-packer-verify-build-centos-7-builder<br>ci-management-packer-verify-build-centos-8-builder | 12 |
| csit | csit-cdash-version.yml<br>csit-dpdk-perf-mrr-weekly.yml<br>csit-hfr.yaml<br>csit-perf-report.yml<br>csit-trex-perf-ndrpdr-weekly.yml<br>csit-verify-tox.yaml<br>csit-vpp-perf-hoststack-daily.yml<br>csit-vpp-perf-mrr-daily.yml<br>csit-vpp-perf-mrr-weekly.yml<br>csit-vpp-perf-ndrpdr-weekly.yml<br>csit-vpp-perf-soak-weekly.yml<br>dependabot-updates<br>gerrit-comment-handler.yaml<br>github2gerrit.yaml<br>vpp-csit-bisect.yml | 15 | csit-info-yaml-verify | 1 |
| vpp | dependabot-updates<br>gerrit-comment-handler.yml<br>gerrit-merge.yml<br>gerrit-verify.yml<br>github2gerrit.yaml<br>periodic-vpp-verify-cov.yml<br>periodic-vpp-verify-dpdk-rdma-ver.yml<br>periodic-vpp-verify-hst.yml<br>update-graph<br>vpp-csit-verify-api.yml<br>vpp-merge-docs.yml<br>vpp-merge-maketest.yml<br>vpp-verify-arm-drivers.yml<br>vpp-verify-checkstyle.yml<br>vpp-verify-docs.yml<br>vpp-verify-gcc.yml<br>vpp-verify-hst.yml<br>vpp-verify-maketest.yml | 18 | vpp-cov-verify-master-ubuntu2404-x86_64 | 1 |

**Total:** 4 repositories with CI/CD jobs

---
## Unattributed Jenkins Jobs


These jobs could not be matched to any repository. They may be infrastructure jobs, release jobs, build pipelines, or jobs that use naming conventions different from the repository names. Consider reviewing the job names and repository naming patterns to improve attribution.


**Total:** 1 unattributed jobs

### Job Details

| Job Name | Status | URL |
|----------|--------|-----|
| test_job | Success | [View Job](https://jenkins.fd.io/job/test_job/) |

---
## 📋 Committer INFO.yaml Report

## 📋 Committer INFO.yaml Report

This report shows project information from INFO.yaml files, including lifecycle state, project leads, and committer activity status.

| Project | Creation Date | Lifecycle State | Project Lead | Committers |
|---------|---------------|-----------------|--------------|------------|
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">.github</span> | 2024-03-07 | Incubation | <span style="color: gray;" title="Unknown activity status">Vanessa Valderrama</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Andrew Grimberg</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Anil Belur</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Eric Ball</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jessica Wagantall</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Kevin Sandi</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Matt Watkins</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Dave Wallace</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ed Warnicke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Peter Mikus</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vratko Polak</span> |
| <a href="https://support.linuxfoundation.org" target="_blank">ci-management</a> | 2015-11-19 | Incubation | <span style="color: gray;" title="Unknown activity status">Andrew Grimberg</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Dave Wallace</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ed Warnicke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Peter Mikus</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vanessa Rene Valderrama</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vratko Polak</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Eric Ball</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">cicn</span> | 2017-02-02 | Incubation | <span style="color: gray;" title="Unknown activity status">Luca Muscariello</span> | <span style="color: gray;" title="Unknown activity status">Alberto Compagno</span><br><span style="color: gray;" title="Unknown activity status">Jim Gibson</span><br><span style="color: gray;" title="Unknown activity status">Jordan Augé</span><br><span style="color: gray;" title="Unknown activity status">Mauro Sardara</span><br><span style="color: gray;" title="Unknown activity status"> Michele Papalini</span><br><span style="color: gray;" title="Unknown activity status"> Angelo Mantellini</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">csit</span> | 2016-01-05 | Incubation | <span style="color: gray;" title="Unknown activity status">Maciek Konstantynowicz</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Dave Wallace</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Juraj Linkeš</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Peter Mikus</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tibor Frank</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vratko Polak</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">govpp</span> | 2017-4-27 | Incubation | <span style="color: gray;" title="Unknown activity status">Ondrej Fabry</span> | <span style="color: gray;" title="Unknown activity status">Jan Medved</span><br><span style="color: gray;" title="Unknown activity status">Rastislav Szabo</span><br><span style="color: gray;" title="Unknown activity status">Vladimir Lavor</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">hicn</span> | 2019-01-15 | Incubation | <span style="color: gray;" title="Unknown activity status">Luca Muscariello</span> | <span style="color: gray;" title="Unknown activity status">Alberto Compagno</span><br><span style="color: gray;" title="Unknown activity status">Jordan Augé</span><br><span style="color: gray;" title="Unknown activity status">Michele Papalini</span><br><span style="color: gray;" title="Unknown activity status">Mauro Sardara</span><br><span style="color: gray;" title="Unknown activity status">Jacques Samain</span><br><span style="color: gray;" title="Unknown activity status">Angelo Mantellini</span><br><span style="color: gray;" title="Unknown activity status">Olivier Roques</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">honeycomb</span> | 2016-12-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Marek Gradzki</span> | <span style="color: gray;" title="Unknown activity status">Dave Wallace</span><br><span style="color: gray;" title="Unknown activity status">Ed Warnicke</span><br><span style="color: gray;" title="Unknown activity status">Juraj Sloboda</span><br><span style="color: gray;" title="Unknown activity status">MaroÅ¡ MarÅ¡alek</span><br><span style="color: gray;" title="Unknown activity status">Robert Varga</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">tldk</span> | 2016-05-19 | Incubation | <span style="color: gray;" title="Unknown activity status">Konstantin Ananyev</span> | <span style="color: gray;" title="Unknown activity status">Mohammad Abdul Awal</span><br><span style="color: gray;" title="Unknown activity status">Ed Warnicke</span><br><span style="color: gray;" title="Unknown activity status">Keith Wiles</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">udpi</span> | 2019-29-08 | Incubation | <span style="color: gray;" title="Unknown activity status">Hongjun Ni</span> | <span style="color: gray;" title="Unknown activity status">Xiang Wang</span><br><span style="color: gray;" title="Unknown activity status">Yang Hong</span><br><span style="color: gray;" title="Unknown activity status">Harry Chang</span><br><span style="color: gray;" title="Unknown activity status">Jian Gu</span><br><span style="color: gray;" title="Unknown activity status">Jianghua Shan</span><br><span style="color: gray;" title="Unknown activity status">Yang Zhang</span><br><span style="color: gray;" title="Unknown activity status">Xingfu Li</span><br><span style="color: gray;" title="Unknown activity status">Xiaofan Li</span><br><span style="color: gray;" title="Unknown activity status">Yuying Xia</span><br><span style="color: gray;" title="Unknown activity status">Chenggang Fan</span><br><span style="color: gray;" title="Unknown activity status">Feng Gao</span><br><span style="color: gray;" title="Unknown activity status">Zhong Liu</span><br><span style="color: gray;" title="Unknown activity status">Yong Zhao</span><br><span style="color: gray;" title="Unknown activity status">Haiquan Chen</span><br><span style="color: gray;" title="Unknown activity status">Jim Thompson</span><br><span style="color: gray;" title="Unknown activity status">Pengjie Li</span><br><span style="color: gray;" title="Unknown activity status">Zhao Zhang</span><br><span style="color: gray;" title="Unknown activity status">Zhangpeng Xie</span><br><span style="color: gray;" title="Unknown activity status">Drenfong Wang</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">vpp</span> | 2015-12-08 | Incubation | <span style="color: gray;" title="Unknown activity status">Damjan Marion</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Dave Barach</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Florin Coras</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Benoit Ganne</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">John Lo</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Chris Luke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Neale Ranns</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Matthew Smith</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ole Trøan</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Paul Vinciguerra</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Dave Wallace</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ed Warnicke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Andrew Yourtchenko</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Fan Zhang</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Mohammed HAWARI</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">vsap</span> | 2019-12-10 | Incubation | <span style="color: gray;" title="Unknown activity status">Ping Yu</span> | <span style="color: gray;" title="Unknown activity status">Florin Coras</span><br><span style="color: gray;" title="Unknown activity status">Stephen Belair</span><br><span style="color: gray;" title="Unknown activity status">Jian Li</span><br><span style="color: gray;" title="Unknown activity status">Yuwei Zhang</span><br><span style="color: gray;" title="Unknown activity status">Shujun Zhuang</span><br><span style="color: gray;" title="Unknown activity status">Hongjun Ni</span><br><span style="color: gray;" title="Unknown activity status">Wei Xu</span> |


---

## 📊 INFO.yaml Lifecycle State Summary

### Lifecycle State Summary

| Lifecycle State | Gerrit Project Count | Percentage |
|----------------|---------------------|------------|
| Incubation | 11 | 100.0% |

**Total Projects:** 11
---

---*Generated with ❤️ by Release Engineering*