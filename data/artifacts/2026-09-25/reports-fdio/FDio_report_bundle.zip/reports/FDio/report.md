# 📊 GitHub Project Analysis Report: FDio

**Generated:** 2026-09-25 07:07:17 UTC
**Schema Version:** 1.5.0

---## Table of Contents

- [Global Summary](#summary)
- [Gerrit Projects](#repositories)
- [Top Contributors](#contributors)
- [Top Organizations](#organizations)
- [Repository Feature Matrix](#features)
- [Deployed CI/CD Jobs](#workflows)

---

## 📈 Global Summary

**✅ Current** commits within last 365 days

**☑️ Active** commits between 365-1095 days

**🛑 Inactive** no commits in 1095+ days

| Metric | Count | Percentage |
| --- | --- | --- |
| Total Repositories | 6 | 100% |
| Current Repositories | 3 | 50.0% |
| Active Repositories | 0 | 0.0% |
| Inactive Repositories | 3 | 50.0% |
| No Apparent Commits | 0 | 0.0% |
| Total Commits | 23.2K | - |
| Total Lines of Code | 80.7K | - |

---
## 🏢 Top Organizations

The data presented in the table below covers the past 365 days.

**Organizations Found:** 156

| Rank | Organization | Contributors | Commits | LOC | Δ LOC | Avg LOC/Commit | Unique Repositories |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | cisco.com | 159 | 1251 | +189152 | 319799 | +46 | 4 |
| 2 | gmail.com | 118 | 351 | +28644 | 41678 | +44 | 4 |
| 3 | icloud.com | 2 | 217 | +61831 | 145082 | -98 | 3 |
| 4 | netgate.com | 17 | 89 | +7144 | 8567 | +64 | 1 |
| 5 | hawari.fr | 1 | 18 | +16236 | 17443 | +834 | 1 |
| 6 | pm.me | 1 | 18 | +366 | 499 | +12 | 1 |
| 7 | github.com | 2 | 15 | +18 | 36 | 0 | 2 |
| 8 | marvell.com | 16 | 13 | +578 | 659 | +38 | 2 |
| 9 | ipng.nl | 1 | 11 | +2905 | 3262 | +231 | 1 |
| 10 | barachs.net | 2 | 9 | +533 | 588 | +53 | 1 |
| 11 | labn.net | 4 | 7 | +481 | 655 | +43 | 1 |
| 12 | qq.com | 5 | 7 | +515 | 607 | +60 | 1 |
| 13 | intel.com | 55 | 6 | +104 | 130 | +13 | 3 |
| 14 | meter.com | 5 | 6 | +70 | 124 | +2 | 2 |
| 15 | linuxfoundation.org | 5 | 5 | +168 | 190 | +29 | 6 |
| 16 | employees.org | 1 | 4 | +389 | 466 | +78 | 1 |
| 17 | googlemail.com | 1 | 3 | +84 | 85 | +27 | 1 |
| 18 | graphiant.com | 5 | 3 | +20 | 30 | +3 | 1 |
| 19 | hotmail.se | 1 | 3 | +1083 | 1431 | +245 | 1 |
| 20 | imc.com | 1 | 3 | +15 | 16 | +4 | 1 |
| 21 | 46labs.com | 2 | 2 | +382 | 432 | +166 | 1 |
| 22 | chinatelecom.cn | 4 | 2 | +18 | 32 | +2 | 1 |
| 23 | ericsson.com | 8 | 2 | +150 | 166 | +67 | 1 |
| 24 | ipng.ch | 1 | 2 | +545 | 610 | +240 | 1 |
| 25 | pantheon.tech | 31 | 2 | +474 | 584 | +182 | 2 |
| 26 | sina.com | 1 | 2 | +7 | 18 | -2 | 1 |
| 27 | travelping.com | 4 | 2 | +5 | 15 | -2 | 1 |
| 28 | andrews-macbook-pro.local | 1 | 1 | +1 | 2 | 0 | 1 |
| 29 | arm.com | 17 | 1 | +43 | 45 | +41 | 2 |
| 30 | mcconnachie.ca | 1 | 1 | +1 | 2 | 0 | 1 |

---
## 👥 Top Contributors

The data presented in the table below covers the past 365 days.

**Contributors Found:** 663

| Rank | Contributor | Commits | LOC | Δ LOC | Avg LOC/Commit | Repositories | Organization |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Florin Coras | 322 | +53788 | 71598 | +111 | 2 | cisco.com |
| 2 | Dave Wallace | 249 | +16109 | 23143 | +36 | 4 | gmail.com |
| 3 | Matus Fabian | 242 | +28333 | 42185 | +59 | 2 | cisco.com |
| 4 | Peter Mikus | 215 | +61812 | 145057 | -99 | 3 | icloud.com |
| 5 | Damjan Marion | 147 | +49586 | 123795 | -167 | 1 | cisco.com |
| 6 | Tibor Frank | 109 | +4524 | 7427 | +14 | 2 | cisco.com |
| 7 | Vratko Polak | 86 | +13582 | 22641 | +52 | 3 | cisco.com |
| 8 | Adrian Villin | 66 | +7686 | 13119 | +34 | 1 | cisco.com |
| 9 | Jerome Tollet | 59 | +10497 | 13476 | +127 | 1 | cisco.com |
| 10 | Benoît Ganne | 57 | +3258 | 4847 | +29 | 1 | cisco.com |
| 11 | Klement Sekera | 52 | +3678 | 4541 | +54 | 1 | netgate.com |
| 12 | Aritra Basu | 37 | +2395 | 2903 | +51 | 1 | cisco.com |
| 13 | Hadi Rayan Al-Sandid | 33 | +5285 | 5800 | +144 | 1 | cisco.com |
| 14 | Samuel Benko | 30 | +4087 | 4653 | +117 | 1 | cisco.com |
| 15 | Maxime Peim | 23 | +6473 | 9028 | +170 | 1 | gmail.com |
| 16 | Matus Fabian | 18 | +366 | 499 | +12 | 1 | pm.me |
| 17 | Mohammed Hawari | 18 | +16236 | 17443 | +834 | 1 | hawari.fr |
| 18 | Damjan Marion | 17 | +1123 | 1554 | +40 | 1 | gmail.com |
| 19 | Yoann Desmouceaux | 17 | +343 | 460 | +13 | 1 | cisco.com |
| 20 | Rob Shearman | 16 | +821 | 925 | +44 | 1 | gmail.com |
| 21 | dependabot[bot] | 15 | +18 | 36 | 0 | 1 | github.com |
| 22 | Mohsin KAZMI | 11 | +2402 | 2552 | +204 | 2 | cisco.com |
| 23 | Pim van Pelt | 11 | +2905 | 3262 | +231 | 1 | ipng.nl |
| 24 | Matthew Smith | 10 | +285 | 430 | +14 | 1 | netgate.com |
| 25 | Monendra Singh Kushwaha | 10 | +291 | 370 | +21 | 1 | marvell.com |
| 26 | Steven | 10 | +283 | 364 | +20 | 3 | cisco.com |
| 27 | Dave Barach | 9 | +533 | 588 | +53 | 1 | barachs.net |
| 28 | Ivan Shvedunov | 8 | +1596 | 1737 | +181 | 1 | netgate.com |
| 29 | Semir Sionek | 8 | +412 | 503 | +40 | 1 | cisco.com |
| 30 | Alexander Skorichenko | 7 | +774 | 900 | +92 | 1 | netgate.com |

---
## 📊 Repositories

| Repository | Commits | LOC | Contributors | Days Inactive | Last Commit Date | Status |
| --- | --- | --- | --- | --- | --- | --- |
| [vpp](https://github.com/gerrit.fd.io/vpp) | 16410 | +228465 | 92 | 0 | 2026-09-24 | ✅ |
| [csit](https://github.com/gerrit.fd.io/csit) | 6603 | +75182 | 7 | 0 | 2026-09-25 | ✅ |
| [vppsb](https://github.com/gerrit.fd.io/vppsb) | 88 | 0 | 0 | 2680 | 2019-05-24 | 🛑 |
| [.github](https://github.com/gerrit.fd.io/.github) | 49 | +8348 | 2 | 22 | 2026-09-03 | ✅ |
| [main_test](https://github.com/gerrit.fd.io/main_test) | 8 | 0 | 0 | 2155 | 2020-10-30 | 🛑 |
| [test_injector](https://github.com/gerrit.fd.io/test_injector) | 1 | 0 | 0 | 3677 | 2016-08-30 | 🛑 |

**Total:** 6 repositories

---
## 🔧 Gerrit Project Feature Matrix

| Gerrit Project | Primary Type | Other Types | Dependabot | Pre-commit | ReadTheDocs | .gitreview | G2G | Status |
|----------------|--------------|-------------|------------|------------|-------------|------------|-----|--------|
| test_injector | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| main_test | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vppsb | C | JavaScript, Shell, HTML, CSS, Lua | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| .github | HCL | Python, Shell | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| csit | Robot Framework | Python, Shell, SCSS, HTML, HCL | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| vpp | C | Python, Shell, Go, C++, HTML, CSS, Lua | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ |

---
## 🏁 Deployed CI/CD Jobs

**Total GitHub workflows:** 39

| Gerrit Project | GitHub Workflows | Workflow Count |
|----------------|-------------------|----------------|
| .github | gerrit-required-verify-non-voting.yaml<br>gerrit-verify.yaml<br>gha-dispatcher.yaml<br>terraform-nomad-alertmanager.yaml<br>terraform-nomad-gha-dispatcher.yaml<br>terraform-nomad-prometheus.yaml<br>terraform-nomad-pyspark-etl.yaml<br>update-graph | 8 |
| csit | csit-cdash-version.yml<br>csit-perf-report.yml<br>dependabot-updates<br>gerrit-comment-handler.yaml<br>gerrit-verify.yaml<br>github2gerrit.yaml<br>update-graph<br>vpp-csit-bisect.yml | 8 |
| vpp | dependabot-updates<br>gerrit-comment-handler.yml<br>gerrit-merge.yml<br>gerrit-verify.yml<br>github2gerrit.yaml<br>periodic-vpp-coverity.yml<br>periodic-vpp-verify-asan-hst.yml<br>periodic-vpp-verify-asan-maketest.yml<br>periodic-vpp-verify-cov.yml<br>periodic-vpp-verify-dpdk-rdma-ver.yml<br>periodic-vpp-verify-hst.yml<br>pr-verify.yml<br>update-graph<br>vpp-csit-verify-api.yml<br>vpp-merge-docs.yml<br>vpp-merge-maketest.yml<br>vpp-verify-arm-drivers.yml<br>vpp-verify-checkstyle.yml<br>vpp-verify-docs.yml<br>vpp-verify-gcc.yml<br>vpp-verify-hst-u2204.yml<br>vpp-verify-hst.yml<br>vpp-verify-maketest.yml | 23 |

**Total:** 3 repositories with CI/CD jobs

---
## 📋 Committer INFO.yaml Report

## 📋 Committer INFO.yaml Report

This report shows project information from INFO.yaml files, including lifecycle state, project leads, and committer activity status.

| Project | Creation Date | Lifecycle State | Project Lead | Committers |
|---------|---------------|-----------------|--------------|------------|
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">.github</span> | 2024-03-07 | Incubation | <span style="color: gray;" title="Unknown activity status">Vanessa Valderrama</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Andrew Grimberg</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Anil Belur</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Eric Ball</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jessica Wagantall</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Kevin Sandi</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Matt Watkins</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Dave Wallace</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ed Warnicke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Peter Mikus</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vratko Polak</span> |
| <a href="https://support.linuxfoundation.org" target="_blank">ci-management</a> | 2015-11-19 | Incubation | <span style="color: gray;" title="Unknown activity status">Andrew Grimberg</span> | <span style="color: gray;" title="Unknown activity status">Dave Wallace</span><br><span style="color: gray;" title="Unknown activity status">Ed Warnicke</span><br><span style="color: gray;" title="Unknown activity status">Peter Mikus</span><br><span style="color: gray;" title="Unknown activity status">Vanessa Rene Valderrama</span><br><span style="color: gray;" title="Unknown activity status">Vratko Polak</span><br><span style="color: gray;" title="Unknown activity status">Eric Ball</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">cicn</span> | 2017-02-02 | Incubation | <span style="color: gray;" title="Unknown activity status">Luca Muscariello</span> | <span style="color: gray;" title="Unknown activity status">Alberto Compagno</span><br><span style="color: gray;" title="Unknown activity status">Jim Gibson</span><br><span style="color: gray;" title="Unknown activity status">Jordan Augé</span><br><span style="color: gray;" title="Unknown activity status">Mauro Sardara</span><br><span style="color: gray;" title="Unknown activity status"> Michele Papalini</span><br><span style="color: gray;" title="Unknown activity status"> Angelo Mantellini</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">csit</span> | 2016-01-05 | Incubation | <span style="color: gray;" title="Unknown activity status">Maciek Konstantynowicz</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Dave Wallace</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Juraj Linkeš</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Peter Mikus</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tibor Frank</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vratko Polak</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">govpp</span> | 2017-4-27 | Incubation | <span style="color: gray;" title="Unknown activity status">Ondrej Fabry</span> | <span style="color: gray;" title="Unknown activity status">Jan Medved</span><br><span style="color: gray;" title="Unknown activity status">Rastislav Szabo</span><br><span style="color: gray;" title="Unknown activity status">Vladimir Lavor</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">hicn</span> | 2019-01-15 | Incubation | <span style="color: gray;" title="Unknown activity status">Luca Muscariello</span> | <span style="color: gray;" title="Unknown activity status">Alberto Compagno</span><br><span style="color: gray;" title="Unknown activity status">Jordan Augé</span><br><span style="color: gray;" title="Unknown activity status">Michele Papalini</span><br><span style="color: gray;" title="Unknown activity status">Mauro Sardara</span><br><span style="color: gray;" title="Unknown activity status">Jacques Samain</span><br><span style="color: gray;" title="Unknown activity status">Angelo Mantellini</span><br><span style="color: gray;" title="Unknown activity status">Olivier Roques</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">honeycomb</span> | 2016-12-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Marek Gradzki</span> | <span style="color: gray;" title="Unknown activity status">Dave Wallace</span><br><span style="color: gray;" title="Unknown activity status">Ed Warnicke</span><br><span style="color: gray;" title="Unknown activity status">Juraj Sloboda</span><br><span style="color: gray;" title="Unknown activity status">MaroÅ¡ MarÅ¡alek</span><br><span style="color: gray;" title="Unknown activity status">Robert Varga</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">tldk</span> | 2016-05-19 | Incubation | <span style="color: gray;" title="Unknown activity status">Konstantin Ananyev</span> | <span style="color: gray;" title="Unknown activity status">Mohammad Abdul Awal</span><br><span style="color: gray;" title="Unknown activity status">Ed Warnicke</span><br><span style="color: gray;" title="Unknown activity status">Keith Wiles</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">udpi</span> | 2019-29-08 | Incubation | <span style="color: gray;" title="Unknown activity status">Hongjun Ni</span> | <span style="color: gray;" title="Unknown activity status">Xiang Wang</span><br><span style="color: gray;" title="Unknown activity status">Yang Hong</span><br><span style="color: gray;" title="Unknown activity status">Harry Chang</span><br><span style="color: gray;" title="Unknown activity status">Jian Gu</span><br><span style="color: gray;" title="Unknown activity status">Jianghua Shan</span><br><span style="color: gray;" title="Unknown activity status">Yang Zhang</span><br><span style="color: gray;" title="Unknown activity status">Xingfu Li</span><br><span style="color: gray;" title="Unknown activity status">Xiaofan Li</span><br><span style="color: gray;" title="Unknown activity status">Yuying Xia</span><br><span style="color: gray;" title="Unknown activity status">Chenggang Fan</span><br><span style="color: gray;" title="Unknown activity status">Feng Gao</span><br><span style="color: gray;" title="Unknown activity status">Zhong Liu</span><br><span style="color: gray;" title="Unknown activity status">Yong Zhao</span><br><span style="color: gray;" title="Unknown activity status">Haiquan Chen</span><br><span style="color: gray;" title="Unknown activity status">Jim Thompson</span><br><span style="color: gray;" title="Unknown activity status">Pengjie Li</span><br><span style="color: gray;" title="Unknown activity status">Zhao Zhang</span><br><span style="color: gray;" title="Unknown activity status">Zhangpeng Xie</span><br><span style="color: gray;" title="Unknown activity status">Drenfong Wang</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">vpp</span> | 2015-12-08 | Incubation | <span style="color: gray;" title="Unknown activity status">Damjan Marion</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Dave Barach</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Florin Coras</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Benoit Ganne</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">John Lo</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Chris Luke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Neale Ranns</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Matthew Smith</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ole Trøan</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Paul Vinciguerra</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Dave Wallace</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ed Warnicke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Andrew Yourtchenko</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Fan Zhang</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Mohammed HAWARI</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">vsap</span> | 2019-12-10 | Incubation | <span style="color: gray;" title="Unknown activity status">Ping Yu</span> | <span style="color: gray;" title="Unknown activity status">Florin Coras</span><br><span style="color: gray;" title="Unknown activity status">Stephen Belair</span><br><span style="color: gray;" title="Unknown activity status">Jian Li</span><br><span style="color: gray;" title="Unknown activity status">Yuwei Zhang</span><br><span style="color: gray;" title="Unknown activity status">Shujun Zhuang</span><br><span style="color: gray;" title="Unknown activity status">Hongjun Ni</span><br><span style="color: gray;" title="Unknown activity status">Wei Xu</span> |


---

## 📊 INFO.yaml Lifecycle State Summary

### Lifecycle State Summary

| Lifecycle State | Gerrit Project Count | Percentage |
|----------------|---------------------|------------|
| Incubation | 11 | 100.0% |

**Total Projects:** 11
---

---*Generated with ❤️ by Release Engineering*