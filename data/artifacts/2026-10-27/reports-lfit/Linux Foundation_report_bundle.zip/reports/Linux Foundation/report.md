# 📊 GitHub Project Analysis Report: Linux Foundation

**Generated:** 2026-10-27 07:11:40 UTC
**Schema Version:** 1.5.0

---## Table of Contents

- [Global Summary](#summary)
- [Gerrit Projects](#repositories)
- [Top Contributors](#contributors)
- [Top Organizations](#organizations)
- [Repository Feature Matrix](#features)
- [Deployed CI/CD Jobs](#workflows)

---

## 📈 Global Summary

**✅ Current** commits within last 365 days

**☑️ Active** commits between 365-1095 days

**🛑 Inactive** no commits in 1095+ days

| Metric | Count | Percentage |
| --- | --- | --- |
| Total Repositories | 33 | 100% |
| Current Repositories | 22 | 66.7% |
| Active Repositories | 2 | 6.1% |
| Inactive Repositories | 9 | 27.3% |
| No Apparent Commits | 0 | 0.0% |
| Total Commits | 8.1K | - |
| Total Lines of Code | 10.8K | - |

---
## 🏢 Top Organizations

The data presented in the table below covers the past 365 days.

**Organizations Found:** 37

| Rank | Organization | Contributors | Commits | LOC | Δ LOC | Avg LOC/Commit | Unique Repositories |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | linuxfoundation.org | 31 | 456 | +14306 | 17939 | +23 | 33 |
| 2 | github.com | 1 | 43 | +84 | 168 | 0 | 3 |
| 3 | telekom.de | 2 | 2 | +83 | 83 | +41 | 2 |
| 4 | t-mobile.pl | 2 | 1 | +45 | 45 | +45 | 1 |
| 5 | att.com | 8 | 0 | 0 | 0 | 0 | 5 |
| 6 | bell.ca | 1 | 0 | 0 | 0 | 0 | 1 |
| 7 | chinamobile.com | 2 | 0 | 0 | 0 | 0 | 1 |
| 8 | cisco.com | 1 | 0 | 0 | 0 | 0 | 2 |
| 9 | colindixon.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 10 | enea.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 11 | ensicaen.fr | 1 | 0 | 0 | 0 | 0 | 1 |
| 12 | ericsson.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 13 | est.tech | 3 | 0 | 0 | 0 | 0 | 1 |
| 14 | gmail.com | 13 | 0 | 0 | 0 | 0 | 21 |
| 15 | hcl.com | 2 | 0 | 0 | 0 | 0 | 1 |
| 16 | highstreet-technologies.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 17 | hpe.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 18 | hq.sk | 1 | 0 | 0 | 0 | 0 | 2 |
| 19 | huawei.com | 2 | 0 | 0 | 0 | 0 | 1 |
| 20 | intel.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 21 | intracom-telecom.com | 1 | 0 | 0 | 0 | 0 | 1 |
| 22 | linux.com | 1 | 0 | 0 | 0 | 0 | 9 |
| 23 | navy.mil | 3 | 0 | 0 | 0 | 0 | 1 |
| 24 | nokia.com | 3 | 0 | 0 | 0 | 0 | 1 |
| 25 | opennetworking.org | 1 | 0 | 0 | 0 | 0 | 1 |
| 26 | orange.com | 5 | 0 | 0 | 0 | 0 | 4 |
| 27 | pantheon.tech | 1 | 0 | 0 | 0 | 0 | 1 |
| 28 | protonmail.ch | 1 | 0 | 0 | 0 | 0 | 1 |
| 29 | redhat.com | 4 | 0 | 0 | 0 | 0 | 3 |
| 30 | samsung.com | 3 | 0 | 0 | 0 | 0 | 1 |

---
## 👥 Top Contributors

The data presented in the table below covers the past 365 days.

**Contributors Found:** 106

| Rank | Contributor | Commits | LOC | Δ LOC | Avg LOC/Commit | Repositories | Organization |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Anil Belur | 213 | +5715 | 7131 | +20 | 24 | linuxfoundation.org |
| 2 | Matthew Watkins | 96 | +6927 | 7914 | +61 | 11 | linuxfoundation.org |
| 3 | lf-jobbuilder | 90 | +1381 | 2514 | +2 | 1 | linuxfoundation.org |
| 4 | dependabot[bot] | 43 | +84 | 168 | 0 | 3 | github.com |
| 5 | Andrew Grimberg | 31 | +146 | 218 | +2 | 28 | linuxfoundation.org |
| 6 | Kevin Sandi | 22 | +90 | 97 | +3 | 5 | linuxfoundation.org |
| 7 | Eric Ball | 4 | +47 | 65 | +7 | 16 | linuxfoundation.org |
| 8 | Fiete Ostkamp | 2 | +83 | 83 | +41 | 2 | telekom.de |
| 9 | Marek Szwalkiewicz | 1 | +45 | 45 | +45 | 1 | t-mobile.pl |
| 10 | Alexandru Avadanii | 0 | 0 | 0 | 0 | 1 | enea.com |
| 11 | Anil Belur | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 12 | Aric Gardner | 0 | 0 | 0 | 0 | 11 | linuxfoundation.org |
| 13 | Ayush | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 14 | Bengt Thuree | 0 | 0 | 0 | 0 | 7 | linuxfoundation.org |
| 15 | Bruno Sakoto | 0 | 0 | 0 | 0 | 1 | bell.ca |
| 16 | C.J. Collier | 0 | 0 | 0 | 0 | 1 | linuxfoundation.org |
| 17 | Chandra Dasari | 0 | 0 | 0 | 0 | 1 | linuxfoundation.org |
| 18 | Chau Do | 0 | 0 | 0 | 0 | 1 | navy.mil |
| 19 | Christopher Lott (cl778h) | 0 | 0 | 0 | 0 | 1 | att.com |
| 20 | Claudio D. Gasparini | 0 | 0 | 0 | 0 | 1 | att.com |
| 21 | Claudio D. Gasparini | 0 | 0 | 0 | 0 | 1 | pantheon.tech |
| 22 | Colin Dixon | 0 | 0 | 0 | 0 | 1 | colindixon.com |
| 23 | Cédric Ollivier | 0 | 0 | 0 | 0 | 1 | orange.com |
| 24 | DW Talton | 0 | 0 | 0 | 0 | 4 | linuxfoundation.org |
| 25 | Dan Timoney | 0 | 0 | 0 | 0 | 1 | att.com |
| 26 | Daniel Farrell | 0 | 0 | 0 | 0 | 2 | redhat.com |
| 27 | Daniel Farrell | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 28 | Daniel Pono Takamori | 0 | 0 | 0 | 0 | 4 | linuxfoundation.org |
| 29 | Dave Wallace | 0 | 0 | 0 | 0 | 1 | gmail.com |
| 30 | David Deal | 0 | 0 | 0 | 0 | 1 | gmail.com |

---
## 📊 Repositories

| Repository | Commits | LOC | Contributors | Days Inactive | Last Commit Date | Status |
| --- | --- | --- | --- | --- | --- | --- |
| [releng/info-master](https://github.com/gerrit.linuxfoundation.org/releng/info-master) | 3769 | +1510 | 6 | 4 | 2026-10-22 | ✅ |
| [releng/global-jjb](https://github.com/gerrit.linuxfoundation.org/releng/global-jjb) | 1608 | +2162 | 6 | 42 | 2026-09-14 | ✅ |
| [releng/lftools](https://github.com/gerrit.linuxfoundation.org/releng/lftools) | 709 | +936 | 2 | 11 | 2026-10-15 | ✅ |
| [releng/docs](https://github.com/gerrit.linuxfoundation.org/releng/docs) | 374 | +303 | 2 | 94 | 2026-07-24 | ✅ |
| [releng/common-packer](https://github.com/gerrit.linuxfoundation.org/releng/common-packer) | 300 | +786 | 2 | 14 | 2026-10-13 | ✅ |
| [sandbox](https://github.com/gerrit.linuxfoundation.org/sandbox) | 203 | +328 | 3 | 230 | 2026-03-10 | ✅ |
| [releng/docs-conf](https://github.com/gerrit.linuxfoundation.org/releng/docs-conf) | 173 | +2217 | 4 | 110 | 2026-07-09 | ✅ |
| [releng/gerrit_to_platform](https://github.com/gerrit.linuxfoundation.org/releng/gerrit_to_platform) | 149 | +3697 | 4 | 68 | 2026-08-19 | ✅ |
| [releng](https://github.com/gerrit.linuxfoundation.org/releng) | 113 | 0 | 0 | 965 | 2024-03-05 | ☑️ |
| [ansible/roles](https://github.com/gerrit.linuxfoundation.org/ansible/roles) | 70 | +26 | 2 | 103 | 2026-07-15 | ✅ |
| [ansible/roles/lf-recommended-tools](https://github.com/gerrit.linuxfoundation.org/ansible/roles/lf-recommended-tools) | 68 | +203 | 1 | 84 | 2026-08-04 | ✅ |
| [ansible/roles/java-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/java-install) | 62 | +436 | 2 | 49 | 2026-09-07 | ✅ |
| [ansible/roles/python-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/python-install) | 50 | +200 | 1 | 88 | 2026-07-31 | ✅ |
| [releng/ci-workshop](https://github.com/gerrit.linuxfoundation.org/releng/ci-workshop) | 47 | 0 | 0 | 1514 | 2022-09-03 | 🛑 |
| [ansible/roles/puppet-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/puppet-install) | 39 | +303 | 1 | 42 | 2026-09-14 | ✅ |
| [ansible/roles/system-update](https://github.com/gerrit.linuxfoundation.org/ansible/roles/system-update) | 37 | +115 | 1 | 88 | 2026-07-31 | ✅ |
| [ansible/roles/lf-dev-libs](https://github.com/gerrit.linuxfoundation.org/ansible/roles/lf-dev-libs) | 37 | +211 | 1 | 88 | 2026-07-31 | ✅ |
| [ansible/roles/docker-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/docker-install) | 33 | +138 | 1 | 88 | 2026-07-31 | ✅ |
| [ansible/roles/haveged-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/haveged-install) | 29 | +145 | 1 | 88 | 2026-07-31 | ✅ |
| [ansible/roles/shellcheck-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/shellcheck-install) | 27 | +149 | 1 | 88 | 2026-07-31 | ✅ |
| [ansible/roles/packer-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/packer-install) | 25 | +143 | 1 | 88 | 2026-07-31 | ✅ |
| [releng/pipelines](https://github.com/gerrit.linuxfoundation.org/releng/pipelines) | 24 | 0 | 0 | 1541 | 2022-08-08 | 🛑 |
| [puppet/modules/mailman3](https://github.com/gerrit.linuxfoundation.org/puppet/modules/mailman3) | 21 | 0 | 0 | 3771 | 2016-06-29 | 🛑 |
| [ansible/roles/mono-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/mono-install) | 20 | +216 | 2 | 87 | 2026-07-31 | ✅ |
| [ansible/roles/sysstat-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/sysstat-install) | 20 | +141 | 1 | 88 | 2026-07-31 | ✅ |
| [lfn/process](https://github.com/gerrit.linuxfoundation.org/lfn/process) | 13 | 0 | 0 | 3062 | 2018-06-08 | 🛑 |
| [ansible/roles/protobuf-install](https://github.com/gerrit.linuxfoundation.org/ansible/roles/protobuf-install) | 12 | 0 | 0 | 733 | 2024-10-24 | ☑️ |
| [releng/sigul-docker](https://github.com/gerrit.linuxfoundation.org/releng/sigul-docker) | 7 | +153 | 2 | 26 | 2026-09-30 | ✅ |
| [puppet/modules/gce](https://github.com/gerrit.linuxfoundation.org/puppet/modules/gce) | 5 | 0 | 0 | 3553 | 2017-02-02 | 🛑 |
| [releng/license-checker](https://github.com/gerrit.linuxfoundation.org/releng/license-checker) | 4 | 0 | 0 | 3069 | 2018-06-01 | 🛑 |
| [clav2test/icla-and-ccla-project](https://github.com/gerrit.linuxfoundation.org/clav2test/icla-and-ccla-project) | 2 | 0 | 0 | 2050 | 2021-03-16 | 🛑 |
| [clav2test/ccla-only-project](https://github.com/gerrit.linuxfoundation.org/clav2test/ccla-only-project) | 1 | 0 | 0 | 2853 | 2019-01-03 | 🛑 |
| [sandbox-info-master](https://github.com/gerrit.linuxfoundation.org/sandbox-info-master) | 1 | 0 | 0 | 2224 | 2020-09-24 | 🛑 |

**Total:** 33 repositories

---
## 🔧 Gerrit Project Feature Matrix

| Gerrit Project | Primary Type | Other Types | Dependabot | Pre-commit | ReadTheDocs | .gitreview | G2G | Status |
|----------------|--------------|-------------|------------|------------|-------------|------------|-----|--------|
| ansible/roles/protobuf-install | Shell |  | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| ansible/roles/lf-recommended-tools | Python | Shell | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/lf-dev-libs | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/mono-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/haveged-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/docker-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/packer-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/java-install | Shell | Python | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/puppet-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/python-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| puppet/modules/gce | Ruby | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| clav2test/ccla-only-project | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/roles/shellcheck-install | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| puppet/modules/mailman3 | Ruby | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| clav2test/icla-and-ccla-project | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/roles/sysstat-install | Python | Shell | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ |
| ansible/roles/system-update | Python | Shell | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| lfn/process | Python |  | ❌ | ❌ | ✅ | ✅ | ❌ | 🛑 |
| releng/ci-workshop | Groovy | Dockerfile, Shell | ❌ | ✅ | ❌ | ✅ | ❌ | 🛑 |
| releng/common-packer | HCL | Python, Shell | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ |
| releng/license-checker | Go |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| releng/docs | Python | Shell, HTML, CSS | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ |
| releng/docs-conf | Python |  | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| releng/gerrit_to_platform | Python |  | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| releng/pipelines | Groovy | Java/Gradle, Python, Shell, HTML | ❌ | ✅ | ✅ | ✅ | ❌ | 🛑 |
| releng/sigul-docker | Dockerfile |  | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| sandbox-info-master | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| releng/global-jjb | Shell | Python, Groovy, HTML | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ |
| releng/lftools | Python | HTML | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ |
| ansible/roles | Shell |  | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| releng/info-master | N/A |  | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| releng | Shell | Python, Go, Groovy, HTML, CSS, HCL | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| sandbox | Java/Maven | JavaScript, TypeScript, Python, Shell, Groovy, HTML, CSS | ✅ | ❌ | ✅ | ✅ | ❌ | ✅ |

---
## 🏁 Deployed CI/CD Jobs

**Total GitHub workflows:** 70

| Gerrit Project | GitHub Workflows | Workflow Count |
|----------------|-------------------|----------------|
| ansible/roles/docker-install | call-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| ansible/roles/haveged-install | call-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| ansible/roles/java-install | call-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| ansible/roles/lf-dev-libs | call-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| ansible/roles/lf-recommended-tools | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/mono-install | call-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| ansible/roles/packer-install | call-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| ansible/roles/protobuf-install | gerrit-verify.yaml | 1 |
| ansible/roles/puppet-install | call-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| ansible/roles/python-install | call-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| ansible/roles/shellcheck-install | call-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| ansible/roles/sysstat-install | call-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| ansible/roles/system-update | call-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| releng/common-packer | call-composed-github2gerrit.yaml<br>gerrit-verify.yaml<br>release.yaml | 3 |
| releng/docs | call-composed-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml | 3 |
| releng/docs-conf | build-test-release.yaml<br>dependabot-updates<br>gerrit-verify.yaml<br>github2gerrit.yaml<br>release-drafter.yaml<br>update-graph | 6 |
| releng/gerrit_to_platform | codeql.yaml<br>dependabot-updates<br>gerrit-verify.yaml<br>github2gerrit.yaml<br>release.yaml<br>testing.yaml | 6 |
| releng/global-jjb | call-composed-github2gerrit.yaml<br>dependabot-updates<br>gerrit-verify.yaml<br>release.yaml | 4 |
| releng/info-master | call-composed-github2gerrit.yaml<br>gerrit-verify.yaml | 2 |
| releng/lftools | call-composed-github2gerrit.yaml<br>codeql<br>codeql<br>dependabot-updates<br>gerrit-verify.yaml<br>release-drafter.yaml<br>release.yaml | 7 |
| releng/sigul-docker | gerrit-verify.yaml<br>release.yaml | 2 |
| sandbox | dependabot-updates<br>gerrit-merge-github2gerrit.yaml | 2 |

**Total:** 22 repositories with CI/CD jobs

---


---*Generated with ❤️ by Release Engineering*