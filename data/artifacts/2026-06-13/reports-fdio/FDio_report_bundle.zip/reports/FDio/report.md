# 📊 GitHub Project Analysis Report: FDio

**Generated:** 2026-06-13 08:07:02 UTC
**Schema Version:** 1.5.0

---## Table of Contents

- [Global Summary](#summary)
- [Gerrit Projects](#repositories)
- [Top Contributors](#contributors)
- [Top Organizations](#organizations)
- [Repository Feature Matrix](#features)
- [Deployed CI/CD Jobs](#workflows)

---

## 📈 Global Summary

**✅ Current** commits within last 365 days

**☑️ Active** commits between 365-1095 days

**🛑 Inactive** no commits in 1095+ days

| Metric | Count | Percentage |
| --- | --- | --- |
| Total Repositories | 6 | 100% |
| Current Repositories | 3 | 50.0% |
| Active Repositories | 0 | 0.0% |
| Inactive Repositories | 3 | 50.0% |
| No Apparent Commits | 0 | 0.0% |
| Total Commits | 22.6K | - |
| Total Lines of Code | 294.7K | - |

---
## 🏢 Top Organizations

The data presented in the table below covers the past 365 days.

**Organizations Found:** 154

| Rank | Organization | Contributors | Commits | LOC | Δ LOC | Avg LOC/Commit | Unique Repositories |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | cisco.com | 156 | 1143 | +175747 | 310983 | +35 | 4 |
| 2 | gmail.com | 115 | 305 | +23203 | 35205 | +36 | 4 |
| 3 | icloud.com | 2 | 185 | +51314 | 127529 | -134 | 3 |
| 4 | netgate.com | 16 | 71 | +5435 | 6637 | +59 | 1 |
| 5 | hawari.fr | 1 | 19 | +16354 | 17561 | +797 | 1 |
| 6 | github.com | 2 | 15 | +18 | 36 | 0 | 2 |
| 7 | ipng.nl | 1 | 11 | +3993 | 4357 | +329 | 1 |
| 8 | marvell.com | 16 | 10 | +232 | 265 | +19 | 2 |
| 9 | barachs.net | 2 | 9 | +533 | 588 | +53 | 1 |
| 10 | travelping.com | 4 | 7 | +124 | 175 | +10 | 1 |
| 11 | employees.org | 1 | 6 | +14481 | 14610 | +2392 | 1 |
| 12 | linuxfoundation.org | 5 | 6 | +172 | 204 | +23 | 6 |
| 13 | labn.net | 4 | 5 | +428 | 592 | +52 | 1 |
| 14 | intel.com | 55 | 4 | +18 | 33 | 0 | 3 |
| 15 | qq.com | 5 | 4 | +29 | 37 | +5 | 1 |
| 16 | googlemail.com | 1 | 3 | +84 | 85 | +27 | 1 |
| 17 | graphiant.com | 5 | 3 | +20 | 30 | +3 | 1 |
| 18 | hotmail.se | 1 | 3 | +1083 | 1431 | +245 | 1 |
| 19 | chinatelecom.cn | 4 | 2 | +18 | 32 | +2 | 1 |
| 20 | ipng.ch | 1 | 2 | +545 | 610 | +240 | 1 |
| 21 | mts.ru | 2 | 2 | +36 | 46 | +13 | 1 |
| 22 | pantheon.tech | 31 | 2 | +474 | 584 | +182 | 2 |
| 23 | sina.com | 1 | 2 | +7 | 18 | -2 | 1 |
| 24 | yandex-team.ru | 4 | 2 | +30 | 35 | +12 | 1 |
| 25 | 163.com | 8 | 1 | +8 | 16 | 0 | 1 |
| 26 | andrews-macbook-pro.local | 1 | 1 | +1 | 2 | 0 | 1 |
| 27 | arm.com | 17 | 1 | +43 | 45 | +41 | 2 |
| 28 | mcconnachie.ca | 1 | 1 | +1 | 2 | 0 | 1 |
| 29 | siewert.io | 1 | 1 | +12 | 23 | +1 | 1 |
| 30 | skbuff.ru | 1 | 1 | 0 | 1 | -1 | 1 |

---
## 👥 Top Contributors

The data presented in the table below covers the past 365 days.

**Contributors Found:** 648

| Rank | Contributor | Commits | LOC | Δ LOC | Avg LOC/Commit | Repositories | Organization |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Matus Fabian | 257 | +33382 | 46928 | +77 | 2 | cisco.com |
| 2 | Florin Coras | 248 | +32293 | 45265 | +77 | 2 | cisco.com |
| 3 | Dave Wallace | 229 | +15234 | 21576 | +38 | 4 | gmail.com |
| 4 | Peter Mikus | 183 | +51295 | 127504 | -136 | 3 | icloud.com |
| 5 | Damjan Marion | 161 | +42120 | 115273 | -192 | 1 | cisco.com |
| 6 | Tibor Frank | 104 | +8389 | 15594 | +11 | 2 | cisco.com |
| 7 | Adrian Villin | 90 | +12867 | 20230 | +61 | 1 | cisco.com |
| 8 | Vratko Polak | 75 | +22077 | 38541 | +74 | 3 | cisco.com |
| 9 | Benoît Ganne | 55 | +2816 | 4313 | +23 | 1 | cisco.com |
| 10 | Klement Sekera | 40 | +2621 | 3292 | +48 | 1 | netgate.com |
| 11 | Jerome Tollet | 31 | +6392 | 7107 | +183 | 1 | cisco.com |
| 12 | Semir Sionek | 24 | +1440 | 1788 | +45 | 1 | cisco.com |
| 13 | Hadi Rayan Al-Sandid | 22 | +3162 | 3401 | +132 | 1 | cisco.com |
| 14 | Mohammed Hawari | 19 | +16354 | 17561 | +797 | 1 | hawari.fr |
| 15 | Mohsin KAZMI | 19 | +3526 | 3879 | +167 | 2 | cisco.com |
| 16 | Maxime Peim | 16 | +2343 | 4570 | +7 | 1 | gmail.com |
| 17 | Steven | 16 | +526 | 794 | +16 | 3 | cisco.com |
| 18 | dependabot[bot] | 15 | +18 | 36 | 0 | 1 | github.com |
| 19 | Rob Shearman | 14 | +785 | 886 | +48 | 1 | gmail.com |
| 20 | Aritra Basu | 11 | +1688 | 1760 | +146 | 1 | cisco.com |
| 21 | Matthew Smith | 11 | +291 | 460 | +11 | 1 | netgate.com |
| 22 | Pim van Pelt | 11 | +3993 | 4357 | +329 | 1 | ipng.nl |
| 23 | Damjan Marion | 9 | +657 | 948 | +40 | 1 | gmail.com |
| 24 | Dave Barach | 9 | +533 | 588 | +53 | 1 | barachs.net |
| 25 | Samuel Benko | 9 | +894 | 982 | +89 | 1 | cisco.com |
| 26 | Yoann Desmouceaux | 9 | +133 | 190 | +8 | 1 | cisco.com |
| 27 | Andrew Yourtchenko | 8 | +1510 | 1520 | +187 | 1 | gmail.com |
| 28 | Ivan Shvedunov | 8 | +1596 | 1737 | +181 | 1 | netgate.com |
| 29 | Vladimir Zhigulin | 7 | +124 | 175 | +10 | 1 | travelping.com |
| 30 | Monendra Singh Kushwaha | 6 | +123 | 141 | +17 | 1 | marvell.com |

---
## 📊 Repositories

| Repository | Commits | LOC | Contributors | Days Inactive | Last Commit Date | Status |
| --- | --- | --- | --- | --- | --- | --- |
| [vpp](https://github.com/gerrit.fd.io/vpp) | 15971 | +209729 | 86 | 7 | 2026-06-05 | ✅ |
| [csit](https://github.com/gerrit.fd.io/csit) | 6503 | +79622 | 5 | 3 | 2026-06-09 | ✅ |
| [vppsb](https://github.com/gerrit.fd.io/vppsb) | 88 | 0 | 0 | 2576 | 2019-05-24 | 🛑 |
| [.github](https://github.com/gerrit.fd.io/.github) | 35 | +5094 | 2 | 29 | 2026-05-14 | ✅ |
| [main_test](https://github.com/gerrit.fd.io/main_test) | 8 | 0 | 0 | 2051 | 2020-10-30 | 🛑 |
| [test_injector](https://github.com/gerrit.fd.io/test_injector) | 1 | 0 | 0 | 3573 | 2016-08-30 | 🛑 |

**Total:** 6 repositories

---
## 🔧 Gerrit Project Feature Matrix

| Gerrit Project | Primary Type | Other Types | Dependabot | Pre-commit | ReadTheDocs | .gitreview | G2G | Status |
|----------------|--------------|-------------|------------|------------|-------------|------------|-----|--------|
| test_injector | N/A |  | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| main_test | Shell |  | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vppsb | C | JavaScript, Shell, HTML, CSS, Lua | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| .github | Shell | Python, HCL | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| csit | Robot Framework | Python, Shell, SCSS, HTML, HCL | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| vpp | C | Python, Shell, Go, C++, HTML, CSS, Lua | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ |

---
## 🏁 Deployed CI/CD Jobs

**Total GitHub workflows:** 30

| Gerrit Project | GitHub Workflows | Workflow Count |
|----------------|-------------------|----------------|
| .github | gerrit-required-verify-non-voting.yaml<br>gerrit-verify.yaml<br>gha-dispatcher.yaml<br>update-graph | 4 |
| csit | csit-cdash-version.yml<br>csit-perf-report.yml<br>dependabot-updates<br>gerrit-comment-handler.yaml<br>gerrit-verify.yaml<br>github2gerrit.yaml<br>update-graph<br>vpp-csit-bisect.yml | 8 |
| vpp | dependabot-updates<br>gerrit-comment-handler.yml<br>gerrit-merge.yml<br>gerrit-verify.yml<br>github2gerrit.yaml<br>periodic-vpp-verify-cov.yml<br>periodic-vpp-verify-dpdk-rdma-ver.yml<br>periodic-vpp-verify-hst.yml<br>update-graph<br>vpp-csit-verify-api.yml<br>vpp-merge-docs.yml<br>vpp-merge-maketest.yml<br>vpp-verify-arm-drivers.yml<br>vpp-verify-checkstyle.yml<br>vpp-verify-docs.yml<br>vpp-verify-gcc.yml<br>vpp-verify-hst.yml<br>vpp-verify-maketest.yml | 18 |

**Total:** 3 repositories with CI/CD jobs

---
## 📋 Committer INFO.yaml Report

## 📋 Committer INFO.yaml Report

This report shows project information from INFO.yaml files, including lifecycle state, project leads, and committer activity status.

| Project | Creation Date | Lifecycle State | Project Lead | Committers |
|---------|---------------|-----------------|--------------|------------|
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">.github</span> | 2024-03-07 | Incubation | <span style="color: gray;" title="Unknown activity status">Vanessa Valderrama</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Andrew Grimberg</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Anil Anil Belur</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Eric Ball</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Jessica Wagantall</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Kevin Sandi</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Matt Watkins</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Dave Wallace</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ed Warnicke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Peter Mikus</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vratko Polak</span> |
| <a href="https://support.linuxfoundation.org" target="_blank">ci-management</a> | 2015-11-19 | Incubation | <span style="color: gray;" title="Unknown activity status">Andrew Grimberg</span> | <span style="color: gray;" title="Unknown activity status">Dave Wallace</span><br><span style="color: gray;" title="Unknown activity status">Ed Warnicke</span><br><span style="color: gray;" title="Unknown activity status">Peter Mikus</span><br><span style="color: gray;" title="Unknown activity status">Vanessa Rene Valderrama</span><br><span style="color: gray;" title="Unknown activity status">Vratko Polak</span><br><span style="color: gray;" title="Unknown activity status">Eric Ball</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">cicn</span> | 2017-02-02 | Incubation | <span style="color: gray;" title="Unknown activity status">Luca Muscariello</span> | <span style="color: gray;" title="Unknown activity status">Alberto Compagno</span><br><span style="color: gray;" title="Unknown activity status">Jim Gibson</span><br><span style="color: gray;" title="Unknown activity status">Jordan Augé</span><br><span style="color: gray;" title="Unknown activity status">Mauro Sardara</span><br><span style="color: gray;" title="Unknown activity status"> Michele Papalini</span><br><span style="color: gray;" title="Unknown activity status"> Angelo Mantellini</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">csit</span> | 2016-01-05 | Incubation | <span style="color: gray;" title="Unknown activity status">Maciek Konstantynowicz</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Dave Wallace</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Juraj Linkeš</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Peter Mikus</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Tibor Frank</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Vratko Polak</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">govpp</span> | 2017-4-27 | Incubation | <span style="color: gray;" title="Unknown activity status">Ondrej Fabry</span> | <span style="color: gray;" title="Unknown activity status">Jan Medved</span><br><span style="color: gray;" title="Unknown activity status">Rastislav Szabo</span><br><span style="color: gray;" title="Unknown activity status">Vladimir Lavor</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">hicn</span> | 2019-01-15 | Incubation | <span style="color: gray;" title="Unknown activity status">Luca Muscariello</span> | <span style="color: gray;" title="Unknown activity status">Alberto Compagno</span><br><span style="color: gray;" title="Unknown activity status">Jordan Augé</span><br><span style="color: gray;" title="Unknown activity status">Michele Papalini</span><br><span style="color: gray;" title="Unknown activity status">Mauro Sardara</span><br><span style="color: gray;" title="Unknown activity status">Jacques Samain</span><br><span style="color: gray;" title="Unknown activity status">Angelo Mantellini</span><br><span style="color: gray;" title="Unknown activity status">Olivier Roques</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">honeycomb</span> | 2016-12-18 | Incubation | <span style="color: gray;" title="Unknown activity status">Marek Gradzki</span> | <span style="color: gray;" title="Unknown activity status">Dave Wallace</span><br><span style="color: gray;" title="Unknown activity status">Ed Warnicke</span><br><span style="color: gray;" title="Unknown activity status">Juraj Sloboda</span><br><span style="color: gray;" title="Unknown activity status">MaroÅ¡ MarÅ¡alek</span><br><span style="color: gray;" title="Unknown activity status">Robert Varga</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">tldk</span> | 2016-05-19 | Incubation | <span style="color: gray;" title="Unknown activity status">Konstantin Ananyev</span> | <span style="color: gray;" title="Unknown activity status">Mohammad Abdul Awal</span><br><span style="color: gray;" title="Unknown activity status">Ed Warnicke</span><br><span style="color: gray;" title="Unknown activity status">Keith Wiles</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">udpi</span> | 2019-29-08 | Incubation | <span style="color: gray;" title="Unknown activity status">Hongjun Ni</span> | <span style="color: gray;" title="Unknown activity status">Xiang Wang</span><br><span style="color: gray;" title="Unknown activity status">Yang Hong</span><br><span style="color: gray;" title="Unknown activity status">Harry Chang</span><br><span style="color: gray;" title="Unknown activity status">Jian Gu</span><br><span style="color: gray;" title="Unknown activity status">Jianghua Shan</span><br><span style="color: gray;" title="Unknown activity status">Yang Zhang</span><br><span style="color: gray;" title="Unknown activity status">Xingfu Li</span><br><span style="color: gray;" title="Unknown activity status">Xiaofan Li</span><br><span style="color: gray;" title="Unknown activity status">Yuying Xia</span><br><span style="color: gray;" title="Unknown activity status">Chenggang Fan</span><br><span style="color: gray;" title="Unknown activity status">Feng Gao</span><br><span style="color: gray;" title="Unknown activity status">Zhong Liu</span><br><span style="color: gray;" title="Unknown activity status">Yong Zhao</span><br><span style="color: gray;" title="Unknown activity status">Haiquan Chen</span><br><span style="color: gray;" title="Unknown activity status">Jim Thompson</span><br><span style="color: gray;" title="Unknown activity status">Pengjie Li</span><br><span style="color: gray;" title="Unknown activity status">Zhao Zhang</span><br><span style="color: gray;" title="Unknown activity status">Zhangpeng Xie</span><br><span style="color: gray;" title="Unknown activity status">Drenfong Wang</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">vpp</span> | 2015-12-08 | Incubation | <span style="color: gray;" title="Unknown activity status">Damjan Marion</span> | <span style="color: green;" title="✅ Current - commits within last 365 days">Dave Barach</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Florin Coras</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Benoit Ganne</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">John Lo</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Chris Luke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Neale Ranns</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Matthew Smith</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ole Trøan</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Paul Vinciguerra</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Dave Wallace</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Ed Warnicke</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Andrew Yourtchenko</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Fan Zhang</span><br><span style="color: green;" title="✅ Current - commits within last 365 days">Mohammed HAWARI</span> |
| <span style="color: red;" title="⚠️ Broken project issue-tracker link: Connection failed (after 3 attempts)">vsap</span> | 2019-12-10 | Incubation | <span style="color: gray;" title="Unknown activity status">Ping Yu</span> | <span style="color: gray;" title="Unknown activity status">Florin Coras</span><br><span style="color: gray;" title="Unknown activity status">Stephen Belair</span><br><span style="color: gray;" title="Unknown activity status">Jian Li</span><br><span style="color: gray;" title="Unknown activity status">Yuwei Zhang</span><br><span style="color: gray;" title="Unknown activity status">Shujun Zhuang</span><br><span style="color: gray;" title="Unknown activity status">Hongjun Ni</span><br><span style="color: gray;" title="Unknown activity status">Wei Xu</span> |


---

## 📊 INFO.yaml Lifecycle State Summary

### Lifecycle State Summary

| Lifecycle State | Gerrit Project Count | Percentage |
|----------------|---------------------|------------|
| Incubation | 11 | 100.0% |

**Total Projects:** 11
---

---*Generated with ❤️ by Release Engineering*